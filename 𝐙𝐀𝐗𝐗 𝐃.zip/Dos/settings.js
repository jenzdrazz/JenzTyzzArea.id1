const settings = {
  ownerName: '𝐙𝐀𝐗𝐗 𝐃𝐃𝐎𝐒', // Ganti dengan nama owner lu
  botToken: '7887065801:AAGt32Tyzt3GzR7YB-w2dpoUrzwlLDBhsgE', // Ganti dengan token bot Telegram lu
  owner: '7077196697', //OWNER user id
};

module.exports = settings;
